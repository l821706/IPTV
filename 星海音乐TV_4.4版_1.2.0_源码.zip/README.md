# 星海音乐TV（Android 4.4 电视端免费听歌应用）

一个给 **Android 4.4（API 19）电视 / 机顶盒** 用的音乐播放应用：纯原生 Java，不依赖 androidx、
**端上内置 JS 引擎（QuickJS，随包提供 x86 / armeabi-v7a / arm64-v8a）**、不引用 4.4 不存在的 API，
遥控器全程可操作，免费搜索并播放主流平台的公开试听内容。

- 应用名：星海音乐TV
- 包名：`com.freemusic.tv`
- 版本：1.2.0（versionCode 21）—— 本轮**修好「导入在线音源报 `cannot read property 'version' of undefined`」**：
  端上宿主补上 LX 的 **`lx.currentScriptInfo`**（脚本头部注释解析出的 `name/description/version/author/homepage`
  + 脚本原文 `rawScript`），此前因缺它而跑不通的脚本（如 `pdone/lx-music-source` 的 `lx/latest.js`「独家音源」、
  `flower_1.js`）现在能导入并按「引擎执行型」用起来；同时把「跑不通」的提示补成**可定位**：带上
  `（出错位置 文件:行:列）` 与 `脚本读取了宿主未提供的接口：lx.xxx`。改动清单
  [`docs/改动清单-1.2.0.md`](docs/改动清单-1.2.0.md)、上机取证
  [`docs/复验记录-1.2.0.md`](docs/复验记录-1.2.0.md)
- 上一版（1.1.9）：**播放缓存不再越攒越多**——播完 / 切歌 / 停止自动清理已缓存到本地的音频，
  `cacheDir` 下 `stream_*` 上限 40 MB / 6 个（详见 [`docs/复验记录-1.1.9.md`](docs/复验记录-1.1.9.md)）
- 更早（1.1.8）：端上内置 QuickJS 引擎，导入 `.js` 时先静态提取、提取不到就把脚本真跑一次，
  跑得起来按「引擎执行型」收下并在播放时实时跑脚本取地址（详见
  [`docs/复验记录-1.1.8.md`](docs/复验记录-1.1.8.md) 与 [`docs/js引擎与脚本执行-设计.md`](docs/js引擎与脚本执行-设计.md)）
- minSdk / targetSdk：19 / 19
- 产物：`星海音乐TV_4.4版_1.2.0.apk`（约 1.30 MB，v1 + v2 + v3 签名；含三个 ABI 的 JS 引擎库）

## 一、功能

| 模块 | 说明 |
| --- | --- |
| 搜索 | 聚合 QQ音乐、酷狗、酷我、网易云的公开搜索接口，可按音源筛选；12 个热门搜索词一键搜索；列表内自动去重 |
| 榜单 | 12 个公开榜单（热歌榜、新歌榜、飙升榜、原创榜、电音榜、国风榜、民谣榜、摇滚榜、ACG榜、古典榜、欧美热歌榜、Billboard榜），单榜最多 100 首 |
| 解析取流 | 可在设置页**导入音源并切换**：导入的「模板型音源」（`.json` 描述）优先取流，取不到再走**内置音源线路**（内置音源脚本 fish_music，地址见设置页；320K 档取不到时自动降一档试 128K），再按 **QQ音乐 → 酷狗音乐 → 酷我音乐 → 网易云音乐** 的顺序回退（同平台直取或跨平台同名匹配），命中即停；每条候选先取 2KB 验真（含自己跟随 302 跳转，取流地址用验真时的最终地址） |
| 播放 | 流式失败自动改整曲缓存后本地播放；支持 上一首 / 播放暂停 / 下一首 / 快退 10 秒 / 快进 10 秒 / 拖动进度；**从列表页点回正在播放的那首歌只切回播放页并保留播放进度**（不重新取流、不从头播放）；**播放模式可选 顺序播放 / 列表循环 / 单曲循环 / 随机播放**（播放页模式按钮切换，选择存偏好、跨曲目保持）；**列表页光标/高亮自动跟随正在播放的歌**（播完自动切下一首后跟着走，只设选中与滚动、不抢焦点） |
| 歌词 | LRC 逐行解析后**一行一个视图渲染**，当前播放行按时间轴**高亮**（亮蓝色，其余灰）并滚动居中，与歌曲人声对齐；歌词页可见时进度回调加密到 250ms，并**按下一行时间戳精确调度换行**（自校正，拖动 / 暂停 / 换歌都不错档）；设置页「歌词提前量」17 档可调（延后 2 秒 ~ 提前 8 秒、低档 0.25 秒步进，**默认不提前**）；拖动进度条时高亮即时跟随；加载中显示「歌词加载中…」，取不到显示「暂无歌词」；QQ 来源优先走 QQ 音乐官方歌词接口 |
| 封面 | 黑胶唱片样式自绘视图，封面圆形裁切并随播放旋转；取不到封面时用歌名首字生成贴纸 |
| 收藏 | 收藏 / 取消收藏（播放页 OK 键）；收藏页可整列表播放，**按菜单键取消当前选中行的收藏**（长按 OK 同样可取消，触摸长按有效） |
| 设置 | 音质（高品 128K / 超品 320K / 无损 FLAC）、取流方式（直接流式 / 先下载再播；「先下载再播」与 HTTPS 线路会先把整曲存到本地缓存，**播完/切歌/停止即回收，缓存上限 40MB / 6 个**）、**内置 / 导入音源切换**（行值标出当前是内置还是导入并给出内置 / 导入个数，按 OK 循环切换、立即生效、落盘并重启保持）、**导入在线音源**（在线地址导入 / 扫描本地目录；`.json` 描述直接生效，`.js` 按「字面音质键→地址表 / 平台 musicUrl 里拼出来的地址 / `{id}`·`{level}` 模板表」三类写法尽力提取，两类失败提示分开，格式见 [`docs/音源描述文件格式.md`](docs/音源描述文件格式.md)）、**歌词提前量**（17 档：延后 2 秒 / 1 秒 / 0.5 秒 → 不提前 → 提前 0.25 ~ 8 秒，按 OK 逐档循环，**默认不提前**；真机「人声领先」就往上调）、清除封面缓存；底部显示当前音源脚本、内置音源接口地址、平台顺序、当前音质与当前音源 |

## 二、遥控器操作

| 按键 | 作用 |
| --- | --- |
| 方向键 | 在导航、热词、音源筛选、列表、播放控件之间移动焦点 |
| OK / 确认 | 选中；列表项即播放该歌；设置项即切换取值 |
| 返回 | 先关闭播放页；非搜索页时回到搜索页；**在搜索页按返回会弹「退出应用」确认框**（点取消留在应用，点退出才结束），避免遥控器误触退出 |
| 菜单 | **收藏页**：取消当前选中行的收藏；**其它页面**：直接跳到设置页 |
| 播放 / 暂停键 | 暂停与继续（也可用播放页「暂停/播放」按钮） |
| 上一曲 / 下一曲键 | 上下一首（顺序播放已到列表末尾时按「下一首」会提示且不跳转） |
| 快退 / 快进键 | 后退 / 前进 10 秒（播放页也有「快退 / 快进」按钮，暂停时也生效） |
| 长按 ← / →（播放页） | 快退 / 快进 10 秒；短按仍是原来的焦点移动 / 进度条拖动 |
| 长按 OK（收藏页） | 取消该歌的收藏（触摸长按有效；部分遥控器的长按会被「确认键」兜底逻辑吃掉，此时用菜单键） |
| 播放页「播放模式」按钮 | 顺序播放 → 列表循环 → 单曲循环 → 随机播放 循环切换，按钮上显示当前模式；关闭播放页改用返回键 |

## 三、构建

工程不需要 Gradle / AGP，也不需要在系统里预装 Android SDK——构建脚本会在缺工具链时自动从国内镜像下载。

```bash
cd freemusic-tv
./build.sh                 # 缺什么下什么，然后直接出 APK
FETCH_ONLY=1 ./build.sh    # 只准备工具链
```

已有工具链时可用环境变量指定，走最快的本地路径：

```bash
JAVA_HOME=/path/to/jdk11 \
BUILD_TOOLS=/path/to/build-tools \
ANDROID_JAR=/path/to/android-19/android.jar \
./build.sh
```

换用别的音源脚本地址（不改代码）：

```bash
LX_SOURCE_URL=https://example.com/xxx/latest.js ./build.sh
```

脚本流程（任何一步失败都会中止并指出阶段）：

0. 布局尺寸自检（`tools/check_layouts.py`）：任何元素缺 `layout_width` / `layout_height` 直接构建失败
0.3 内置音源脚本获取（`tools/fetch_lx_source.sh`）：从内置音源接口地址取脚本，**GitHub 直连不可达时
    自动按顺序尝试 jsDelivr / gitmirror / ghproxy 镜像**，全部失败则沿用仓库里已有的脚本
0.5 音源脚本描述文件（`tools/extract_lx_source.js`）：用 Node **真实运行**该脚本，把它的音源键、
    id 字段、音质等级、url 模板与来源地址、脚本 sha256 固化成 `assets/lx_source.json`
1. `aapt2 compile` 编译资源
2. `aapt2 link` 生成资源表与 `R.java`，并用 `-A assets` 把音源脚本与描述文件打进包
3. `javac -source 8 -target 8` 编译 Java 源码
4. `d8 --min-api 19` 生成 dex
5. 组装 APK 并 `zipalign` 4 字节对齐
6. `apksigner` 签名（v1 + v2，兼容 Android 4.4）并回验

自动下载源（国内可直连）：腾讯 `AndroidSDK` 镜像的 build-tools、华为 `openjdk` 镜像的 JDK 11、
Google `android-19_r04` 平台包。

> 首次构建会在 `keystore/freemusic.jks` 生成自签名证书（口令写在 `build.sh` 里，仅为本地构建默认值）。
> **请保留 `keystore/` 目录**：同一把钥匙才能让后续版本覆盖安装；正式发布请替换为你自己的签名配置。
> 本源码包内**含** `keystore/freemusic.jks`（与已发布安装包同一把钥匙，SHA-256
> `4889af03b2f80fa478a9ec7ce10f97408ea6691def183dcef24887e4e49be2fc`），便于直接覆盖安装；
> 证书含私钥，正式发布请替换为你自己的签名配置。

## 四、安装

```bash
adb install -r build/star-music-tv-1.0.3.apk
```

- 可直接覆盖安装 1.0.2 / 1.0.1 / 1.0.0（同为自签名证书，`versionCode` 已升到 4）。
- 也可拷到 U 盘插到电视上用文件管理器安装。
- 首次安装需在系统设置里允许「未知来源」安装。
- 若电视上已装过同一包名但签名不同的版本，需先卸载再安装。
- 应用同时声明了 `LAUNCHER` 与 `LEANBACK_LAUNCHER`，电视桌面的「应用」与「Android TV 应用」入口都能找到。

## 五、兼容 Android 4.4 的关键设计

1. **编译期强制约束**：编译用的就是 API 19 的 `android.jar`，任何 `>API19` 的调用会直接编译失败。
2. **布局尺寸自检**：4.4 上元素缺 `layout_width` / `layout_height` 不会在打包阶段报错，而是在
   `LayoutInflater` 里抛异常、应用一开就闪退，所以这一项被做成构建前的硬性检查。
3. **零第三方依赖**：界面用系统控件（`ListView` / `TextView` / `EditText` / `SeekBar` / `ScrollView`）加
   自绘 `Canvas` 视图；不引入 androidx、矢量图、字体图标。
4. **不在端上跑 JS**：音源脚本是 ES2015+（箭头函数/解构/模板串/async），而 4.4 的 WebView 是 Chromium 33
   （只有 ES5），可用版 Rhino 同样只到 ES5，端上根本解析不了；因此改成「构建期真实运行脚本 → 固化行为
   描述文件 → 端上按描述执行」，行为等价且不依赖 JS 引擎（详见 `docs/lx-source-integration.md`）。
5. **不触碰高版本 API**：dex 静态扫描 `java/util/function`、`java/time`、`java/util/stream`、
   `java/nio/file`、`androidx`、`javax/script`、`java/beans`、`MediaSession`、`NotificationChannel`、
   `DisplayCutout` 等引用数全为 0。
6. **TLS 1.2**：4.4 默认只协商 TLSv1，这里给 `HttpsURLConnection` 换上会启用 TLSv1.2 / 1.1 / 1 的
   SocketFactory（证书校验仍走系统默认，不做任何绕过）。
7. **遥控器确认键双通道**：列表项自身挂点击监听，同时在列表上直接拦 `DPAD_CENTER` / `ENTER` 回接条目
   点击逻辑，不依赖框架内部把确认键转成点击的行为。
8. **启动自检**：`CrashGuard` 捕获启动阶段异常并在屏幕上显示异常类名与堆栈，同时写到
   `files/last_crash.txt`，避免「黑一下就退出、什么线索都没有」。
9. **单 dex 未超限**：方法/字段引用远低于 64K，不需要 MultiDex。

## 六、取流链路（默认走内置音源线路，平台线路回退）

```
默认音源线路（内置音源脚本）：https://raw.githubusercontent.com/pdone/lx-music-source/main/fish/latest.js
各平台官方接口：QQ音乐 c.y.qq.com / u.y.qq.com，酷狗 m.kugou.com，酷我 nmobi.kuwo.cn，网易云 music.163.com

歌曲
 → ① 默认音源线路（内置音源脚本 fish_music，按脚本分支取流；先按设置音质，取不到降一档试 128K）
 → ② QQ音乐      官方 vkey 取流（同平台直取；其它平台按歌名+歌手在 QQ 匹配后再取）
 → ③ 酷狗音乐    换源聚合 kg_song_kw.php → 酷狗官方接口（同平台直取或跨平台匹配）
 → ④ 酷我音乐    酷我 car 官方取流接口 → 酷我官方取流接口（同平台直取或跨平台匹配）
 → ⑤ 网易云音乐  enhance/player/url → 外链兜底（同平台直取或跨平台匹配）
 → ⑥ 模板型音源脚本线路（仅脚本是「URL 模板型」时有；fish 属运行时装接口型，会跳过）
 → 每条候选都取前 2KB 验真（Content-Type 只认 audio/*，或 ID3/MP3/FLAC/OGG/MP4/WAV 魔数）后才交给 MediaPlayer
 → 命中第一条真音频即停；全部失败则如实逐条列出原因，并可在设置里换音质重试
```

**歌词接口本轮未改动**（与取流链路相互独立）：
QQ 来源走 QQ 音乐官方歌词 `c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg`；
酷我来源走酷我官方明文歌词 `m.kuwo.cn/newh5/singles/songinfoandlrc`；
其余先在 QQ 官方按歌名+歌手找一次，再回落到网易云歌词。

**QQ 音乐官方取流的实测结论（2026-11-05）**：
- 搜索 `c.y.qq.com/soso/fcgi-bin/client_search_cp`、歌词 `…/fcg_query_lyric_new.fcg` 匿名可用，端上直接用。
- 取流 `u.y.qq.com/cgi-bin/musicu.fcg`（vkey.GetVkeyServer）**对匿名请求一律返回空 purl**
  （换 module / platform / filename 组合、直连 CDN 也都是 403）——需要登录态（uin + qqmusic_key）。
  端上照官方参数发起请求，拿到空地址就按上面的顺序落到下一家，绝不伪造地址；播放页线路区会如实打印
  `[FAIL] QQ音乐 · 官方取流 flac · HTTP 0 · - · QQ 官方 vkey 接口`。

默认音源线路（fish_music）各平台分支见下表；改回模板型脚本只需换地址、不用改代码：
`LX_SOURCE_URL=<脚本地址> ./build.sh`。

| 平台（fish 脚本内） | 脚本的尝试顺序 |
| --- | --- |
| 网易云 wy | 换源聚合 `musicapi.haitangw.net` / `music.haitangw.cc` 的 `wy_song_kw.php` → 网易云官方接口 → 酷我交叉匹配 |
| 酷狗 kg | 换源聚合 `kg_song_kw.php` → 酷狗官方接口（`m.kugou.com getSongInfo`）→ 酷我交叉匹配 |
| QQ音乐 tx | QQ 聚合接口 `tang.api.s01s.cn/music_open_api.php?mid=` → 酷我交叉匹配 |
| 酷我 kw | 酷我 car 取流接口（`nmobi.kuwo.cn` convert_url_with_sign + car 客户端 source）→ 酷我交叉匹配 |
| 咪咕 mg | 酷我交叉匹配 |

- 换源聚合与交叉匹配都要求「歌名 + 歌手」与请求歌曲对得上（脚本里的 strict match），对不上判失败继续下一条。
- 酷我 car 接口在部分歌曲/320K 档会返回 `.mgg`（酷我客户端专用加密封装，普通播放器打不开），
  这种候选直接判不可用；默认线路此时会降一档改试 128K（实测能拿到 mp3/aac 真音频）。
- 播放页的「线路」区会逐条打印 `[OK]/[FAIL] 线路名 · HTTP 状态 · 类型 · 备注`，
  例如 `[OK] 默认音源 fish_music v1.9.0 · QQ音乐 flac（酷我交叉匹配 rid=…） · audio/x-flac · 已验真为音频`，
  或 `[FAIL] 默认音源 … 320k · 该音质没取到可用地址，改试 128k` → `[OK] 默认音源 … 128k（酷我 car 取流接口）`。
- 音质三档映射：高品 128K → 网易云 br=128000 / 换源 level=standard / 酷我 car `br=128kmp3`；
  超品 320K → 320000 / exhigh / `320kmp3`；无损 FLAC → 999000 / lossless / `2000kflac`。

## 七、验证结论

> 第七、八节主体是 1.0.3 时期（内置音源为「长青SVIP音源」）的记录，保留作为历史对照；
> 当前版本（1.0.7：平台顺序 QQ→酷狗→酷我→网易云、QQ 官方接口、三档音质、退出确认、快进快退）的
> 改动与逐项取证见 [`docs/复验记录-1.0.7.md`](docs/复验记录-1.0.7.md)；
> 1.0.6 换内置音源为 fish 见 [`docs/复验记录-1.0.6.md`](docs/复验记录-1.0.6.md)；
> 1.0.4/1.0.5 的酷我官方接口改造见 [`docs/复验记录-1.0.5.md`](docs/复验记录-1.0.5.md)。

### 7.1 构建产物与静态检查

- 布局尺寸自检：70 个元素全部具备尺寸属性。
- APK 内容：`AndroidManifest.xml`、`resources.arsc`、`classes.dex`、`res/` 与四套密度图标之外，
  还包含 `assets/lx_source.json`（脚本行为描述）与 `assets/lx_sources/changqing-latest.js`
  （脚本原文，即从内置音源接口地址取到的那份）。
- dex 静态扫描：高版本 API 与 androidx 引用全部为 0；dex 版本 `035`（Dalvik 可加载）。
- 清单：`sdkVersion=19`、`targetSdkVersion=19`、`versionCode=4`、`versionName=1.0.3`、
  LAUNCHER + LEANBACK_LAUNCHER 正常注册。
- 签名：`apksigner verify` 通过 v1（JAR）、v2、v3 三代方案。

### 7.2 联网实跑（JVM，与 APK 内同一份 class）

```
音源脚本描述文件装载：长青SVIP音源 v1.3.0 / changqing-latest.js / 音源键=[kg, tx, wy, kw, mg]
  来源地址：https://raw.githubusercontent.com/pdone/lx-music-source/main/changqing/latest.js
  脚本 sha256：6a942987c1e111a113376fbf8ff9fb677c487058f16ce792779c72f69c4ed6de
  五个平台的 id 字段与音质等级全部读出：kg→hash，其余→songmid；128k=standard / 320k=exhigh / flac=lossless
脚本线路排在所有候选最前面（实测 HTTP 404 后自动回退），四类来源全部拿到 HTTP 206 + audio/mpeg 真实音频
搜索/榜单/歌词/整曲下载等检查合计 29 项全部 PASS
验证脚本：tools/jvm_verify/JvmVerify.java（用法见文件头注释）
```

### 7.3 Android 4.4.2 上机实测（API 19，x86 无头模拟器）

```
安装：Success，包内版本 versionCode=4 / versionName=1.0.3
启动：Displayed com.freemusic.tv/.MainActivity: +1s901ms，无 FATAL EXCEPTION
设置页（原文）：音源脚本：长青SVIP音源 v1.3.0（changqing-latest.js，线路优先；
              内置音源接口 GitHub pdone/lx-music-source/main/changqing/latest.js）
播放：搜索后按遥控器 OK 进入播放页，进度正常推进（00:19 / 02:48），
      Android 4.4 媒体引擎 AwesomePlayer 已 setDataSource_l 加载音频流
线路诊断（播放页原文，节选）：
      已暂停，按播放键继续
      [FAIL] 长青SVIP音源 v1.3.0 · wy音乐 320k · HTTP 404 · text/html · 非音频响应 text/html
          http://yinyue.haitangw.net/wy/wy.php?type=mp3&id=865050824&level…
      [FAIL] 长青SVIP音源 v1.3.0 · wy音乐 128k · HTTP 404 · text/html · 非音频响应 text/html
      [OK]   网易云 · 官方接口 320K · HTTP 206 · audio/mpeg; charset=UTF-8 · 已验真为音频
```

## 八、已知限制

- **内置音源脚本的上游当前不可用（最重要的一条）**：官方地址取到的仍是「长青SVIP音源 v1.3.0」，
  它 5 个平台的取流都指向 `yinyue.haitangw.net`，该域名下相关路径实测全部 nginx 404，因此
  **脚本线路目前拿不到音频**，实际出声靠内置直连线路兜底。每次构建都会从官方地址重新取脚本，
  等作者发布可用版本后重新构建即可生效（端上代码无需改动）。
- 脚本自带的「更新门禁」在 v1.3.0 中实测已失效（它的判断条件是 `statusCode === 99924`，正常 HTTP
  响应永远不满足），所以本应用不实现该门禁，仅按描述文件执行取流。
- 上机验证用的是 **Android 4.4.2（API 19）模拟器**，仍非真实电视 / 机顶盒与实体遥控器：字体观感、
  某些厂商遥控键码差异需装到真机后再微调；模拟器没有音频输出设备，「解码器已加载音频流 + 播放进度
  正常推进」是当前能拿到的最强证据。
- 长按 OK 取消收藏未在模拟器上验证（输入工具无法模拟长按），如失效可在播放页按 OK 取消收藏。
- 播放依赖第三方接口，接口若调整或限流会直接影响可用性（已做多线路与兜底，仍可能个别歌曲取不到）。
- 酷狗 / QQ 音乐的内置直链不可用，这两家的歌曲由跨平台兜底播放（可能是同曲不同版本）。
- 与历史交付的其他包名/签名不同，不能互相覆盖安装。
- 本软件仅聚合各平台公开试听接口用于个人学习研究，不提供下载、破解与转载能力，请勿用于商业用途。

## 九、修复记录（1.0.0 → 1.0.1）

1.0.0 装机后表现为「安装成功、一打开就闪退」，共定位并修复三处问题，均已在上机环境复验：

| # | 现象 | 根因 | 修复 |
| --- | --- | --- | --- |
| 1 | 一打开就闪退 | 搜索页两个按钮只写了 `layout_height`，`@style/ActionButton` 也没提供宽度；AAPT2 打包不报错，运行时 `LinearLayout.LayoutParams` 抛 `Binary XML file line #34: You must supply a layout_width attribute` | 给 `ActionButton` / `ChipButton` 样式补 `layout_width`，相关元素再显式补一遍；新增 `tools/check_layouts.py` 并入构建，这类问题直接拦在出包前 |
| 2 | 遥控器按 OK 没反应（列表上） | 4.4 的 `ListView` 自己持有焦点，列表项不接焦点、只显示选中态，框架内部未把确认键转成条目点击，键被列表项「按下去什么都不做」地吞掉 | 列表项挂上自身点击监听，并在列表上直接拦 `DPAD_CENTER` / `ENTER` 回接条目点击逻辑（`attachConfirmKeyListener`），不依赖框架内部行为 |
| 3 | 播放页「收藏 / 音质 / 关闭」看不到 | 控制行 6 个按钮总宽超出右侧可用宽度，被挤出屏幕 | 拆成两行（上一首/暂停/下一首 + 收藏/音质/关闭），歌词区高度 190dp → 150dp |

复现 1.0.0 崩溃的原始日志（Android 4.4.2）：

```
E/AndroidRuntime: FATAL EXCEPTION: main
E/AndroidRuntime: Process: com.freemusic.tv, PID: 2201
E/AndroidRuntime: java.lang.RuntimeException: Unable to start activity
        ComponentInfo{com.freemusic.tv/com.freemusic.tv.MainActivity}:
        java.lang.RuntimeException: Binary XML file line #34: You must supply a layout_width attribute.
E/AndroidRuntime:     at android.content.res.TypedArray.getLayoutDimension(TypedArray.java:492)
E/AndroidRuntime:     at android.view.ViewGroup$LayoutParams.setBaseAttributes(ViewGroup.java:5948)
E/AndroidRuntime:     at android.widget.LinearLayout$LayoutParams.<init>(LinearLayout.java:1831)
E/AndroidRuntime:     at android.view.LayoutInflater.rInflate(LayoutInflater.java:758)
E/AndroidRuntime:     at com.freemusic.tv.MainActivity.onCreate(MainActivity.java:114)
```

## 十、变更记录（1.0.1 → 1.0.2）：歌曲解析音源接入 lx 音源脚本

**做了什么**

- 新增 `tools/extract_lx_source.js`：构建期在 Node 里**真实运行**音源脚本，把它对外暴露的能力固化成
  `assets/lx_source.json`：5 个平台（kg/tx/wy/kw/mg）、各自的 id 字段（kg 用 `hash`，其余用 `songmid`）、
  音质等级（`128k=standard` / `320k=exhigh` / `flac=lossless`）与 url 模板。
- 新增 `LxSource.java`：端上读取描述文件，按脚本行为拼取流地址；`PlayResolver` 把脚本线路
  **排到所有候选线路最前面**（同平台 1–2 条 + 跨平台 1 条），其后再走原有直连与兜底。
- 脚本原文随包分发；设置页新增音源脚本信息展示；播放页线路诊断逐条打印。

**为什么不在端上直接执行这份 JS**

脚本用到了 `globalThis`、箭头函数、解构、模板串、`async/await`（实测扫描结果），而 Android 4.4 的
WebView 是 Chromium 33（仅 ES5）、可用版 Rhino 也仅 ES5，端上无法解析；本脚本的取流逻辑是纯字符串
拼装，因此构建期固化后行为等价、且不依赖任何 JS 引擎。完整取舍与接口清单见
`docs/lx-source-integration.md`。

## 十一、变更记录（1.0.2 → 1.0.3）：内置音源接口改为官方地址

**改了什么**

- `build.sh` 新增内置音源接口地址常量，并在构建时由 `tools/fetch_lx_source.sh` 从该地址取脚本：

  ```
  https://raw.githubusercontent.com/pdone/lx-music-source/main/changqing/latest.js
  ```

  直连不可达时自动按顺序尝试 jsDelivr / gitmirror / ghproxy 镜像，全部失败则沿用仓库里已有脚本；
  也可用 `LX_SOURCE_URL=<其它地址> ./build.sh` 临时换源。
- 描述文件新增两个字段：`sourceUrl`（内置音源接口地址）与 `scriptSha256`（脚本指纹），便于溯源；
  随包分发的脚本文件改名为 `assets/lx_sources/changqing-latest.js`（对应官方地址的 latest）。
- 设置页底部说明新增内置音源接口地址展示。

**这次改动的一个如实结论**

该地址上的脚本与上一版内置的脚本**逐字节相同**：

```
sha256  6a942987c1e111a113376fbf8ff9fb677c487058f16ce792779c72f69c4ed6de
        （官方地址取到 / 上一版随包脚本 / 本次包内脚本 三者一致）
```

因此行为与 1.0.2 一致：脚本线路排第一优先、当前实测 404，随后回退到内置直连线路并成功播放。
本版真正的变化是把"内置音源接口 = 该官方地址"固定下来并可自动取用，而不是音源能力本身。

## 十二、变更记录（1.1.5 → 1.1.6）：修好「导入在线音源被拒」

**问题**

导入在线音源地址（`.js` / `.json`）时提示「这个音源没有端上可用的取流模板，未导入」。用
pdone/lx-music-source 仓库里 12 份真实脚本复现：旧规则（只认字面「音质键 → http 地址」表）把 **12 份全部拒掉**，
其中 4 份其实是「识别规则漏判」——脚本把取流地址写在按平台组织的 `musicUrl` / 模板表里，用
`'…?type=mp3&id=' + hash` 或 `` `…?type=mp3&id=${n}&level=${e}` `` 拼出来，并没有字面的音质键表。

**改法（`SourceStore`，仍不执行 JS）**

- 识别三类写法：① 字面「音质键 → 地址」表；② 脚本里按平台拼出来的地址（字符串拼接 / ES 模板串）；
  ③ 本来就是 `{id}` / `{level}` 的模板表。统一归一成 `{id}` / `{level}`，并支持 `${encodeURIComponent(id)}`
  这类简单包装。
- 平台归属：地址前最近出现的平台键（`kg:{musicUrl(...)}`），否则看地址路径特征（`/kg/`、`kw.php`、`kgqq`…），
  否则各平台都试一遍。
- 排除非取流地址：`.json` / `.js` / `.html` 等文件、含 `type=json` / `format=json` 的接口、歌词 / 封面 /
  搜索 / 配置类路径、以及含无法解析配置占位（`${URL_CONFIG.domains.x}`）的地址。
- `{level}` 取值按音质档传 `standard` / `exhigh` / `lossless`（与内置 fish 链路同一套），可在描述 JSON 的
  `levelTokens` 里改。
- 自校验加强：拼出来的描述必须能解析、且平台数与落盘条目数一致（旧实现多平台时会少拼一个花括号，
  被宽松的 JSON 解析掩盖，导致只生效第一个平台）。
- 失败提示分开：`.json` 缺 `urlTemplates` → 「描述里没有可用的取流模板…」；`.js` 提取不到 →
  「该 .js 脚本属「运行时装接口型」…」。

**复验（见 `docs/复验记录-1.1.6.md`）**

- JVM：`SourceStoreCheck` 22/22（新增 9 项真实脚本形态用例）、`JvmVerify` 29/29、`QqApiCheck` 6/6、
  `FishApiCheck` 6/6、`SourceFlowCheck` 通过（切到导入音源后取流确实先走它，切回内置不残留）。
- 设备（Android 4.4.2 无头模拟器）：覆盖安装 1.1.5 → 1.1.6 `Success`（versionCode 17、同一把签名）；
  地址导入真实在线脚本成功（`音源导入成功 => 全豆要[聚合音源] v9.3 平台=tx/kg/kw/wy/mg`）；
  无模板 `.js` 与无 `urlTemplates` 的 `.json` 各自给出新提示；切成导入音源后 `active_source` 落盘；
  播放时线路诊断显示导入音源的模板线路排在最前，取不到自动回退到可用平台线路并正常出声，FATAL / ANR 0。

**如实说明**

不是所有 `.js` 都能在端上生效：`fish_music`、`juhe`、`lx`、`sixyin` 这类属「运行时装接口型 / 混淆型」，
要按脚本逻辑联网请求接口才算得出地址，端上不跑 JS 就提取不到可用模板——这类脚本会明确提示原因，
不再笼统地说「没有模板」。另外 4.4 的系统信任库里没有部分第三方证书链，脚本里的 `https://` 模板线路
可能在 TLS 握手上失败（`Trust anchor for certification path not found`），此时会自动回退；
想让某条模板真正生效，可在描述 JSON 里把它换成该服务的 http 地址（这些第三方中转大多同时提供 http）。

## 十三、变更记录（1.1.6 → 1.1.7）：设置页音源入口摆到明面 + 歌词提前量默认「不提前」

**改了什么**

- 设置页第 3 行 `当前音源` → **`内置 / 导入音源切换`**，行值标出身份与数量：
  `内置音源 fish_music v1.9.0（按 OK 切换，共 4 个：内置 1 / 导入 3）` / `导入音源 全豆要[聚合音源] v9.3（…）`；
  切换后的提示与日志同样写明「内置音源 / 导入音源」（例如 `切换音源 => 导入音源 我的测试音源 v1.0 平台=tx/kw`），
  落盘 `active_source`、重启保持、点回内置有效。
- 设置页第 4 行 `音源导入` → **`导入在线音源`**，行值写明支持的两类模板：
  `按 OK 导入 .json 描述 / .js 脚本（在线地址或本地目录）`；对话框标题改为「导入在线音源」，
  输入框提示「音源地址（.json 描述 / .js 脚本）」，说明文案写清在线导入与本地扫描两条路径、`.json` 与 `.js` 的差别。
- 「歌词提前量」初始默认 `500ms`（提前 0.5 秒）→ **`0ms`（不提前）**；新增一次性迁移：
  落盘值仍是旧默认 0.5 秒的机器升级后迁移为「不提前」，用户自己调过的档位（含延后档、0.25/0.75 秒等）保持不动；
  设置页行值与底部说明同步为「默认不提前」。

**复验（见 `docs/复验记录-1.1.7.md`，改动清单见 `docs/改动清单-1.1.7.md`）**

- JVM：`JvmVerify` 29/29、`SourceStoreCheck` 22/22、`QqApiCheck` 6/6、`FishApiCheck` 6/6、`SourceFlowCheck` 通过。
- 设备（Android 4.4.2 无头模拟器）：用户上传的 1.1.4 → 1.1.7 覆盖安装 `Success`（versionCode 18、同一把签名）；
  清数据启动与旧默认值迁移都显示「不提前」、自调档位不受影响、逐档仍可调（`歌词提前量 => 250ms`）；
  在线地址导入 `.json` 与真实 `.js` 均成功（`音源导入成功 => 我的测试音源 v1.0 平台=tx/kw`、
  `=> 全豆要[聚合音源] v9.3 平台=tx/kg/kw/wy/mg`），无模板 `.js` 与缺 `urlTemplates` 的 `.json` 各自给出新提示；
  切成导入音源后线路诊断显示其模板线路排在最前，取出真音频（`HTTP 200 · audio/mpeg · 已验真为音频`）并正常播放，
  第三方中转不可达时自动回退仍出声；全程 `FATAL / ANR` 为 0。

## 十四、变更记录（1.1.7 → 1.1.8）：端上内置 JS 引擎，接口型脚本能真跑

**改了什么**

- 新增 `native/`：QuickJS（2024-01-13，MIT）经 NDK 交叉编译成 `libqjs.so`（x86 / armeabi-v7a / arm64-v8a，
  各约 0.6 MB），JNI 胶水 `native/qjs_jni.c` 只暴露 `nNew / nEval / nCall / nWait / nFree` 五个出入口；
  `build.sh` 出包时会把这些库打进 `lib/<abi>/`（4.4 安装时自动解压到 app-lib）。
- 新增 `assets/js/lx-host.js`：JS 侧 lx 宿主（request/on/send/utils/console/setTimeout + 事件循环支撑），
  Java 侧 `JsHost` 实现日志、HTTP、AES/散列/base64 等宿主能力；`JsEngine` 负责「导入试跑」与「取流会话」
  （专用引擎线程、超时、结果缓存、失败记忆、LRU 会话）。
- `SourceStore` / `LxSource`：描述新增 `runner` 字段；`runner=quickjs` 且声明平台的条目按「引擎执行型」判定可用；
  导入失败时的原因分类更细（描述缺模板 / 引擎跑不通：接口状态 / 脚本报错 / 脚本拒绝客户端）。
- `PlayResolver`：新增「脚本音源线路（引擎执行）」，排在模板线路之后、平台线路之前，沿用 2KB 验真与回退；
  诊断里显示脚本用时与脚本给出的失败原因。
- 设置页：「导入在线音源」对话框说明改为「端上已内置 JS 引擎」；「内置 / 导入音源切换」里引擎执行型音源显示为
  `名字 vX（引擎执行）`；切换音源时清掉引擎会话缓存。

**复验（见 `docs/复验记录-1.1.8.md`）**

- JVM：`SourceStoreCheck` 26/26（含 4 项引擎执行型用例）、`SourceFlowCheck`（含引擎不可用时的降级回退）、
  `JvmVerify` 29/29、`QqApiCheck` 6/6、`FishApiCheck` 6/6。
- 设备（Android 4.4.2 无头模拟器）：覆盖安装 1.1.7 → 1.1.8 `Success`（versionCode 19、同一把签名）；
  导入接口型脚本得到 `音源导入成功 => 本地接口测试音源 v1.0（引擎执行） 平台=tx`、
  `=> GDStudio接口音源 v1.0（引擎执行） 平台=wy`；播放诊断显示引擎线路命中真音频
  （`HTTP 200/206 · audio/mpeg · 已验真为音频`）并正常出声；juhe（接口 429）、lx / sixyin（缺 API / 拒绝客户端）
  各自给出准确原因；内置与模板型音源、歌词默认「不提前」、音源切换均无回归；`FATAL / ANR` 为 0。

**如实说明**

- 混淆型脚本可能仍跑不通（依赖超出 LX 公开能力的自研 API 或校验客户端指纹），此时会给出准确报错。
- 引擎执行型脚本能否取到流取决于第三方接口当时是否可用（juhe 的接口对我们返回 429）。
- armeabi-v7a / arm64-v8a 的引擎库只做了编译与导出符号检查（本机只有 x86 模拟器镜像，未做真机运行验证）。

## 十五、变更记录（1.1.8 → 1.1.9）：播放缓存自动清理 + 缓存上限

**改了什么**（`src/com/freemusic/tv/MusicPlayer.java`）

- **播完自动清理**：`onCompletion` 在推进下一首之前删掉刚播完的本地缓存（单曲循环保留，要重放）。
- **切歌 / 停止 / 失败也回收**：`playIndex()`、`playList()`、`stopAndRelease()` 回收上一首那份；
  下载完成时用户已切歌则当场删掉刚下完的文件；本地文件播放失败时删掉这份坏缓存。
- **缓存上限**：每次下载前修剪 `cacheDir` 下 `stream_*`——总量上限 40 MB、文件数上限 6 个，超出按最旧先删，
  并清理异常退出残留的 `*.part`；正在播放 / 正在下载的那份绝不删。
- 日志：`缓存清理 => 删除 …`、`缓存修剪 => 删 N 个（释放 X MB），剩余 M 个/Y MB，上限 40MB / 6 个`。

**复验（见 `docs/复验记录-1.1.9.md`）**

- 基线：改动前模拟器上 4 个 `stream_*` 文件已占 **38.8 MB** 且从不回收。
- 上机：8 秒测试曲播完即删（逐首日志）；投放 11 个文件 / 74.9 MB 后播放触发
  `缓存修剪 => 删 5 个（释放 38MB），剩余 6 个/36MB`；直接流式播放不产生缓存、切歌回收旧文件；
  `FATAL / ANR` 为 0。
- JVM：`JvmVerify` 29/29、`SourceStoreCheck` 26/26、`QqApiCheck` 6/6、`FishApiCheck` 6/6、`SourceFlowCheck` 通过。
- 版本：versionCode 20 / 1.1.9，同一把签名，1.1.8 → 1.1.9 覆盖安装 `Success`。

## 十六、变更记录（1.1.9 → 1.2.0）：端上宿主补上 `lx.currentScriptInfo` + 失败提示可定位

**改了什么**

- `assets/js/lx-host.js`：给脚本补上 LX 的 **`lx.currentScriptInfo`**（`name` / `description` / `version` /
  `author` / `homepage` / `rawScript` / `rawScriptPath` / `source`），值来自 Java 侧注入的
  `globalThis.__lxScriptMeta`，注入缺失时整体兜底成空串；并给 `lx` 套一层代理记录**脚本读过但宿主没有的接口**。
- `JsEngine.java`：装载顺序改为「元信息 → 宿主胶水 → 脚本」；头部注释解析改成整行取值（`@homepage` 这类带
  `://` 的字段不再被截断）；失败原因补上 `（出错位置 文件:行:列）` 与 `脚本读取了宿主未提供的接口：lx.xxx`；
  `probe(sourceUrl)` / `sessionFor(key, script, metaJson)` 把导入来源与元信息一路带到取流会话。
- `PlayResolver.java` / `MainActivity.java`：引擎执行型取流会话与导入流程都带上元信息与来源。
- `JsHost.java`：`quote()` 增加 U+2028 / U+2029 转义（把脚本原文嵌进 JS 字面量时不会写出断行）。
- 新增 JVM 侧检查 `tools/jvm_verify/LxHostCheck.java`；`versionCode 21` / `versionName 1.2.0`，
  三 ABI 引擎库与 1.1.9 逐字节一致（本轮未改原生代码）。

**复验（见 `docs/复验记录-1.2.0.md`）**

- 真引擎（与端上同一份 QuickJS 源码）：补上 `currentScriptInfo` 后 `lx/latest.js` 脚本 `inited` 成功
  （平台 kw/kg/tx/wy/mg）；缺接口脚本的报错被 `__lxMissingText()` 记下。
- 上机（Android 4.4.2 无头模拟器）：覆盖安装 1.1.9 → 1.2.0 `Success`（versionCode 21、同一把签名）；
  导入该在线脚本得到 `音源导入成功 => 独家音源 v7（引擎执行） 平台=kw/kg/tx/wy/mg/local`；
  导入失败提示带出错位置与缺失接口；切到导入音源后播放正常出声（脚本引擎逐个平台真跑脚本取流，
  第三方 HTTPS 受限时自动回退平台线路），`FATAL / ANR` 为 0。
- JVM：`LxHostCheck` 22/22、`SourceStoreCheck` 26/26、`JvmVerify` 29/29、`QqApiCheck` 6/6、
  `FishApiCheck` 6/6、`KwApiCheck` 3/4（酷我官方明文歌词接口偶发返回空，既有已知项）、`SourceFlowCheck` 通过。
