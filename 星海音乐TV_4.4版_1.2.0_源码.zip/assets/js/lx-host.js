/*
 * lx 宿主胶水（端上 JS 引擎用）
 *
 * 运行在端上的 QuickJS 里，作用是把音源脚本需要的 `globalThis.lx` 桥接到 Java 侧，
 * 并把「等脚本初始化完成」「按歌取流」暴露成 native 侧可以轮询的接口。
 *
 * 协议约定（与 Java 侧 JsEngine / JsHost 对齐）：
 *   * Java -> JS：__nativeHostCall(name, argsJson) -> String（日志 / HTTP / utils 都在 Java 里实现）
 *   * JS -> native 的事件循环支撑：__enginePumpTimers / __engineAwait*（由 native 的等待循环驱动）
 *   * 取流：Java 先调 __lxMusicUrl(payloadJson) 发起，再轮询 __lxUrlDone()，最后读 __lxUrlResult() / __lxUrlError()
 */
(function () {
  var g = globalThis;
  var EVENT = { request: 'request', inited: 'inited', updateAlert: 'updateAlert' };
  var handlers = {};
  var initedData = null;
  var logs = [];

  function host(name, args) {
    try {
      return __nativeHostCall(name, JSON.stringify(args === undefined ? {} : args));
    } catch (e) {
      return null;
    }
  }

  function parseMaybe(text) {
    if (typeof text !== 'string' || !text.length) return null;
    try { return JSON.parse(text); } catch (e) { return null; }
  }

  // ---------- console ----------
  function logLine(args, level) {
    var parts = [];
    for (var i = 0; i < args.length; i++) {
      var v = args[i];
      if (typeof v === 'string') {
        parts.push(v);
      } else {
        try { parts.push(JSON.stringify(v)); } catch (e) { parts.push(String(v)); }
      }
    }
    var line = parts.join(' ');
    if (logs.length < 40) logs.push(line);
    host('log', { level: level || 'info', msg: line });
  }
  if (typeof g.console === 'undefined') g.console = {};
  g.console.log = function () { logLine(arguments, 'info'); };
  g.console.info = g.console.log;
  g.console.debug = g.console.log;
  g.console.warn = function () { logLine(arguments, 'warn'); };
  g.console.error = function () { logLine(arguments, 'error'); };
  g.console.group = function () { };
  g.console.groupEnd = function () { };

  // ---------- 定时器（由 native 的等待循环泵动） ----------
  var timers = [];
  var timerSeq = 1;
  g.setTimeout = function (fn, ms) {
    var id = timerSeq++;
    timers.push({ id: id, fn: fn, at: Date.now() + (ms || 0) });
    return id;
  };
  g.clearTimeout = function (id) {
    for (var i = 0; i < timers.length; i++) if (timers[i].id === id) { timers.splice(i, 1); return; }
  };
  g.__enginePumpTimers = function () {
    var now = Date.now(), next = -1, due = [], i, d;
    for (i = timers.length - 1; i >= 0; i--) {
      if (timers[i].at <= now) { due.push(timers[i]); timers.splice(i, 1); }
      else { d = timers[i].at - now; if (next < 0 || d < next) next = d; }
    }
    for (i = 0; i < due.length; i++) { try { due[i].fn(); } catch (e) { } }
    return next;
  };

  // ---------- Promise 收尾（native 调 __engineAwait 托管，再轮询 __engineAwaitDone） ----------
  var awaitState = { pending: false, ok: false, value: null, error: null };
  g.__engineAwait = function (promise) {
    awaitState.pending = true; awaitState.ok = false; awaitState.value = null; awaitState.error = null;
    Promise.resolve(promise).then(
      function (v) { awaitState.pending = false; awaitState.ok = true; awaitState.value = v; },
      function (e) { awaitState.pending = false; awaitState.ok = false; awaitState.error = String((e && e.stack) || e); }
    );
    return true;
  };
  g.__engineAwaitDone = function () { return !awaitState.pending; };
  g.__engineAwaitResult = function () { return awaitState.value; };
  g.__engineAwaitError = function () { return awaitState.error; };

  // ---------- lx 本体 ----------
  function lxRequest(url, options, callback) {
    var opt = options || {};
    var raw = host('request', {
      url: url,
      method: opt.method || 'GET',
      headers: opt.headers || {},
      body: opt.body === undefined ? null : opt.body,
      timeoutMs: opt.timeoutMs || 15000
    });
    var parsed = parseMaybe(raw);
    var resp = null;
    var body = null;
    lastRequest.url = String(url);
    lastRequest.statusCode = parsed ? (parsed.statusCode || 0) : 0;
    lastRequest.error = (parsed && parsed.error) ? String(parsed.error) : '';
    lastRequest.snippet = (parsed && typeof parsed.bodyText === 'string') ? parsed.bodyText.substring(0, 160) : '';
    if (parsed && !parsed.error) {
      body = (parsed.bodyJson !== undefined && parsed.bodyJson !== null) ? parsed.bodyJson : parsed.bodyText;
      resp = { statusCode: parsed.statusCode || 0, headers: parsed.headers || {}, body: body };
    }
    if (typeof callback === 'function') {
      if (!resp) {
        callback(new Error((parsed && parsed.error) ? parsed.error : 'request failed'));
      } else {
        callback(null, resp, body);
      }
      return;
    }
    return new Promise(function (resolve, reject) {
      if (resp) resolve(resp); else reject(new Error((parsed && parsed.error) ? parsed.error : 'request failed'));
    });
  }

  var lastRequest = { url: '', statusCode: 0, snippet: '', error: '' };

  var lx = {
    version: '2.11.0',
    env: 'desktop',
    EVENT_NAMES: EVENT,
    on: function (name, handler) { handlers[name] = handler; },
    send: function (name, data) {
      if (name === EVENT.inited) initedData = data;
      host('event', { name: name, data: data === undefined ? null : data });
      return true;
    },
    request: lxRequest,
    utils: {}
  };
  var TOOLS = ['md5', 'sha1', 'sha256', 'base64Encode', 'base64Decode', 'randomBytes', 'str2b64', 'b642str', 'toHex'];
  for (var t = 0; t < TOOLS.length; t++) {
    (function (name) {
      lx.utils[name] = function () {
        var args = [];
        for (var i = 0; i < arguments.length; i++) args.push(arguments[i]);
        var raw = host('util', { name: name, args: args });
        var out = parseMaybe(raw);
        if (out && out.value !== undefined) return out.value;
        return out === null ? raw : out;
      };
    })(TOOLS[t]);
  }

  // ---------- utils.crypto / utils.buffer（LX 脚本常用，缺了会直接报 cannot read property） ----------
  function toU8(v) {
    if (v instanceof Uint8Array) return v;
    if (typeof v === 'string') return strToU8(v);
    if (v && v.length !== undefined && typeof v !== 'string') {
      var out = new Uint8Array(v.length);
      for (var i = 0; i < v.length; i++) out[i] = v[i] & 0xFF;
      return out;
    }
    if (v && v.buffer) return new Uint8Array(v.buffer);
    return new Uint8Array(0);
  }
  function strToU8(str) {
    var utf8 = unescape(encodeURIComponent(String(str)));
    var out = new Uint8Array(utf8.length);
    for (var i = 0; i < utf8.length; i++) out[i] = utf8.charCodeAt(i) & 0xFF;
    return out;
  }
  function u8ToStr(u8) {
    var s = '';
    for (var i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i] & 0xFF);
    return decodeURIComponent(escape(s));
  }
  function u8ToB64(u8) {
    var s = '';
    for (var i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i] & 0xFF);
    return lx.utils.base64Encode(s);
  }
  function b64ToU8(b64) {
    var s = lx.utils.base64Decode(String(b64));
    var out = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) out[i] = s.charCodeAt(i) & 0xFF;
    return out;
  }
  lx.utils.buffer = {
    from: function (input, encoding) {
      if (encoding === 'base64') return b64ToU8(input);
      if (encoding === 'hex') {
        var out = new Uint8Array(Math.floor(String(input).length / 2));
        for (var i = 0; i < out.length; i++) out[i] = parseInt(String(input).substr(i * 2, 2), 16);
        return out;
      }
      return toU8(input);
    },
    bufToString: function (buf, encoding) {
      var u8 = toU8(buf);
      if (encoding === 'base64') return u8ToB64(u8);
      if (encoding === 'hex') {
        var h = '';
        for (var i = 0; i < u8.length; i++) h += (u8[i] < 16 ? '0' : '') + u8[i].toString(16);
        return h;
      }
      return u8ToStr(u8);
    },
    concat: function (list) {
      var total = 0, i;
      for (i = 0; i < list.length; i++) total += toU8(list[i]).length;
      var out = new Uint8Array(total), off = 0;
      for (i = 0; i < list.length; i++) { var u = toU8(list[i]); out.set(u, off); off += u.length; }
      return out;
    },
    slice: function (buf, start, end) { return toU8(buf).slice(start, end); }
  };
  lx.utils.crypto = {
    md5: function (str) { return lx.utils.md5(str); },
    sha1: function (str) { return lx.utils.sha1(str); },
    sha256: function (str) { return lx.utils.sha256(str); },
    randomBytes: function (size) { return b64ToU8(lx.utils.randomBytes(size || 16)); },
    aesEncrypt: function (buffer, mode, key, iv) {
      var raw = host('util', { name: 'aes', op: 'encrypt', data: u8ToB64(toU8(buffer)), mode: mode,
        key: u8ToB64(toU8(key)), iv: iv === undefined || iv === null ? '' : u8ToB64(toU8(iv)) });
      var out = parseMaybe(raw);
      if (!out || !out.value) throw new Error('aesEncrypt failed');
      return b64ToU8(out.value);
    },
    aesDecrypt: function (buffer, mode, key, iv) {
      var raw = host('util', { name: 'aes', op: 'decrypt', data: u8ToB64(toU8(buffer)), mode: mode,
        key: u8ToB64(toU8(key)), iv: iv === undefined || iv === null ? '' : u8ToB64(toU8(iv)) });
      var out = parseMaybe(raw);
      if (!out || !out.value) throw new Error('aesDecrypt failed');
      return b64ToU8(out.value);
    }
  };

  // ---------- currentScriptInfo（LX 的「当前脚本信息」） ----------
  // LX 的宿主会给每个脚本一份 currentScriptInfo：脚本头部注释解析出来的元信息 + 脚本原文。
  // 脚本常用它判断版本/来源，例如 lx.currentScriptInfo.version（缺了会直接报 cannot read property）。
  // Java 侧在装载脚本前先执行 globalThis.__lxScriptMeta = {...}；这里读不到就整体兜底成空串。
  var meta = null;
  try {
    meta = (g.__lxScriptMeta && typeof g.__lxScriptMeta === 'object') ? g.__lxScriptMeta : null;
  } catch (e) {
    meta = null;
  }
  function metaStr(k) {
    try {
      var v = meta ? meta[k] : null;
      return typeof v === 'string' ? v : '';
    } catch (e) {
      return '';
    }
  }
  lx.currentScriptInfo = {
    name: metaStr('name'),
    description: metaStr('description'),
    version: metaStr('version'),
    author: metaStr('author'),
    homepage: metaStr('homepage'),
    rawScript: metaStr('rawScript'),
    rawScriptPath: metaStr('rawScriptPath'),
    source: metaStr('source')
  };

  // ---------- 宿主接口缺失记录 ----------
  // 脚本读了 lx 上不存在的成员（老宿主没提供的接口）时记一笔；导入失败时由 Java 侧一并说明，
  // 让「端上跑不通」能定位到缺哪个接口，而不是只丢一句 cannot read property。
  var lxMissing = [];
  function lxWrap(target) {
    if (typeof Proxy !== 'function') {
      return target;
    }
    try {
      return new Proxy(target, {
        get: function (t, k) {
          var v = t[k];
          if (v === undefined && typeof k === 'string' && !Object.prototype.hasOwnProperty.call(t, k)) {
            if (lxMissing.indexOf(k) < 0 && lxMissing.length < 32) {
              lxMissing.push(k);
            }
          }
          return v;
        },
        has: function (t, k) { return k in t; },
        set: function (t, k, v) { t[k] = v; return true; },
        ownKeys: function (t) { return Object.keys(t); },
        getOwnPropertyDescriptor: function (t, k) { return Object.getOwnPropertyDescriptor(t, k); }
      });
    } catch (e) {
      return target;
    }
  }

  g.lx = lxWrap(lx);
  g.__lxMissingText = function () {
    try { return lxMissing.join(','); } catch (e) { return ''; }
  };

  // ---------- 供 native 轮询 / 读取的入口 ----------
  g.__lxInited = function () { return !!initedData; };
  g.__lxSourcesJson = function () {
    var s = (initedData && initedData.sources) ? initedData.sources : null;
    try { return JSON.stringify(s || {}); } catch (e) { return '{}'; }
  };
  g.__lxLogsJson = function () { try { return JSON.stringify(logs); } catch (e) { return '[]'; } };
  g.__lxLastRequestJson = function () {
    try { return JSON.stringify(lastRequest); } catch (e) { return '{}'; }
  };

  // ---------- 按歌取流：先发起，再由 native 轮询 __lxUrlDone ----------
  var urlState = { pending: false, url: '', error: '' };
  g.__lxMusicUrl = function (payloadJson) {
    var p = parseMaybe(payloadJson) || {};
    var fn = handlers[EVENT.request];
    urlState.pending = true; urlState.url = ''; urlState.error = '';
    if (typeof fn !== 'function') {
      urlState.pending = false;
      urlState.error = '脚本没有注册取流处理器';
      return true;
    }
    var info = { type: p.quality, musicInfo: p.music || {} };
    function finish(v) {
      urlState.pending = false;
      if (typeof v === 'string') urlState.url = v;
      else if (v && typeof v.url === 'string') urlState.url = v.url;
      else urlState.url = '';
      if (!urlState.url) urlState.error = '脚本没有返回播放地址';
    }
    function fail(e) {
      urlState.pending = false;
      urlState.error = String((e && e.stack) || e);
    }
    try {
      var ret = fn({ action: 'musicUrl', source: p.source, info: info });
      Promise.resolve(ret).then(finish, fail);
    } catch (e) {
      fail(e);
    }
    return true;
  };
  g.__lxUrlDone = function () { return !urlState.pending; };
  g.__lxUrlResult = function () { return urlState.url; };
  g.__lxUrlError = function () { return urlState.error; };
})();