#!/usr/bin/env bash
#
# 星海音乐TV（Android 4.4 / API 19 电视端）一键构建脚本
#
# 特点：在默认未预装 Android SDK / Gradle 的环境（含云端沙箱）里也能直接出包。
#   * 工具链缺失时自动从国内镜像下载 JDK、build-tools、API 19 平台包
#   * 不使用 Gradle / AGP，手工串联 javac -> aapt2 -> d8 -> zipalign -> apksigner
#   * 用 API 19 的 android.jar 作为编译期约束：任何 >API19 的调用会直接编译失败
#   * 内置音源脚本每次构建都从官方地址取（GitHub 直连不可达时走镜像），再固化出行为描述文件
#
# 用法：
#   ./build.sh                # 自动准备工具链并出包
#   FETCH_ONLY=1 ./build.sh   # 只准备工具链
#   TOOLCHAIN_DIR=/opt/tc ./build.sh
#   JAVA_HOME=... BUILD_TOOLS=... ANDROID_JAR=... ./build.sh   # 使用已有工具链
#   LX_SOURCE_URL=<音源脚本地址> ./build.sh                    # 换用别的音源脚本地址
#
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
TOOLCHAIN_DIR="${TOOLCHAIN_DIR:-$ROOT/toolchain}"
BUILD_DIR="$ROOT/build"
SRC_DIR="$ROOT/src"
RES_DIR="$ROOT/res"
MANIFEST="$ROOT/AndroidManifest.xml"
OUT_APK_NAME="${OUT_APK_NAME:-star-music-tv-1.0.6.apk}"

# 内置音源接口（lx-music-source 脚本）的官方地址
LX_SOURCE_URL="${LX_SOURCE_URL:-https://raw.githubusercontent.com/pdone/lx-music-source/main/fish/latest.js}"

JDK_URL="https://mirrors.huaweicloud.com/openjdk/11.0.2/openjdk-11.0.2_linux-x64_bin.tar.gz"
BUILD_TOOLS_URL="https://mirrors.cloud.tencent.com/AndroidSDK/build-tools_r30.0.3-linux.zip"
PLATFORM_URL="https://dl.google.com/android/repository/android-19_r04.zip"

log() { printf '\033[1;34m[build]\033[0m %s\n' "$*"; }
die() { printf '\033[1;31m[build]\033[0m %s\n' "$*" >&2; exit 1; }

fetch() {
  local url="$1" dst="$2"
  if [ -s "$dst" ]; then
    log "已存在 $(basename "$dst")，跳过下载"
    return 0
  fi
  log "下载 $url"
  if command -v curl >/dev/null 2>&1; then
    curl -fL --retry 3 --connect-timeout 20 -o "$dst.part" "$url" || die "下载失败：$url"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$dst.part" "$url" || die "下载失败：$url"
  else
    die "环境里没有 curl / wget，无法自动下载工具链"
  fi
  mv "$dst.part" "$dst"
}

ensure_toolchain() {
  if [ -n "${JAVA_HOME:-}" ] && [ -n "${BUILD_TOOLS:-}" ] && [ -n "${ANDROID_JAR:-}" ]; then
    log "使用环境变量指定的工具链"
    return 0
  fi
  mkdir -p "$TOOLCHAIN_DIR"
  if [ ! -x "$TOOLCHAIN_DIR/jdk/bin/javac" ]; then
    fetch "$JDK_URL" "$TOOLCHAIN_DIR/jdk.tar.gz"
    log "解压 JDK"
    mkdir -p "$TOOLCHAIN_DIR/jdk_extract"
    tar xzf "$TOOLCHAIN_DIR/jdk.tar.gz" -C "$TOOLCHAIN_DIR/jdk_extract"
    local jdk_root
    jdk_root="$(find "$TOOLCHAIN_DIR/jdk_extract" -maxdepth 3 -type f -name javac -path '*/bin/*' | head -1)"
    [ -n "$jdk_root" ] || die "JDK 解压后找不到 javac"
    ln -sfn "$(dirname "$(dirname "$jdk_root")")" "$TOOLCHAIN_DIR/jdk"
  fi
  if [ ! -x "$TOOLCHAIN_DIR/build-tools/aapt2" ]; then
    fetch "$BUILD_TOOLS_URL" "$TOOLCHAIN_DIR/build-tools.zip"
    log "解压 build-tools"
    rm -rf "$TOOLCHAIN_DIR/bt_extract"
    mkdir -p "$TOOLCHAIN_DIR/bt_extract"
    unzip -q -o "$TOOLCHAIN_DIR/build-tools.zip" -d "$TOOLCHAIN_DIR/bt_extract"
    local bt
    bt="$(find "$TOOLCHAIN_DIR/bt_extract" -maxdepth 3 -type f -name aapt2 | head -1)"
    [ -n "$bt" ] || die "build-tools 解压后找不到 aapt2"
    ln -sfn "$(dirname "$bt")" "$TOOLCHAIN_DIR/build-tools"
  fi
  if [ ! -f "$TOOLCHAIN_DIR/android-19/android.jar" ]; then
    fetch "$PLATFORM_URL" "$TOOLCHAIN_DIR/platform.zip"
    log "解压 API 19 平台包"
    rm -rf "$TOOLCHAIN_DIR/platform"
    mkdir -p "$TOOLCHAIN_DIR/platform"
    unzip -q -o "$TOOLCHAIN_DIR/platform.zip" -d "$TOOLCHAIN_DIR/platform"
    local jar
    jar="$(find "$TOOLCHAIN_DIR/platform" -maxdepth 3 -type f -name android.jar | head -1)"
    [ -n "$jar" ] || die "平台包解压后找不到 android.jar"
    ln -sfn "$(dirname "$jar")" "$TOOLCHAIN_DIR/android-19"
  fi

  export JAVA_HOME="$TOOLCHAIN_DIR/jdk"
  export BUILD_TOOLS="$TOOLCHAIN_DIR/build-tools"
  export ANDROID_JAR="$TOOLCHAIN_DIR/android-19/android.jar"
}

ensure_toolchain
[ "${FETCH_ONLY:-0}" = "1" ] && { log "工具链就绪：$TOOLCHAIN_DIR"; exit 0; }

export PATH="$JAVA_HOME/bin:$BUILD_TOOLS:$PATH"
export JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF-8"

for f in "$BUILD_TOOLS/aapt2" "$BUILD_TOOLS/d8" "$BUILD_TOOLS/zipalign" "$BUILD_TOOLS/apksigner" "$JAVA_HOME/bin/javac"; do
  [ -x "$f" ] || command -v "$(basename "$f")" >/dev/null 2>&1 || die "缺少构建工具：$f"
done

log "0/6 布局尺寸自检（Android 4.4 缺 layout_width/height 会直接闪退，必须拦在构建前）"
if command -v python3 >/dev/null 2>&1 && [ -f "$ROOT/tools/check_layouts.py" ]; then
  python3 "$ROOT/tools/check_layouts.py" "$RES_DIR" || die "布局尺寸自检未通过，请按提示补齐 layout_width / layout_height"
else
  log "跳过（未找到 python3 或 tools/check_layouts.py）"
fi

log "0.3/6 内置音源脚本获取（官方地址优先，GitHub 直连不可达时走镜像）"
log "      音源接口：$LX_SOURCE_URL"
LX_SCRIPT="$ROOT/assets/lx_sources/$(basename "${LX_SOURCE_URL%%\?*}")"
if [ "$(basename "$LX_SCRIPT")" = "latest.js" ]; then
  # 形如 .../<脚本名>/latest.js：用上一级目录名当脚本文件名，避免 fetch 脚本按 dirname 归类
  LX_SCRIPT="$ROOT/assets/lx_sources/$(basename "$(dirname "${LX_SOURCE_URL%%\?*}")")-latest.js"
fi
# 注意：必须以环境变量形式传给子脚本，否则 fetch 脚本读不到 LX_SOURCE_URL 会回落到它自己的默认地址
LX_SOURCE_URL="$LX_SOURCE_URL" bash "$ROOT/tools/fetch_lx_source.sh" "$LX_SCRIPT" \
  || die "内置音源脚本获取失败"

log "0.5/6 音源脚本描述文件（构建期真实运行脚本后固化，见 docs/lx-source-integration.md）"
LX_JSON="$ROOT/assets/lx_source.json"
if command -v node >/dev/null 2>&1 && [ -f "$LX_SCRIPT" ]; then
  node "$ROOT/tools/extract_lx_source.js" "$LX_SCRIPT" "$LX_JSON" "$LX_SOURCE_URL" \
    || die "音源脚本描述文件生成失败"
  log "已按 $(basename "$LX_SCRIPT") 重新生成 $(basename "$LX_JSON")"
elif [ -f "$LX_JSON" ]; then
  log "沿用已有 $(basename "$LX_JSON")（未发现 node 或音源脚本）"
else
  die "缺少音源脚本描述文件，且当前环境无法生成"
fi

log "清理旧产物"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/gen" "$BUILD_DIR/classes" "$BUILD_DIR/dex"

log "1/6 aapt2 compile 资源"
"$BUILD_TOOLS/aapt2" compile --dir "$RES_DIR" -o "$BUILD_DIR/res.zip"

log "2/6 aapt2 link 生成资源表与 R.java（含 assets 音源脚本与描述文件）"
"$BUILD_TOOLS/aapt2" link \
  -o "$BUILD_DIR/app-res.apk" \
  -I "$ANDROID_JAR" \
  --manifest "$MANIFEST" \
  --java "$BUILD_DIR/gen" \
  -A "$ROOT/assets" \
  --min-sdk-version 19 \
  --target-sdk-version 19 \
  --auto-add-overlay \
  "$BUILD_DIR/res.zip"

log "3/6 javac 编译 Java 源码（android.jar 走 classpath，保留 JDK 的 LambdaMetafactory）"
"$JAVA_HOME/bin/javac" \
  -source 8 -target 8 \
  -encoding UTF-8 \
  -classpath "$ANDROID_JAR" \
  -d "$BUILD_DIR/classes" \
  $(find "$SRC_DIR" "$BUILD_DIR/gen" -name '*.java')

log "4/6 d8 生成 API 19 的 dex"
"$BUILD_TOOLS/d8" \
  --min-api 19 \
  --lib "$ANDROID_JAR" \
  --output "$BUILD_DIR/dex" \
  $(find "$BUILD_DIR/classes" -name '*.class')

log "5/6 组装 APK 并做 4 字节对齐"
python3 - "$BUILD_DIR" <<'PY'
import os, sys, zipfile
build = sys.argv[1]
src = os.path.join(build, "app-res.apk")
dst = os.path.join(build, "app-unsigned.apk")
dex = os.path.join(build, "dex", "classes.dex")
if not os.path.isfile(dex):
    raise SystemExit("找不到 classes.dex")
zin = zipfile.ZipFile(src, "r")
zout = zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED)
for item in zin.infolist():
    zout.writestr(item, zin.read(item.filename))
zout.write(dex, "classes.dex")
# 引擎库：native/lib/<abi>/libqjs.so -> lib/<abi>/libqjs.so（Android 4.4 安装时自动解压到 app-lib）
libdir = os.path.join(os.path.dirname(build), "native", "lib")
for abi in ("armeabi-v7a", "arm64-v8a", "x86"):
    so = os.path.join(libdir, abi, "libqjs.so")
    if os.path.isfile(so):
        zout.write(so, "lib/%s/libqjs.so" % abi)
        print("已写入 lib/%s/libqjs.so：%d 字节" % (abi, os.path.getsize(so)))
    else:
        print("缺少引擎库：%s（跳过，该 ABI 上将没有脚本引擎）" % so)
zout.close()
zin.close()
print("已写入 classes.dex：%d 字节" % os.path.getsize(dex))
PY
"$BUILD_TOOLS/zipalign" -p -f 4 "$BUILD_DIR/app-unsigned.apk" "$BUILD_DIR/app-aligned.apk"

log "6/6 签名（v1 + v2，兼容 Android 4.4）"
KS="$ROOT/keystore/freemusic.jks"
if [ ! -f "$KS" ]; then
  mkdir -p "$(dirname "$KS")"
  "$JAVA_HOME/bin/keytool" -genkeypair -keystore "$KS" -alias freemusic \
    -keyalg RSA -keysize 2048 -validity 10950 \
    -storepass android -keypass android \
    -dname "CN=XingHai Music TV, O=FreeMusicTV, C=CN" >/dev/null 2>&1
  log "已生成自签名证书：$KS（口令 android）"
fi
"$BUILD_TOOLS/apksigner" sign \
  --ks "$KS" --ks-pass pass:android --key-pass pass:android \
  --min-sdk-version 19 --v1-signing-enabled true --v2-signing-enabled true \
  --out "$BUILD_DIR/$OUT_APK_NAME" \
  "$BUILD_DIR/app-aligned.apk"
"$BUILD_TOOLS/apksigner" verify --min-sdk-version 19 -v "$BUILD_DIR/$OUT_APK_NAME"

log "构建完成：$BUILD_DIR/$OUT_APK_NAME"
ls -lh "$BUILD_DIR/$OUT_APK_NAME"