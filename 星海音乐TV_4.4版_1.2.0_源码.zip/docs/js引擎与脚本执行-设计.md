# 端上脚本执行（QuickJS）· 设计与可行性验证

- 目的：让「运行时装接口型」`.js` 音源脚本在 Android 4.4（API 19）电视端**真正执行**，而不是只做静态提取。
- 结论：可行，已在 4.4.2 无头 x86 模拟器上跑通（引擎加载 → async/await 执行 → lx 事件 → 宿主 HTTP → 结果回传，全程无崩溃）。

## 一、为什么选 QuickJS（而不是 Rhino / 只做静态提取）

工程里此前的约定是「不引入端上 JS 引擎」，导入 `.js` 只做静态提取；本次按需求放开这一约定，

| 方案 | 结论 |
| --- | --- |
| 只做静态提取（现状） | 接口型/混淆型脚本都跑不了，无法满足「修复」诉求 |
| Rhino（纯 Java） | 4.4 上可用，但只支持 ES5 语法：脚本里的 `async/await`、部分 ES6+ 写法解析不了，需在端上做 Babel 转译（Babel 本身又是几 MB 的 JS，还得先有一个能跑它的引擎）；历史工程（changqing-musictv）正是走「构建期 Babel 转 ES5 + Rhino 1.7.10」，**只能覆盖随包固化的脚本，覆盖不了用户运行时导入的任意脚本** |
| **QuickJS（C，NDK 编译成 .so）** | 原生支持 ES2020（async/await、Promise、可选链等），脚本可**原样执行**，体积可控（单 ABI 约 0.6 MB），API 19 目标干净 |

因此本轮引入 QuickJS：脚本不再需要转译，任意导入的接口型脚本都有机会直接跑。

## 二、构成

```
native/qjs_jni.c        JNI 胶水（唯一 native 出入口：nNew / nEval / nCall / nFree + 宿主回调）
native/build_qjs.sh     用 Android NDK 交叉编译 libqjs.so（x86 / armeabi-v7a / arm64-v8a）
native/lib/<abi>/libqjs.so   预编译好的引擎库（随包分发）
assets/js/lx-host.js    JS 侧宿主胶水：把 lx.request/on/send、console、setTimeout 等桥到 Java
```

- 引擎版本：QuickJS **2024-01-13**（含 bignum，`CONFIG_BIGNUM`）。
- 工具链：Android NDK r21e（clang 9），`i686-linux-android19-clang` / `armv7a-linux-androideabi19-clang` /
  `aarch64-linux-android21-clang`。
- 编译要点：`-Os -DNDEBUG -fPIC -ffunction-sections -fdata-sections -fvisibility=hidden`，
  链接 `-Wl,--gc-sections -Wl,-s -lm -llog`；不链接 `quickjs-libc`（std/os 模块用不到）。
- 体积：x86 **611852** / armeabi-v7a **628296** / arm64-v8a **599928** 字节（合计约 1.8 MB，进 APK 后压缩约 0.9 MB）。

## 三、native 出入口与 Java 约定

| native | 说明 |
| --- | --- |
| `nNew(memLimit, stackLimit, Class hostCls)` | 建 Runtime+Context，装 `__nativeHostCall`，设置内存/栈上限与超时中断；`hostCls` 用于绑定宿主静态方法 |
| `nEval(handle, code, fname, timeoutMs)` | 执行脚本；结果统一按 `{"ok":true,"value":…}` / `{"ok":false,"error":"…"}` 返回 |
| `nCall(handle, func, argJson, timeoutMs)` | 调全局函数（一个字符串参数） |
| `nFree(handle)` | 释放 |

- **线程**：Runtime/Context 不是线程安全的 → Java 侧固定在一条专用引擎线程上串行使用。
- **超时**：`JS_SetInterruptHandler` + 每次调用传入 deadline，脚本卡死会被中断而不是拖死应用。
- **隔离**：所有异常都转成 JSON 文本，不跨 JNI 抛 Java 异常；脚本报错不会带崩进程。

## 四、踩到并解决的两个坑

1. **Dalvik 上不能在 native 线程里 `FindClass`**：直接在 JNI 里 `FindClass("com/freemusic/tv/JsHost")`
   在 4.4（CheckJNI 开启）下触发 VM abort（`dvmDumpNativeStack` + `VM aborting`）。
   → 改为由 Java 侧把 `JsHost.class` 传进 `nNew`，native 只做 `NewGlobalRef` + `GetStaticMethodID`。
2. **Promise 收尾的事件循环顺序**：脚本处理器普遍是 `async`，直接拿到的是 Promise。
   → native 侧统一把结果交给胶水的 `__engineAwait` 托管，然后循环「先放行到期定时器（`__enginePumpTimers`）→
   再泵微任务（`JS_ExecutePendingJob`）→ 看是否落定」；顺序反了会在定时器 resolve 之后少泵一次微任务，
   结果永远读到空值。

## 五、可行性验证（4.4.2 无头 x86 模拟器）

探针 APK（包名 `com.freemusic.tv.probe`，与主应用同包类名以便复用 JNI 符号）在模拟器上运行一段含
async/await、setTimeout、lx 事件、宿主 HTTP 的脚本，`logcat -s QjsProbe` 实际输出：

```
结果: engine=ok newMs=19 hostEvalMs=100 {"ok":true,"value":null}
 scriptEvalMs=92 {"ok":true,"value":null}
 diag={"ok":true,"value":{"engineAwait":"function","awaitDone":"function","awaitResult":"function","awaitError":"function","pumpTimers":"function","setTimeoutType":"function","lxType":"object"}}
 sync={"ok":true,"value":{"syncOk":"SYNC_OK","n":42}}
 callMs=7979 {"ok":true,"value":{"asyncOk":"ASYNC_OK","invoke":"{\"ok\":true,\"value\":\"ok-from-handler\"}","handlerSeen":{"action":"musicUrl","source":"probe","id":"MID-1"},"sources":{"probe":{"name":"探针源","actions":["musicUrl"],"qualitys":["320k"]}},"http":{"err":null,"status":200,"kind":"string"},"totalMs":7977}}
```

即：引擎 19 ms 建好；`async/await` + `setTimeout` 正常（`ASYNC_OK`）；`lx.on/send` 事件链路正常；
宿主 HTTP 桥回传 `status=200`（取本机 HTTP 上的 1.5 MB MP3，耗时约 8 s 是模拟器网络 + 探针整段读文件所致，
真实接口返回的是小 JSON）；`FATAL`/`VM aborting` 计数为 0。

## 六、已知限制

- 本机模拟器只有 x86 系统镜像，**armeabi-v7a / arm64-v8a 的 .so 只做了编译与导出符号检查，未在真机运行**
  （电视盒子上多是 armeabi-v7a；后续如需更强保证，可用 android-19 的 ARM 系统镜像再验一次）。
- 引擎给脚本的内存上限 64 MB、栈 2 MB、单次调用超时按线路给（见应用侧），避免劣质脚本拖垮盒子。
- 脚本仍受网络与上游接口可用性影响：能跑 ≠ 一定能取到流；取不到仍按既有顺序回退平台线路。