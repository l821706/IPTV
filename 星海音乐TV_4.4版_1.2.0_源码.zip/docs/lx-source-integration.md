# 音源接入设计：内置 lx-music-source 音源脚本

本文记录「把应用内置音源接口指向一份 lx-music-source 脚本」这件事在 Android 4.4（API 19）上的落地方案、
已核实的事实与取舍。

**内置音源接口地址**（1.0.3 起）：

```
https://raw.githubusercontent.com/pdone/lx-music-source/main/changqing/latest.js
```

对应脚本为「长青SVIP音源 v1.3.0」，27,645 字节，
sha256 `6a942987c1e111a113376fbf8ff9fb677c487058f16ce792779c72f69c4ed6de`。
脚本原文随包分发在 `assets/lx_sources/changqing-latest.js`。

## 一、为什么不在电视端直接跑这份 JS

脚本用到的语法/运行时能力（由 `tools/extract_lx_source.js` 实测扫描）：

```
globalThis、箭头函数、const/let、解构赋值、模板字符串、async/await
```

- Android 4.4 的 WebView 是 **Chromium 33（只有 ES5）**，解析不了箭头函数、解构、模板串、async/await；
- 可用版本的 Rhino（≤1.7.10）同样是 ES5，也不具备 ES2015+ 解析能力；
- 4.4 电视盒子普遍没有可用 WebView，把播放能力压在 WebView 上风险过高。

而这批脚本的取流逻辑本身是**纯字符串拼装**（url 模板 + 音质等级 + 平台 id），没有加密、没有二次请求。
因此采用：

> **构建期把脚本真跑一遍 → 把行为固化成描述文件 → 端上按描述文件执行**

行为等价，且完全不依赖任何 JS 引擎；脚本本体仍然随包分发，便于审阅与替换。

## 二、构建期取脚本与固化流程

```
tools/fetch_lx_source.sh     按内置音源接口地址取脚本（官方地址优先，失败时依次尝试
                             jsDelivr / gitmirror / ghproxy 镜像；全失败则沿用仓库里已有脚本）
        ↓ assets/lx_sources/changqing-latest.js
tools/extract_lx_source.js   在 Node 里真实加载该脚本（注入 globalThis.lx），录制其对外能力
        ↓ assets/lx_source.json
build.sh                     把 assets/ 打进 APK（aapt2 link -A assets）
```

构建脚本里对应两步：`0.3/6 内置音源脚本获取`、`0.5/6 音源脚本描述文件`。
可用 `LX_SOURCE_URL=<其它地址> ./build.sh` 临时换源。

## 三、脚本契约（实测得到）

在 Node 中加载脚本并注入 `globalThis.lx` 后，实测到：

| 项 | 实测结果 |
| --- | --- |
| 注册事件 | `on('request')`，随后 `send('inited')` 注册音源 |
| 音源键 | `kg`（酷狗）/ `tx`（QQ音乐）/ `wy`（网易云）/ `kw`（酷我）/ `mg`（咪咕） |
| 提供动作 | 每个音源只有 `musicUrl`（**没有 search**，搜索仍由应用自己的平台接口负责） |
| 音质 | 每个音源 `128k / 320k / flac`，对应 level 参数 `standard / exhigh / lossless` |
| 使用的 id 字段 | `kg` 用 `musicInfo.hash`；`wy`/`kw`/`tx`/`mg` 用 `musicInfo.songmid` |
| 更新检查 | `GET https://13413.kstore.vip/lxmusic/changqing.json`，timeout 3000ms，本地版本 `1.3.0` |

URL 模板（`{id}` 处填入该平台 id）：

```
kg: http://yinyue.haitangw.net/kg/kg_song_kw.php?type=mp3&id={id}&level={level}
tx: http://yinyue.haitangw.net/qq/qq_kw.php?type=mp3&id={id}&level={level}
wy: http://yinyue.haitangw.net/wy/wy.php?type=mp3&id={id}&level={level}
kw: http://yinyue.haitangw.net/kw/kw.php?type=mp3&id={id}&level={level}
mg: http://yinyue.haitangw.net/mg/migu.php?type=mp3&id={id}&level={level}
```

### 更新门禁：实测已失效，端上不实现

脚本原本会在「上游有新版本」时拒绝提供音源，但它的判断条件是：

```js
if (e || t.statusCode !== 99924 + 99724 - 99724) return ...检查更新失败...
```

`99924 + 99724 - 99724 = 99924`，正常 HTTP 响应永远不等于 99924，所以它**每次都走失败分支并照常注册音源**，
即使把上游版本号设成 `9.9.9` 也一样（实测 `blocksWhenOutdated = false`、无 `updateAlert`）。
结论：端上不做版本门禁，描述文件里把这一观察记录下来即可。

### 上游可用性：当前不可用（重要）

用脚本给出的 URL 逐个实测（2026-11-03 19:11，`Range: bytes=0-2047`）：

```
wy / kg / qq / kw 四类 × standard / exhigh / lossless 共 10 条 —— 全部 nginx 404（text/html，548 字节）
域名 yinyue.haitangw.net 可解析（119.36.225.67，走 CDN），但 /wy/ /kg/ /qq/ /kw/ /mg/ 路径均不存在
```

也就是说：**这份脚本目前取不到任何音频**（不是接入方式的问题，而是它依赖的第三方代理已下线/改路径）。
脚本自带的更新地址返回的 JSON 仍写 `version: 1.3.0`，说明作者尚未通过该渠道发布新版。

### 与上一版内置脚本的关系

1.0.2 随包分发的 `changqing-1.3.0.js` 与本版从官方地址取到的 `changqing-latest.js`
**逐字节相同**（同一个 sha256）。所以 1.0.3 的改动是「把内置音源接口固定为该官方地址并自动取用」，
取流能力本身与 1.0.2 一致。

## 四、端上接入设计

### 4.1 线路优先级（"内置音源"落在第一优先，兜底保可用）

```
① 内置音源脚本 · 同平台线路        用歌曲自身平台的 id 走脚本模板
② 内置音源脚本 · 跨平台匹配线路    用「歌名+歌手」在其它平台找到 id，再走脚本模板
③ 内置直连线路（网易云官方/外链、酷我 anti.s 等）及其跨平台兜底
④ 每条候选都取前 2KB 验真为音频（Content-Type + ID3/MP3/FLAC/OGG/MP4 魔数）后才交给播放器
   —— 脚本线路当前全部 404，会被 2KB 验真直接判掉并自动落到 ③，界面如实显示每一条线路的结果
```

若只保留脚本线路、不保留兜底，在当前上游 404 的情况下应用将完全放不出声音。

### 4.2 端上实现要点

- **描述文件**：`assets/lx_source.json`，含 `sourceUrl`（内置音源接口地址）与 `scriptSha256`（脚本指纹）。
- **`LxSource` 类**（纯 Java，无 android.* 依赖，可在 JVM 上直接验证）：
  - 解析描述文件，暴露 `sources()`、`templateFor(sourceKey, qualityKey)`、`idFieldFor(sourceKey)`、
    `levelTokenFor(...)`、`sourceUrl()`、`scriptFile()`；
  - `buildUrl(sourceKey, id, qualityKey)`：替换模板里的 `{id}`；`{level}` 已由生成期填入具体等级；
  - 平台键映射：`wy→wy`、`kw→kw`、`kg→kg`、`qq→tx`（咪咕 `mg` 预留，应用暂无咪咕搜索）。
- **音质映射**：应用设置的「自动」→ 依次 `320k`、`128k`；「320K 优先」→ `320k`；「128K 省流」→ `128k`。
- **线程模型**：沿用现有解析线程（`MusicPlayer` 的解析池），不新增线程。
- **失败与超时**：脚本线路使用更短的探测超时（4s 连接 / 6s 读）；单条候选失败即刻换下一条。
- **界面呈现**：播放页「线路」区逐条打印 `[OK]/[FAIL] 线路名 · HTTP 状态 · 类型 · 备注`；
  设置页底部显示脚本名称、版本、脚本文件名与内置音源接口地址。

### 4.3 后续换新版脚本

1. 直接重新构建：`./build.sh` 会从内置音源接口地址重新取脚本并重新生成描述文件；
2. 若要从别的地址取：`LX_SOURCE_URL=<地址> ./build.sh`；
3. 端上代码无需任何改动——只要新脚本仍是 lx-music-source 协议（`on('request')` + `musicUrl`）。

## 五、验收与取证方式

- 契约层：`tools/extract_lx_source.js` 在生成描述文件时打印各平台 id 字段、音质等级、模板、来源地址与
  sha256，并实测「上游有新版本时是否停止提供音源」；描述文件本身即为可复核证据。
- 端上层：JVM 直接调用 `LxSource.buildUrl(...)` 与 `PlayResolver.resolve(...)`，打印候选线路与实际结果。
- 设备层：Android 4.4.2 模拟器安装后，用界面层级与日志确认设置页显示的来源地址、播放页线路诊断文本。

## 六、明确的取舍声明

1. **不在端上跑 JS**：ES5 引擎无法解析 ES2015+ 脚本，端上跑需要转译或自建 JS 引擎（QuickJS + NDK），
   而本脚本的取流逻辑是纯字符串拼装，构建期固化后行为等价、风险最低。
2. **保留内置直连线路做兜底**：因为脚本上游当前返回 404；这是"可用性优先"的取舍，脚本线路始终排在第一优先。
3. **不实现脚本的更新门禁**：该门禁在 v1.3.0 中实测已失效（判断状态码 99924），实现它没有意义。
4. **脚本原文件随包分发，未做任何修改**；端上消费的是它运行后的行为描述。
5. **构建期取脚本而不是端上取**：端上无法执行 JS，取到也没有意义；构建期取用可把来源地址与指纹写进
   描述文件，出包内容可审计、可复现。