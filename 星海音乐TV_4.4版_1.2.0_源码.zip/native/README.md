# 端上 JS 引擎（QuickJS）构建说明

本目录是「引擎执行型音源」用到的原生部分：

```
qjs_jni.c            JNI 胶水（工程自有代码）：nNew / nEval / nCall / nWait / nFree + 宿主回调 __nativeHostCall
build_qjs.sh         用 Android NDK 交叉编译出 libqjs.so
lib/<abi>/libqjs.so  预编译好的引擎库（x86 / armeabi-v7a / arm64-v8a），随包分发
```

## 一、引擎来源与许可

- 引擎：[QuickJS](https://bellard.org/quickjs/) **2024-01-13**（含 bignum），作者 Fabrice Bellard，
  以 **MIT 许可**发布；本项目只做编译与 JNI 封装，未修改其源码。
- 构建工具链：**Android NDK r21e**（clang 9），目标 API 19
  （`i686-linux-android19-clang` / `armv7a-linux-androideabi19-clang` / `aarch64-linux-android21-clang`）。

## 二、重新编译

```bash
# 1) 取 QuickJS 源码（2024-01-13 版）解到 ./qjs
curl -fL -o quickjs.tar.xz https://bellard.org/quickjs/quickjs-2024-01-13.tar.xz
tar xf quickjs.tar.xz && mv quickjs-2024-01-13 qjs

# 2) 准备 NDK（r21e），解到 ./ndk_extract/android-ndk-r21e
#    官方包：https://dl.google.com/android/repository/android-ndk-r21e-linux-x86_64.zip

# 3) 编译三个 ABI
./build_qjs.sh all        # 或 x86 / armv7a / arm64
```

产出体积（实测）：x86 611852、armeabi-v7a 628296、arm64-v8a 599928 字节。

## 三、JNI 约定（与 Java 侧一致）

| native | 说明 |
| --- | --- |
| `nNew(memLimit, stackLimit, Class hostCls)` | 建 Runtime+Context、装 `__nativeHostCall`、设置内存/栈上限与超时中断 |
| `nEval(handle, code, fname, timeoutMs)` | 执行脚本，返回 `{"ok":true,"value":…}` / `{"ok":false,"error":"…"}` |
| `nCall(handle, func, argJson, timeoutMs)` | 调全局函数（一个字符串参数），同样返回上面的 JSON |
| `nWait(handle, condFunc, timeoutMs)` | 泵事件循环直到某个返回布尔的 JS 函数为真（等脚本 inited / 取流结果） |
| `nFree(handle)` | 释放 |

- Runtime/Context 不是线程安全的：Java 侧用**一条专用引擎线程**串行调用（`JsEngine` 里的单线程池）。
- 所有异常都转成 JSON 文本，不跨 JNI 抛 Java 异常；脚本卡死由 `JS_SetInterruptHandler` 中断。
