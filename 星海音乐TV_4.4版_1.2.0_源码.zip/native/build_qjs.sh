#!/usr/bin/env bash
# 用 Android NDK 把 QuickJS 编译成端上可加载的 libqjs.so（目标 API 19，体积优先）。
#
# 说明：
#   * 只需 QuickJS 核心（quickjs / libregexp / libunicode / cutils / libbf）+ 本目录的 JNI 胶水 qjs_jni.c；
#   * 不链接 quickjs-libc（端上用不到 std/os 模块，事件循环由胶水层自实现）；
#   * -Os + gc-sections + 链接期去符号，尽量压体积（电视盒子空间紧张）。
#
# 用法：./build_qjs.sh [x86|armv7a|arm64|all]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
NDK="${NDK:-$ROOT/ndk_extract/android-ndk-r21e}"
BIN="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"
SRC="$ROOT/qjs"
OUT="$ROOT/lib"

CFLAGS_COMMON="-Os -DNDEBUG -D_GNU_SOURCE -DCONFIG_VERSION=\"2024-01-13\" -DCONFIG_BIGNUM \
 -include stdint.h -include stdio.h -include inttypes.h -fPIC -ffunction-sections -fdata-sections \
 -fvisibility=hidden -I$SRC"

build_one() {
  local tm="$1" abi="$2"
  local cc="$BIN/${tm}-clang"
  local bd="$ROOT/build_$abi"
  rm -rf "$bd"; mkdir -p "$bd" "$OUT/$abi"
  local objs=()
  for f in quickjs libregexp libunicode cutils libbf; do
    $cc $CFLAGS_COMMON -c "$SRC/$f.c" -o "$bd/$f.o"
    objs+=("$bd/$f.o")
  done
  $cc $CFLAGS_COMMON -c "$ROOT/qjs_jni.c" -o "$bd/qjs_jni.o"
  objs+=("$bd/qjs_jni.o")
  $cc -shared -Wl,--gc-sections -Wl,-s -o "$OUT/$abi/libqjs.so" "${objs[@]}" -lm -llog
  echo "已生成 $OUT/$abi/libqjs.so ($(stat -c%s "$OUT/$abi/libqjs.so") 字节)"
}

case "${1:-all}" in
  x86) build_one i686-linux-android19 x86 ;;
  armv7a) build_one armv7a-linux-androideabi19 armeabi-v7a ;;
  arm64) build_one aarch64-linux-android21 arm64-v8a ;;
  all)
    build_one i686-linux-android19 x86
    build_one armv7a-linux-androideabi19 armeabi-v7a
    build_one aarch64-linux-android21 arm64-v8a
    ;;
esac