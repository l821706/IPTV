/*
 * 端上 JS 引擎（QuickJS）的 JNI 胶水层。
 *
 * 设计原则：
 *   * 只有很少的 native 出入口：nNew / nEval / nCall / nFree，全部由 Java 侧在**同一条线程**上调用
 *     （Runtime/Context 不是线程安全的，Java 侧用专门的引擎线程串行使用）。
 *   * 单次执行都带超时：JS_SetInterruptHandler 会在超时后中断脚本，避免脚本把端上拖死。
 *   * 内存与栈上限由 Java 侧传入，防止脚本把 4.4 电视盒子的内存吃光。
 *   * 脚本需要的宿主能力（HTTP / 日志 / utils）不写在 C 里，而是：
 *       C 暴露一个全局函数 __nativeHostCall(name, argsJson) -> String，
 *       JS 侧胶水（assets/js/lx-host.js）把它包装成 globalThis.lx.* ；
 *       这样宿主逻辑全部在 Java/JS 里，便于排查与扩展。
 *   * 出错不抛 Java 异常：统一返回 JSON 文本 {"ok":true,"value":...} / {"ok":false,"error":"..."}，
 *     由 Java 侧用工程里的 Json 解析，脚本报错绝不会带崩应用进程。
 */
#include <jni.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <android/log.h>
#include "quickjs.h"

#define TAG "QjsJni"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

typedef struct Engine {
    JSRuntime *rt;
    JSContext *ctx;
    long long deadline_ms;
} Engine;

static JavaVM *g_vm = NULL;
static jclass g_host_cls = NULL;
static jmethodID g_host_call = NULL;

static long long now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL;
}

static int interrupt_cb(JSRuntime *rt, void *opaque) {
    Engine *e = (Engine *)opaque;
    if (e == NULL || e->deadline_ms <= 0) {
        return 0;
    }
    if (now_ms() > e->deadline_ms) {
        LOGE("脚本执行超时，已中断");
        return 1;
    }
    return 0;
}

/* 由 QuickJS 调用的宿主入口；把调用转回 Java 静态方法。 */
static JSValue js_host_call(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    (void)this_val;
    JNIEnv *env = NULL;
    int attached = 0;
    if (g_vm == NULL || g_host_cls == NULL || g_host_call == NULL) {
        return JS_UNDEFINED;
    }
    if ((*g_vm)->GetEnv(g_vm, (void **)&env, JNI_VERSION_1_6) != JNI_OK) {
        if ((*g_vm)->AttachCurrentThread(g_vm, &env, NULL) != JNI_OK) {
            return JS_UNDEFINED;
        }
        attached = 1;
    }
    const char *name = NULL;
    const char *args = "";
    jstring j_name = NULL;
    jstring j_args = NULL;
    jstring j_ret = NULL;
    JSValue ret = JS_UNDEFINED;
    if (argc > 0) {
        name = JS_ToCString(ctx, argv[0]);
    }
    if (argc > 1) {
        args = JS_ToCString(ctx, argv[1]);
    }
    j_name = (*env)->NewStringUTF(env, name == NULL ? "" : name);
    j_args = (*env)->NewStringUTF(env, args == NULL ? "" : args);
    if (j_name != NULL && j_args != NULL) {
        j_ret = (jstring)(*env)->CallStaticObjectMethod(env, g_host_cls, g_host_call, j_name, j_args);
    }
    if ((*env)->ExceptionCheck(env)) {
        /* 宿主侧抛异常时清掉，避免把异常带进 JS 层。 */
        (*env)->ExceptionClear(env);
    }
    if (j_ret != NULL) {
        const char *r = (*env)->GetStringUTFChars(env, j_ret, NULL);
        if (r != NULL) {
            ret = JS_NewString(ctx, r);
            (*env)->ReleaseStringUTFChars(env, j_ret, r);
        }
        (*env)->DeleteLocalRef(env, j_ret);
    }
    if (j_name != NULL) {
        (*env)->DeleteLocalRef(env, j_name);
    }
    if (j_args != NULL) {
        (*env)->DeleteLocalRef(env, j_args);
    }
    if (name != NULL) {
        JS_FreeCString(ctx, name);
    }
    if (args != NULL) {
        JS_FreeCString(ctx, args);
    }
    if (attached) {
        (*g_vm)->DetachCurrentThread(g_vm);
    }
    return ret;
}


/* 最小 JSON 字符串转义：错误信息里可能有引号、反斜杠或换行。 */
static void json_escape(const char *in, char *out, size_t cap) {
    size_t j = 0;
    if (in == NULL) { in = ""; }
    for (size_t i = 0; in[i] != '\0' && j + 2 < cap; i++) {
        unsigned char c = (unsigned char)in[i];
        if (c == '"' || c == '\\') {
            if (j + 2 >= cap) break;
            out[j++] = '\\';
            out[j++] = (char)c;
        } else if (c == '\n' || c == '\r' || c == '\t') {
            out[j++] = ' ';
        } else if (c < 0x20) {
            out[j++] = ' ';
        } else {
            out[j++] = (char)c;
        }
    }
    out[j] = '\0';
}


/* 调用全局函数（一个参数，字符串），失败返回 undefined */
static JSValue call_global(JSContext *ctx, const char *name, JSValue *arg) {
    JSValue global = JS_GetGlobalObject(ctx);
    JSValue fn = JS_GetPropertyStr(ctx, global, name);
    JS_FreeValue(ctx, global);
    if (!JS_IsFunction(ctx, fn)) {
        JS_FreeValue(ctx, fn);
        return JS_UNDEFINED;
    }
    JSValue ret = JS_Call(ctx, fn, JS_UNDEFINED, arg == NULL ? 0 : 1, arg);
    JS_FreeValue(ctx, fn);
    return ret;
}

/*
 * 把脚本结果统一成「最终值」：脚本处理器（以及探针函数）常常是 async，直接拿到的是 Promise，
 * 所以这里一律交给 JS 胶水的 __engineAwait 托管，然后在宿主侧泵微任务与定时器，直到落定或超时。
 *   * JS_ExecutePendingJob 推动 Promise 的 then 回调；
 *   * JS 胶水的 __enginePumpTimers 负责 setTimeout 这类定时器，返回「距下一个到期还有多少毫秒」，-1 表示没有。
 */
static JSValue await_settle(Engine *e, JSValue val) {
    JSValue pend_ctx = JS_UNDEFINED;
    JSValue awaited = call_global(e->ctx, "__engineAwait", &val);
    int guard = 0;
    JSValue out = JS_UNDEFINED;
    int timed_out = 0;
    if (JS_IsException(awaited)) {
        JS_FreeValue(e->ctx, JS_GetException(e->ctx));
        JS_FreeValue(e->ctx, awaited);
        return val;
    }
    JS_FreeValue(e->ctx, awaited);
    while (guard++ < 200000) {
        JSValue done;
        JSValue w;
        int32_t ms = -1;
        /* 先放行到期定时器（脚本里的 setTimeout 会在这里 resolve 掉 Promise）… */
        w = call_global(e->ctx, "__enginePumpTimers", NULL);
        if (!JS_IsException(w)) {
            JS_ToInt32(e->ctx, &ms, w);
        }
        JS_FreeValue(e->ctx, w);
        /* …再把微任务（then 回调）跑干净… */
        while (JS_ExecutePendingJob(e->rt, &pend_ctx) > 0) {
            /* 直到队列为空 */
        }
        /* …然后看 Promise 是否已落定。 */
        done = call_global(e->ctx, "__engineAwaitDone", NULL);
        if (!JS_IsException(done) && JS_ToBool(e->ctx, done) == 1) {
            JS_FreeValue(e->ctx, done);
            break;
        }
        JS_FreeValue(e->ctx, done);
        if (e->deadline_ms > 0 && now_ms() > e->deadline_ms) {
            timed_out = 1;
            break;
        }
        if (ms < 0) {
            /* 没有待触发的定时器、也没别的可推进：再泵一次微任务后收尾（未落定按空结果返回）。 */
            while (JS_ExecutePendingJob(e->rt, &pend_ctx) > 0) {
                /* 最后一次机会 */
            }
            done = call_global(e->ctx, "__engineAwaitDone", NULL);
            if (!JS_IsException(done) && JS_ToBool(e->ctx, done) == 1) {
                JS_FreeValue(e->ctx, done);
                break;
            }
            JS_FreeValue(e->ctx, done);
            break;
        }
        if (ms > 0) {
            usleep((useconds_t)(ms * 1000));
        }
    }
    if (timed_out) {
        out = JS_ThrowInternalError(e->ctx, "script timeout");
    } else {
        JSValue err = call_global(e->ctx, "__engineAwaitError", NULL);
        if (!JS_IsException(err) && !JS_IsNull(err) && !JS_IsUndefined(err)) {
            const char *emsg = JS_ToCString(e->ctx, err);
            out = JS_ThrowInternalError(e->ctx, "%s", emsg != NULL ? emsg : "script error");
            if (emsg != NULL) {
                JS_FreeCString(e->ctx, emsg);
            }
        } else {
            out = call_global(e->ctx, "__engineAwaitResult", NULL);
        }
        JS_FreeValue(e->ctx, err);
    }
    JS_FreeValue(e->ctx, val);
    return out;
}

/* 把 JS 值/异常统一转成 JSON 文本结果。 */
static jstring result_to_json(JNIEnv *env, JSContext *ctx, JSValue val) {
    JSValue out = JS_UNDEFINED;
    const char *text = NULL;
    jstring ret = NULL;
    char *body = NULL;
    size_t len;
    if (JS_IsException(val)) {
        JSValue ex = JS_GetException(ctx);
        const char *msg = JS_ToCString(ctx, ex);
        const char *stack = NULL;
        JSValue st = JS_GetPropertyStr(ctx, ex, "stack");
        if (!JS_IsUndefined(st) && !JS_IsNull(st)) {
            stack = JS_ToCString(ctx, st);
        }
        {
            size_t cap = strlen(msg ? msg : "脚本异常") + (stack ? strlen(stack) : 0) + 256;
            char *safe = (char *)malloc(cap);
            char *safeStack = (char *)malloc(cap);
            body = (char *)malloc(cap * 2 + 96);
            if (safe == NULL || safeStack == NULL || body == NULL) {
                free(safe);
                free(safeStack);
                free(body);
                body = NULL;
            } else {
                json_escape(msg != NULL ? msg : "脚本异常", safe, cap);
                json_escape(stack != NULL ? stack : "", safeStack, cap);
                sprintf(body, "{\"ok\":false,\"error\":\"%s\",\"stack\":\"%s\"}", safe, safeStack);
                free(safe);
                free(safeStack);
            }
        }
        if (msg != NULL) {
            JS_FreeCString(ctx, msg);
        }
        if (stack != NULL) {
            JS_FreeCString(ctx, stack);
        }
        JS_FreeValue(ctx, st);
        JS_FreeValue(ctx, ex);
    } else {
        out = JS_JSONStringify(ctx, val, JS_UNDEFINED, JS_UNDEFINED);
        if (JS_IsException(out) || JS_IsUndefined(out)) {
            if (JS_IsException(out)) {
                JS_FreeValue(ctx, JS_GetException(ctx));
            }
            out = JS_NewString(ctx, "null");
        }
        text = JS_ToCString(ctx, out);
        body = (char *)malloc(strlen(text != NULL ? text : "null") + 32);
        if (body != NULL) {
            sprintf(body, "{\"ok\":true,\"value\":%s}", text != NULL ? text : "null");
        }
        if (text != NULL) {
            JS_FreeCString(ctx, text);
        }
        JS_FreeValue(ctx, out);
    }
    if (body == NULL) {
        body = strdup("{\"ok\":false,\"error\":\"out of memory\"}");
    }
    /* Java 侧按 UTF-8 解析；NewStringUTF 需要修改版 UTF-8，JS 文本里可能出现 4 字节序列，
       因此这里把非法字节统一替换成 '?'，避免 NewStringUTF 出问题。 */
    for (len = 0; body[len] != '\0'; len++) {
        unsigned char c = (unsigned char)body[len];
        if (c >= 0xF0) {
            body[len] = '?';
            body[len + 1] = '?';
            body[len + 2] = '?';
            body[len + 3] = '?';
            len += 3;
        }
    }
    ret = (*env)->NewStringUTF(env, body);
    free(body);
    return ret;
}

JNIEXPORT jlong JNICALL
Java_com_freemusic_tv_QuickJs_nNew(JNIEnv *env, jclass cls, jlong mem_limit, jlong stack_limit, jclass host_klass) {
    Engine *e = (Engine *)calloc(1, sizeof(Engine));
    if (e == NULL) {
        return 0;
    }
    LOGI("nNew: step1 enter");
    if (g_host_cls == NULL) {
        LOGI("nNew: step2 bind host class %p", (void *)host_klass);
        if (host_klass == NULL) {
            free(e);
            return 0;
        }
        g_host_cls = (jclass)(*env)->NewGlobalRef(env, host_klass);
        LOGI("nNew: step2a globalRef=%p", (void *)g_host_cls);
        g_host_call = (*env)->GetStaticMethodID(env, g_host_cls, "hostCall",
                "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
        LOGI("nNew: step2b hostCall=%p", (void *)g_host_call);
        if (g_host_call == NULL) {
            if ((*env)->ExceptionCheck(env)) {
                (*env)->ExceptionClear(env);
            }
            free(e);
            return 0;
        }
    }
    LOGI("nNew: step3 new runtime");
    e->rt = JS_NewRuntime();
    LOGI("nNew: step4 rt=%p", (void *)e->rt);
    if (e->rt == NULL) {
        free(e);
        return 0;
    }
    if (mem_limit > 0) {
        JS_SetMemoryLimit(e->rt, (size_t)mem_limit);
        LOGI("nNew: step5 memlimit ok");
    }
    if (stack_limit > 0) {
        JS_SetMaxStackSize(e->rt, (size_t)stack_limit);
        LOGI("nNew: step6 stack ok");
    }
    JS_SetInterruptHandler(e->rt, interrupt_cb, e);
    LOGI("nNew: step7 interrupt ok");
    e->ctx = JS_NewContext(e->rt);
    LOGI("nNew: step8 ctx=%p", (void *)e->ctx);
    if (e->ctx == NULL) {
        JS_FreeRuntime(e->rt);
        free(e);
        return 0;
    }
    JSValue fn = JS_NewCFunction(e->ctx, js_host_call, "__nativeHostCall", 2);
    LOGI("nNew: step9 cfunction ok");
    JSValue global = JS_GetGlobalObject(e->ctx);
    JS_SetPropertyStr(e->ctx, global, "__nativeHostCall", fn);
    JS_FreeValue(e->ctx, global);
    LOGI("引擎已就绪 (mem=%lld stack=%lld)", (long long)mem_limit, (long long)stack_limit);
    return (jlong)(intptr_t)e;
}

JNIEXPORT jstring JNICALL
Java_com_freemusic_tv_QuickJs_nEval(JNIEnv *env, jclass cls, jlong handle, jstring code, jstring fname,
                                    jlong timeout_ms) {
    Engine *e = (Engine *)(intptr_t)handle;
    if (e == NULL || e->ctx == NULL) {
        return (*env)->NewStringUTF(env, "{\"ok\":false,\"error\":\"engine not ready\"}");
    }
    const char *src = (*env)->GetStringUTFChars(env, code, NULL);
    const char *name = fname != NULL ? (*env)->GetStringUTFChars(env, fname, NULL) : NULL;
    if (src == NULL) {
        return (*env)->NewStringUTF(env, "{\"ok\":false,\"error\":\"bad source\"}");
    }
    e->deadline_ms = timeout_ms > 0 ? now_ms() + (long long)timeout_ms : 0;
    JSValue val = JS_Eval(e->ctx, src, strlen(src), name != NULL ? name : "<eval>", JS_EVAL_TYPE_GLOBAL);
    if (!JS_IsException(val)) {
        val = await_settle(e, val);
    }
    jstring ret = result_to_json(env, e->ctx, val);
    JS_FreeValue(e->ctx, val);
    e->deadline_ms = 0;
    (*env)->ReleaseStringUTFChars(env, code, src);
    if (name != NULL) {
        (*env)->ReleaseStringUTFChars(env, fname, name);
    }
    return ret;
}

JNIEXPORT jstring JNICALL
Java_com_freemusic_tv_QuickJs_nCall(JNIEnv *env, jclass cls, jlong handle, jstring func, jstring arg,
                                    jlong timeout_ms) {
    Engine *e = (Engine *)(intptr_t)handle;
    if (e == NULL || e->ctx == NULL) {
        return (*env)->NewStringUTF(env, "{\"ok\":false,\"error\":\"engine not ready\"}");
    }
    const char *fname = (*env)->GetStringUTFChars(env, func, NULL);
    const char *a = arg != NULL ? (*env)->GetStringUTFChars(env, arg, NULL) : NULL;
    jstring ret;
    JSValue fn;
    JSValue js_arg;
    JSValue val;
    if (fname == NULL) {
        return (*env)->NewStringUTF(env, "{\"ok\":false,\"error\":\"bad function\"}");
    }
    JSValue global = JS_GetGlobalObject(e->ctx);
    fn = JS_GetPropertyStr(e->ctx, global, fname);
    JS_FreeValue(e->ctx, global);
    if (!JS_IsFunction(e->ctx, fn)) {
        JS_FreeValue(e->ctx, fn);
        (*env)->ReleaseStringUTFChars(env, func, fname);
        if (a != NULL) {
            (*env)->ReleaseStringUTFChars(env, arg, a);
        }
        return (*env)->NewStringUTF(env, "{\"ok\":false,\"error\":\"no such function\"}");
    }
    js_arg = JS_NewString(e->ctx, a != NULL ? a : "");
    e->deadline_ms = timeout_ms > 0 ? now_ms() + (long long)timeout_ms : 0;
    val = JS_Call(e->ctx, fn, JS_UNDEFINED, 1, &js_arg);
    if (!JS_IsException(val)) {
        val = await_settle(e, val);
    }
    e->deadline_ms = 0;
    ret = result_to_json(env, e->ctx, val);
    JS_FreeValue(e->ctx, val);
    JS_FreeValue(e->ctx, js_arg);
    JS_FreeValue(e->ctx, fn);
    (*env)->ReleaseStringUTFChars(env, func, fname);
    if (a != NULL) {
        (*env)->ReleaseStringUTFChars(env, arg, a);
    }
    return ret;
}

JNIEXPORT void JNICALL
Java_com_freemusic_tv_QuickJs_nFree(JNIEnv *env, jclass cls, jlong handle) {
    Engine *e = (Engine *)(intptr_t)handle;
    (void)env;
    (void)cls;
    if (e == NULL) {
        return;
    }
    if (e->ctx != NULL) {
        JS_FreeContext(e->ctx);
    }
    if (e->rt != NULL) {
        JS_FreeRuntime(e->rt);
    }
    free(e);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void)reserved;
    g_vm = vm;
    return JNI_VERSION_1_4;
}

/* 等某个返回布尔的 JS 函数变成真值：期间照常泵定时器与微任务（脚本初始化、取流都靠它）。 */
JNIEXPORT jstring JNICALL
Java_com_freemusic_tv_QuickJs_nWait(JNIEnv *env, jclass cls, jlong handle, jstring cond_fn, jlong timeout_ms) {
    Engine *e = (Engine *)(intptr_t)handle;
    const char *cname = NULL;
    JSValue pend_ctx = JS_UNDEFINED;
    int done = 0, timed_out = 0, no_progress = 0;
    long guard = 0;
    if (e == NULL || e->ctx == NULL || cond_fn == NULL) {
        return (*env)->NewStringUTF(env, "{\"ok\":false,\"error\":\"engine not ready\"}");
    }
    cname = (*env)->GetStringUTFChars(env, cond_fn, NULL);
    e->deadline_ms = timeout_ms > 0 ? now_ms() + (long long)timeout_ms : 0;
    while (guard++ < 300000) {
        JSValue w = call_global(e->ctx, "__enginePumpTimers", NULL);
        int32_t ms = -1;
        JSValue c;
        int truthy;
        if (!JS_IsException(w)) {
            JS_ToInt32(e->ctx, &ms, w);
        }
        JS_FreeValue(e->ctx, w);
        while (JS_ExecutePendingJob(e->rt, &pend_ctx) > 0) {
            /* 把 then 回调跑干净 */
        }
        c = call_global(e->ctx, cname, NULL);
        truthy = !JS_IsException(c) && JS_ToBool(e->ctx, c) == 1;
        JS_FreeValue(e->ctx, c);
        if (truthy) {
            done = 1;
            break;
        }
        if (e->deadline_ms > 0 && now_ms() > e->deadline_ms) {
            timed_out = 1;
            break;
        }
        if (ms < 0) {
            /* 没有定时器：再给微任务一次机会，然后收尾 */
            while (JS_ExecutePendingJob(e->rt, &pend_ctx) > 0) {
                /* 最后一次 */
            }
            c = call_global(e->ctx, cname, NULL);
            truthy = !JS_IsException(c) && JS_ToBool(e->ctx, c) == 1;
            JS_FreeValue(e->ctx, c);
            if (truthy) {
                done = 1;
            } else {
                no_progress = 1;
            }
            break;
        }
        if (ms > 0) {
            usleep((useconds_t)(ms * 1000));
        }
    }
    e->deadline_ms = 0;
    if (cname != NULL) {
        (*env)->ReleaseStringUTFChars(env, cond_fn, cname);
    }
    if (done) {
        return (*env)->NewStringUTF(env, "{\"ok\":true}");
    }
    if (timed_out) {
        return (*env)->NewStringUTF(env, "{\"ok\":false,\"error\":\"timeout\"}");
    }
    if (no_progress) {
        return (*env)->NewStringUTF(env, "{\"ok\":false,\"error\":\"no progress\"}");
    }
    return (*env)->NewStringUTF(env, "{\"ok\":false,\"error\":\"loop guard\"}");
}
