package com.freemusic.tv;

import android.app.Activity;
import android.content.Context;
import android.util.TypedValue;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * 启动自检。
 * Android 4.4 上有些问题（例如布局里漏写 layout_width）只在运行时抛异常，
 * 编译期完全看不出来，表现就是「装完一开就闪退」。
 * 这里做两件事：
 *   1. 记下最后一次崩溃的异常类名与堆栈，写到应用私有目录，下次打开可直接读取；
 *   2. 如果启动阶段就抛异常，直接把错误信息铺在屏幕上，让电视上也能看到原因，
 *      而不是黑一下就退出、什么线索都没留下。
 */
public final class CrashGuard {

    private static final String FILE_NAME = "last_crash.txt";
    private static final int MAX_CHARS = 1800;

    private CrashGuard() {
    }

    public static void install(final Context context) {
        final Context app = context.getApplicationContext();
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread, Throwable e) {
                write(app, e);
                if (previous != null) {
                    previous.uncaughtException(thread, e);
                }
            }
        });
    }

    public static void write(Context context, Throwable e) {
        if (e == null) {
            return;
        }
        String text = describe(e);
        File file = file(context);
        OutputStream out = null;
        try {
            out = new FileOutputStream(file);
            out.write(text.getBytes("UTF-8"));
            out.flush();
        } catch (Throwable ignore) {
            // 私有目录不可写时放弃落盘，屏幕提示仍然有效
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (Throwable ignore) {
                    // 忽略
                }
            }
        }
    }

    public static String readLast(Context context) {
        File file = file(context);
        if (file == null || !file.exists()) {
            return "";
        }
        InputStream in = null;
        try {
            in = new FileInputStream(file);
            byte[] buf = new byte[8192];
            int n = in.read(buf);
            if (n <= 0) {
                return "";
            }
            return new String(buf, 0, n, "UTF-8");
        } catch (Throwable t) {
            return "";
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Throwable ignore) {
                    // 忽略
                }
            }
        }
    }

    public static File file(Context context) {
        try {
            return new File(context.getFilesDir(), FILE_NAME);
        } catch (Throwable t) {
            return null;
        }
    }

    /** 异常类名 + 消息 + 前若干层堆栈 + 根因，控制在可读长度内。 */
    public static String describe(Throwable e) {
        StringBuilder sb = new StringBuilder();
        sb.append(e.getClass().getName());
        if (e.getMessage() != null) {
            sb.append(": ").append(e.getMessage());
        }
        StackTraceElement[] frames = e.getStackTrace();
        int limit = frames == null ? 0 : Math.min(frames.length, 12);
        for (int i = 0; i < limit; i++) {
            sb.append("\n    at ").append(frames[i].toString());
        }
        Throwable cause = e.getCause();
        int guard = 0;
        while (cause != null && guard < 5) {
            sb.append("\n  由 ").append(cause.getClass().getName());
            if (cause.getMessage() != null) {
                sb.append(": ").append(cause.getMessage());
            }
            StackTraceElement[] cf = cause.getStackTrace();
            if (cf != null) {
                for (int i = 0; i < Math.min(cf.length, 6); i++) {
                    sb.append("\n    at ").append(cf[i].toString());
                }
            }
            cause = cause.getCause();
            guard++;
        }
        String text = sb.toString();
        return text.length() > MAX_CHARS ? text.substring(0, MAX_CHARS) + "\n...(已截断)" : text;
    }

    /** 启动阶段就失败时，把错误直接显示在电视屏幕上。 */
    public static void showFailureScreen(Activity activity, Throwable e) {
        if (activity == null) {
            return;
        }
        String detail = describe(e);
        try {
            TextView tv = new TextView(activity);
            tv.setText("启动自检未通过，已记录异常信息。\n\n"
                    + detail
                    + "\n\n请把以上文字反馈给开发者；"
                    + "文件位置：" + (file(activity) == null ? "不可用" : file(activity).getAbsolutePath()));
            tv.setTextColor(0xFFE9EEF7);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            tv.setPadding(24, 24, 24, 24);

            ScrollView sv = new ScrollView(activity);
            sv.setBackgroundColor(0xFF0B0E13);
            sv.addView(tv, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
            activity.setContentView(sv, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        } catch (Throwable ignore) {
            // 提示页本身失败时不再递归处理
        }
    }
}