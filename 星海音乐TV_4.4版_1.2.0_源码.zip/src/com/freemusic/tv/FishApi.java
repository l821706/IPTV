package com.freemusic.tv;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 内置音源 fish_music（用户指定的 lx-music-source 脚本）的取流链路端上实现。
 *
 * fish 与「纯 URL 模板」型脚本不同：它的每个平台分支都要在运行时请求后端才能拿到地址，
 * 所以构建期固化的描述文件只能记下它对外暴露的平台、音质与元信息（assets/lx_source.json），
 * 取流本身由本类按脚本的实际调用链在端上实现——调用的上游、参数与顺序都与脚本一致：
 *
 *   平台 wy：换源聚合（wy_song_kw.php）→ 网易云官方接口（enhance/player/url）→ 酷我交叉匹配
 *   平台 kg：换源聚合（kg_song_kw.php）→ 酷狗官方接口（m.kugou.com getSongInfo）→ 酷我交叉匹配
 *   平台 tx：QQ 聚合接口（tang.api.s01s.cn music_open_api.php）→ 酷我交叉匹配
 *   平台 kw：酷我 car 取流接口（nmobi convert_url_with_sign + car 客户端 source）→ 酷我交叉匹配
 *   平台 mg：酷我交叉匹配
 *
 *   换源聚合与交叉匹配都要求「歌名 + 歌手」与请求歌曲对得上（脚本里是 strict match），
 *   对不上就判失败继续下一条，避免放出别的歌。
 *
 * 本类不依赖任何 android.* API，可直接在 JVM 上做联网验证。
 */
public final class FishApi {

    /** 一次取流的结果：地址 + 实际生效的上游（用于播放页线路诊断）。 */
    public static final class Resolved {
        public String url = "";
        public String upstream = "";

        public boolean ok() {
            return url.length() > 0;
        }
    }

    /** 换源聚合站：脚本先试第一个域名，失败再试镜像。 */
    private static final String SWAP_A = "https://musicapi.haitangw.net/music/";
    private static final String SWAP_B = "https://music.haitangw.cc/music/";

    /** 酷我 car 取流接口与脚本里写死的 car 客户端标识、user。 */
    private static final String KUWO_MOBI = "https://nmobi.kuwo.cn/mobi.s";
    private static final String CAR_USER = "7e09dbb97053f47e";
    private static final String[] CAR_SOURCES = {
            "kwplayercar_ar_6.0.0.9_B_jiakong_vh.apk",
            "kwplayercar_ar_6.0.1.0_apk_keluze.apk"
    };

    /** 脚本交叉匹配用的酷我搜索接口（参数与脚本一致）。 */
    private static final String KUWO_SEARCH = "https://search.kuwo.cn/r.s?client=kt&all=";

    /** QQ 音乐聚合接口（脚本 tx 分支的上游）。 */
    private static final String S01S = "https://tang.api.s01s.cn/music_open_api.php?mid=";

    /** 酷狗官方取流接口（脚本 kg 分支的平台原生尝试）。 */
    private static final String KUGOU_INFO = "https://m.kugou.com/app/i/getSongInfo.php?cmd=playInfo&hash=";

    private static final int CONNECT_MS = 5000;
    private static final int READ_MS = 7000;

    private FishApi() {
    }

    /**
     * 只有当前生效的描述文件确实是 fish_music 时才启用这条链路，
     * 避免把别的脚本的能力错算到 fish 头上。
     */
    public static boolean enabled() {
        LxSource lx = LxSource.active();
        if (lx == null || !lx.isReady()) {
            return false;
        }
        String name = lx.displayName() == null ? "" : lx.displayName().toLowerCase();
        String file = lx.scriptFile() == null ? "" : lx.scriptFile().toLowerCase();
        return name.indexOf("fish") >= 0 || file.indexOf("fish") >= 0;
    }

    /** 脚本里的音质档 -> 换源聚合使用的 level 参数。 */
    public static String levelOf(String qualityKey) {
        if ("128k".equals(qualityKey)) {
            return "standard";
        }
        if ("flac".equals(qualityKey) || "flac24bit".equals(qualityKey)) {
            return "lossless";
        }
        return "exhigh";
    }

    /** 脚本里的音质档 -> 酷我 car 取流接口的 br 参数。 */
    public static String brOf(String qualityKey) {
        if ("128k".equals(qualityKey)) {
            return "128kmp3";
        }
        if ("flac".equals(qualityKey)) {
            return "2000kflac";
        }
        if ("flac24bit".equals(qualityKey)) {
            return "4000kflac";
        }
        return "320kmp3";
    }

    // ---------------- 供平台链路复用的上游调用（参数与脚本一致） ----------------

    /** 换源聚合（脚本只对 wy / kg 接了这个接口），要求歌名+歌手对得上。 */
    static String swapAggregate(String platformKey, String id, String title, String artist, String qualityKey) {
        String path = swapPath(LxSource.appSourceToKey(platformKey));
        if (path == null || id == null || id.length() == 0) {
            return "";
        }
        Song probe = new Song(title == null ? "" : title, artist == null ? "" : artist, "",
                Song.SRC_WY, id, "", "", 0);
        return swap(probe, path, levelOf(qualityKey));
    }

    /** 酷我 car 取流接口（nmobi convert_url_with_sign + car 客户端 source + 脚本里的 user）。 */
    static String carRelay(String rid, String qualityKey) {
        return kuwoCar(rid, brOf(qualityKey));
    }

    /** 酷狗官方取流接口（实测多数歌曲只返回空 url）。 */
    static String kugouOfficial(String hash) {
        return kugou(hash);
    }

    /** 网易云官方取流接口（enhance/player/url，br 按音质档）。 */
    static String neteaseOfficial(String id, String qualityKey) {
        return netease(new Song("", "", "", Song.SRC_WY, id, "", "", 0), qualityKey);
    }

    /** 酷我交叉匹配：按「歌名 歌手」搜，取严格对得上的一首的 rid。 */
    static String kuwoMatchRid(String title, String artist) {
        return kuwoMatch(title, artist);
    }

    /** 按 fish 的链路取流；取不到返回 url 为空的结果，不抛异常。 */
    public static Resolved resolve(Song song, String qualityKey) {
        Resolved out = new Resolved();
        if (song == null || song.id.length() == 0) {
            return out;
        }
        String key = LxSource.appSourceToKey(song.source);
        if (key == null) {
            return out;
        }
        String level = levelOf(qualityKey);
        String br = brOf(qualityKey);

        // 1) 换源聚合：脚本只对 wy / kg 接了这个接口
        String swapPath = swapPath(key);
        if (swapPath != null) {
            String u = swap(song, swapPath, level);
            if (u.length() > 0) {
                out.url = u;
                out.upstream = "换源聚合 " + swapPath.replace("_song_kw.php", "");
                return out;
            }
        }

        // 2) 平台原生接口
        if ("wy".equals(key)) {
            String u = netease(song, qualityKey);
            if (u.length() > 0) {
                out.url = u;
                out.upstream = "网易云官方接口";
                return out;
            }
        } else if ("kg".equals(key)) {
            String u = kugou(song.id);
            if (u.length() > 0) {
                out.url = u;
                out.upstream = "酷狗官方接口";
                return out;
            }
        } else if ("tx".equals(key)) {
            String u = s01s(song.id, qualityKey);
            if (u.length() > 0) {
                out.url = u;
                out.upstream = "QQ 聚合接口";
                return out;
            }
        } else if ("kw".equals(key)) {
            String u = kuwoCar(song.id, br);
            if (u.length() > 0) {
                out.url = u;
                out.upstream = "酷我 car 取流接口";
                return out;
            }
        }

        // 3) 酷我交叉匹配兜底（所有平台共用）
        String rid = kuwoMatch(song.title, song.artist);
        if (rid.length() > 0) {
            String u = kuwoCar(rid, br);
            if (u.length() > 0) {
                out.url = u;
                out.upstream = "酷我交叉匹配 rid=" + rid;
                return out;
            }
        }
        return out;
    }

    private static String swapPath(String key) {
        if (Song.SRC_WY.equals(key)) {
            return "wy_song_kw.php";
        }
        if (Song.SRC_KG.equals(key)) {
            return "kg_song_kw.php";
        }
        return null;
    }

    /** 换源聚合：两个域名依次试，返回的 url 必须对应「同一首歌」（脚本的 strict match）。 */
    private static String swap(Song song, String path, String level) {
        String[] hosts = new String[]{SWAP_A, SWAP_B};
        for (int i = 0; i < hosts.length; i++) {
            String url = hosts[i] + path + "?type=json&id=" + Http.encode(song.id)
                    + "&level=" + level;
            Http.Res res = Http.get(url, Http.headers(), CONNECT_MS, READ_MS);
            if (!res.ok()) {
                continue;
            }
            Object root = Json.parse(res.body);
            if (Json.integer(Json.at(root, "code")) != 200) {
                continue;
            }
            String u = Json.strAt(root, "data", "url");
            String name = Json.strAt(root, "data", "name");
            String artist = Json.strAt(root, "data", "artist");
            if (u.length() > 0 && match(song.title, name) && match(song.artist, artist)) {
                return u;
            }
        }
        return "";
    }

    /** 网易云官方接口（与脚本 wy 分支同参数）。 */
    private static String netease(Song song, String qualityKey) {
        int br = 320000;
        if ("128k".equals(qualityKey)) {
            br = 128000;
        } else if ("flac".equals(qualityKey) || "flac24bit".equals(qualityKey)) {
            br = 999000;
        }
        String u = WyApi.songUrl(song.id, br);
        return u == null ? "" : u;
    }

    /** 酷狗官方接口，脚本只在返回里真的有 url 时才采用（实测多数返回空 url）。 */
    private static String kugou(String hash) {
        Http.Res res = Http.get(KUGOU_INFO + Http.encode(hash), Http.headers(), CONNECT_MS, READ_MS);
        if (!res.ok()) {
            return "";
        }
        Object root = Json.parse(res.body);
        String u = Json.strAt(root, "url");
        if (u == null || u.length() == 0 || !u.startsWith("http")) {
            return "";
        }
        return u;
    }

    /** QQ 音乐聚合接口：一次返回各档位地址，按音质取对应字段。 */
    private static String s01s(String mid, String qualityKey) {
        Http.Res res = Http.get(S01S + Http.encode(mid), Http.headers(), CONNECT_MS, READ_MS);
        if (!res.ok()) {
            return "";
        }
        Object root = Json.parse(res.body);
        String field = "song_play_url_hq";
        if ("128k".equals(qualityKey)) {
            field = "song_play_url_standard";
        } else if ("flac".equals(qualityKey)) {
            field = "song_play_url_sq";
        } else if ("flac24bit".equals(qualityKey)) {
            field = "song_play_url_pq";
        }
        String u = Json.strAt(root, field);
        if (u.length() == 0) {
            u = Json.strAt(root, "song_play_url");
        }
        if (u.length() == 0 || !u.startsWith("http")) {
            return "";
        }
        return u;
    }

    /** 酷我 car 取流接口：脚本对两个 car 客户端标识依次试，取 data.url。 */
    private static String kuwoCar(String rid, String br) {
        String id = rid;
        if (id.startsWith("MUSIC_")) {
            id = id.substring("MUSIC_".length());
        }
        for (int i = 0; i < CAR_SOURCES.length; i++) {
            String url = KUWO_MOBI + "?f=web&type=convert_url_with_sign&br=" + br
                    + "&rid=" + id + "&source=" + CAR_SOURCES[i] + "&user=" + CAR_USER;
            Http.Res res = Http.get(url, Http.headers(), CONNECT_MS, READ_MS);
            if (!res.ok()) {
                continue;
            }
            Object root = Json.parse(res.body);
            String u = Json.strAt(root, "data", "url");
            // 酷我 car 接口在部分歌曲/高音质档会返回 .mgg（酷我客户端专用加密封装），
            // 普通播放器打不开，直接判这条候选不可用，让取流落到下一条线路。
            if (u.length() > 0 && u.startsWith("http")
                    && u.indexOf("format$mgg") < 0 && u.indexOf(".mgg") < 0) {
                return u;
            }
        }
        return "";
    }

    /** 酷我交叉匹配：按「歌名 歌手」搜，取严格对得上的一首的 rid。 */
    private static String kuwoMatch(String title, String artist) {
        String query = (title + " " + artist).trim();
        if (query.length() == 0) {
            return "";
        }
        String url = KUWO_SEARCH + Http.encode(query)
                + "&ft=music&cluster=0&strategy=2012&encoding=utf8&rformat=json"
                + "&ver=mbox&plat=pc&vipver=WAR_DUMMY_VERSION&show_copyright_off=1&pn=0&rn=3";
        Http.Res res = Http.get(url, Http.headers(), CONNECT_MS, READ_MS);
        if (!res.ok()) {
            return "";
        }
        List<Map<String, String>> items = KwApi.parseJsObjectArray(res.body, "abslist");
        for (int i = 0; i < items.size(); i++) {
            Map<String, String> it = items.get(i);
            String rid = first(it, "DC_TARGETID", "MUSICRID");
            if (rid.startsWith("MUSIC_")) {
                rid = rid.substring("MUSIC_".length());
            }
            String name = Json.html(first(it, "NAME", "SONGNAME"));
            String a = Json.html(first(it, "ARTIST", "AARTIST"));
            if (rid.length() > 0 && match(title, name) && match(artist, a)) {
                return rid;
            }
        }
        return "";
    }

    private static String first(Map<String, String> m, String... keys) {
        for (int i = 0; i < keys.length; i++) {
            String v = m.get(keys[i]);
            if (v != null && v.length() > 0) {
                return v;
            }
        }
        return "";
    }

    /**
     * 歌名/歌手是否指向同一首歌：先去掉括号补充说明（(Live)、(片段) 之类）再比，
     * 归一化后要求相等；只有单字前缀这种明显不完整的情况才用包含判断兜底。
     */
    static boolean match(String want, String got) {
        String a = base(want);
        String b = base(got);
        if (a.length() == 0 || b.length() == 0) {
            return false;
        }
        if (a.equals(b)) {
            return true;
        }
        return (a.length() >= 2 && b.indexOf(a) >= 0) || (b.length() >= 2 && a.indexOf(b) >= 0);
    }

    private static String base(String s) {
        String t = s == null ? "" : s;
        int cut = -1;
        String[] marks = new String[]{"(", "（", "[", "【", "&"};
        for (int i = 0; i < marks.length; i++) {
            int at = t.indexOf(marks[i]);
            if (at > 0 && (cut < 0 || at < cut)) {
                cut = at;
            }
        }
        if (cut > 0) {
            t = t.substring(0, cut);
        }
        return Song.norm(t);
    }

    /** 便于线路诊断：列出该平台在本音源下的调用链。 */
    public static List<String> chainOf(Song song) {
        List<String> out = new ArrayList<String>();
        String key = LxSource.appSourceToKey(song.source);
        if ("wy".equals(key)) {
            out.add("换源聚合 wy_song_kw.php");
            out.add("网易云官方接口");
        } else if ("kg".equals(key)) {
            out.add("换源聚合 kg_song_kw.php");
            out.add("酷狗官方接口");
        } else if ("tx".equals(key)) {
            out.add("QQ 聚合接口");
        } else if ("kw".equals(key)) {
            out.add("酷我 car 取流接口");
        }
        out.add("酷我交叉匹配");
        return out;
    }
}