package com.freemusic.tv;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/**
 * 纯 java.net 的 HTTP 工具（不依赖任何 Android API），
 * 使同一份取流逻辑既能跑在 Android 4.4 上，也能在 JVM 里做真实联网验证。
 */
public final class Http {

    public static final String UA =
            "Mozilla/5.0 (Linux; Android 4.4.2; SmartTV) AppleWebKit/537.36 (KHTML, like Gecko) "
                    + "Version/4.0 Chrome/30.0.0 Safari/537.36";

    private static final int PROBE_BYTES = 2048;

    static {
        Tls12.install();
    }

    private Http() {
    }

    public interface Progress {
        void onProgress(int read, int total);
    }

    public static class Res {
        public int code;
        public String body = "";
        public String contentType = "";
        public String finalUrl = "";
        public String error = "";
        /** 重定向目标（用于自己跟随 https→http 这类 Java 不自动跨协议的跳转）。 */
        public String location = "";
        public boolean ok() {
            return code >= 200 && code < 400;
        }
    }

    public static class Probe {
        public int code;
        public String contentType = "";
        public int readLen;
        public boolean audio;
        public String snippet = "";
        public String finalUrl = "";
        public String error = "";
        /** 重定向目标（用于自己跟随 https→http 这类 Java 不自动跨协议的跳转）。 */
        public String location = "";
    }

    public static Map<String, String> headers() {
        Map<String, String> h = new LinkedHashMap<String, String>();
        h.put("User-Agent", UA);
        return h;
    }

    public static Map<String, String> headers(String k1, String v1) {
        Map<String, String> h = headers();
        if (k1 != null) {
            h.put(k1, v1);
        }
        return h;
    }

    public static Map<String, String> headers(String k1, String v1, String k2, String v2) {
        Map<String, String> h = headers(k1, v1);
        if (k2 != null) {
            h.put(k2, v2);
        }
        return h;
    }

    public static String encode(String s) {
        if (s == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        byte[] bytes;
        try {
            bytes = s.getBytes("UTF-8");
        } catch (Exception e) {
            bytes = s.getBytes();
        }
        for (int i = 0; i < bytes.length; i++) {
            int b = bytes[i] & 0xFF;
            boolean safe = (b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9')
                    || b == '-' || b == '_' || b == '.' || b == '~';
            if (safe) {
                sb.append((char) b);
            } else {
                sb.append('%');
                sb.append(Character.toUpperCase(Character.forDigit((b >> 4) & 0xF, 16)));
                sb.append(Character.toUpperCase(Character.forDigit(b & 0xF, 16)));
            }
        }
        return sb.toString();
    }

    public static Res get(String url, Map<String, String> headers) {
        return get(url, headers, 9000, 16000);
    }

    public static Res get(String url, Map<String, String> headers, int connectMs, int readMs) {
        Res res = request(url, null, headers, connectMs, readMs);
        if (res.ok()) {
            return res;
        }
        // Java 自带的重定向跟随不跨协议（https → http 会停住），这里自己再跟几次
        String target = url;
        for (int hop = 0; hop < 4 && isRedirect(res.code); hop++) {
            if (res.location.length() == 0) {
                break;
            }
            target = absoluteUrl(target, res.location);
            res = request(target, null, headers, connectMs, readMs);
        }
        return res;
    }

    /** 301/302/303/307/308 都算重定向。 */
    private static boolean isRedirect(int code) {
        return code == 301 || code == 302 || code == 303 || code == 307 || code == 308;
    }

    /** 把 Location（可能是相对路径）拼成绝对地址。 */
    private static String absoluteUrl(String base, String loc) {
        try {
            return new URL(new URL(base), loc).toString();
        } catch (Throwable t) {
            return loc;
        }
    }

    public static Res post(String url, String form, Map<String, String> headers) {
        Map<String, String> h = headers == null ? new LinkedHashMap<String, String>() : headers;
        h.put("Content-Type", "application/x-www-form-urlencoded");
        return request(url, form, h, 9000, 16000);
    }

    private static Res request(String url, String postBody, Map<String, String> headers,
                               int connectMs, int readMs) {
        Res res = new Res();
        HttpURLConnection conn = null;
        InputStream in = null;
        try {
            URL u = new URL(url);
            conn = (HttpURLConnection) u.openConnection();
            conn.setRequestMethod(postBody == null ? "GET" : "POST");
            conn.setConnectTimeout(connectMs);
            conn.setReadTimeout(readMs);
            conn.setInstanceFollowRedirects(true);
            conn.setUseCaches(false);
            conn.setRequestProperty("Accept-Encoding", "gzip");
            conn.setRequestProperty("Accept", "*/*");
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    if (e.getKey() != null && e.getValue() != null) {
                        conn.setRequestProperty(e.getKey(), e.getValue());
                    }
                }
            }
            if (postBody != null) {
                conn.setDoOutput(true);
                byte[] data = postBody.getBytes("UTF-8");
                conn.setFixedLengthStreamingMode(data.length);
                OutputStream os = conn.getOutputStream();
                os.write(data);
                os.flush();
                os.close();
            }
            res.code = conn.getResponseCode();
            res.finalUrl = String.valueOf(conn.getURL());
            res.contentType = nvl(conn.getContentType());
            res.location = nvl(conn.getHeaderField("Location"));
            in = res.code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (in != null) {
                String encoding = nvl(conn.getContentEncoding());
                if (encoding.toLowerCase().indexOf("gzip") >= 0) {
                    in = new GZIPInputStream(in);
                }
                res.body = readAll(in);
            }
        } catch (Throwable t) {
            res.error = t.getClass().getSimpleName() + ":" + nvl(t.getMessage());
        } finally {
            close(in);
            if (conn != null) {
                conn.disconnect();
            }
        }
        return res;
    }

    /**
     * 只取前 2KB，判断这个地址到底是不是可播的音频流。
     * 这是多线路取流的关键：先验真再交给播放器，避免拿到一段错误页或空白。
     */
    public static Probe probeAudio(String url, Map<String, String> headers) {
        return probeAudio(url, headers, 9000, 14000);
    }

    /**
     * 指定超时的版本：脚本音源这类第三方代理线路给更短的预算，避免拖慢整体取流。
     * 另外自己跟随几次重定向：很多模板型音源的地址是 302 跳到另一台机器（还可能跨 http/https），
     * Java 自带的跟随不跨协议，不补这一下会把可用地址误判成「非音频」。
     */
    public static Probe probeAudio(String url, Map<String, String> headers, int connectMs, int readMs) {
        Probe p = probeOnce(url, headers, connectMs, readMs);
        String target = url;
        for (int hop = 0; hop < 4 && isRedirect(p.code); hop++) {
            if (p.location.length() == 0) {
                break;
            }
            target = absoluteUrl(target, p.location);
            p = probeOnce(target, headers, connectMs, readMs);
        }
        return p;
    }

    private static Probe probeOnce(String url, Map<String, String> headers, int connectMs, int readMs) {
        Probe p = new Probe();
        HttpURLConnection conn = null;
        InputStream in = null;
        try {
            URL u = new URL(url);
            conn = (HttpURLConnection) u.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(connectMs);
            conn.setReadTimeout(readMs);
            conn.setInstanceFollowRedirects(true);
            conn.setUseCaches(false);
            conn.setRequestProperty("Accept", "*/*");
            conn.setRequestProperty("Range", "bytes=0-" + (PROBE_BYTES - 1));
            conn.setRequestProperty("Accept-Encoding", "identity");
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    if (e.getKey() != null && e.getValue() != null) {
                        conn.setRequestProperty(e.getKey(), e.getValue());
                    }
                }
            }
            p.code = conn.getResponseCode();
            p.finalUrl = String.valueOf(conn.getURL());
            p.contentType = nvl(conn.getContentType());
            p.location = nvl(conn.getHeaderField("Location"));
            in = p.code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            byte[] head = new byte[PROBE_BYTES];
            int total = 0;
            if (in != null) {
                while (total < PROBE_BYTES) {
                    int n = in.read(head, total, PROBE_BYTES - total);
                    if (n <= 0) {
                        break;
                    }
                    total += n;
                }
            }
            p.readLen = total;
            p.snippet = snippet(head, total);
            p.audio = isAudio(p.contentType, head, total);
        } catch (Throwable t) {
            p.error = t.getClass().getSimpleName() + ":" + nvl(t.getMessage());
        } finally {
            close(in);
            if (conn != null) {
                conn.disconnect();
            }
        }
        return p;
    }

    public static boolean download(String url, Map<String, String> headers, File dst, Progress progress)
            throws IOException {
        return download(url, headers, dst, progress, 4);
    }

    /** hop 是还能自己跟随的重定向次数（跨 http/https 时 Java 不会自动跟）。 */
    private static boolean download(String url, Map<String, String> headers, File dst, Progress progress,
                                    int hop) throws IOException {
        HttpURLConnection conn = null;
        InputStream in = null;
        OutputStream out = null;
        File tmp = new File(dst.getAbsolutePath() + ".part");
        try {
            URL u = new URL(url);
            conn = (HttpURLConnection) u.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(9000);
            conn.setReadTimeout(20000);
            conn.setInstanceFollowRedirects(true);
            conn.setUseCaches(false);
            conn.setRequestProperty("Accept", "*/*");
            conn.setRequestProperty("Accept-Encoding", "identity");
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    if (e.getKey() != null && e.getValue() != null) {
                        conn.setRequestProperty(e.getKey(), e.getValue());
                    }
                }
            }
            int code = conn.getResponseCode();
            if (isRedirect(code) && hop > 0) {
                String loc = nvl(conn.getHeaderField("Location"));
                if (loc.length() > 0) {
                    return download(absoluteUrl(url, loc), headers, dst, progress, hop - 1);
                }
            }
            if (code >= 400) {
                throw new IOException("HTTP " + code);
            }
            int total = conn.getContentLength();
            in = conn.getInputStream();
            out = new FileOutputStream(tmp);
            byte[] buf = new byte[16384];
            int read = 0;
            while (true) {
                int n = in.read(buf);
                if (n <= 0) {
                    break;
                }
                out.write(buf, 0, n);
                read += n;
                if (progress != null) {
                    progress.onProgress(read, total);
                }
            }
            out.flush();
            out.close();
            out = null;
            if (dst.exists() && !dst.delete()) {
                throw new IOException("无法覆盖旧缓存文件");
            }
            if (!tmp.renameTo(dst)) {
                throw new IOException("无法写入缓存文件");
            }
            return true;
        } finally {
            close(out);
            close(in);
            if (conn != null) {
                conn.disconnect();
            }
            if (tmp.exists() && !dst.exists()) {
                tmp.delete();
            }
        }
    }

    /** 依据 Content-Type 与文件头魔数判断是否音频。 */
    public static boolean isAudio(String contentType, byte[] head, int len) {
        if (len <= 0) {
            return false;
        }
        if (head[0] == 'I' && head[1] == 'D' && head[2] == '3') {
            return true;
        }
        if (len >= 2 && (head[0] & 0xFF) == 0xFF && (head[1] & 0xE0) == 0xE0) {
            return true;
        }
        if (len >= 4 && head[0] == 'f' && head[1] == 'L' && head[2] == 'a' && head[3] == 'C') {
            return true;
        }
        if (len >= 4 && head[0] == 'O' && head[1] == 'g' && head[2] == 'g' && head[3] == 'S') {
            return true;
        }
        if (len >= 12 && head[4] == 'f' && head[5] == 't' && head[6] == 'y' && head[7] == 'p') {
            return true;
        }
        if (len >= 12 && head[0] == 'R' && head[1] == 'I' && head[2] == 'F' && head[3] == 'F'
                && head[8] == 'W' && head[9] == 'A' && head[10] == 'V' && head[11] == 'E') {
            return true;
        }
        String ct = contentType == null ? "" : contentType.toLowerCase();
        // 只认 audio/* 与 mpeg：application/octet-stream 里可能是酷我 .mgg 这类加密封装
        // （实测 320K 档会返回 .mgg，普通播放器打不开），不能因为类型宽松就当成音频。
        return ct.indexOf("audio") >= 0 || ct.indexOf("mpeg") >= 0;
    }

    private static String snippet(byte[] head, int len) {
        StringBuilder sb = new StringBuilder();
        int n = len < 24 ? len : 24;
        for (int i = 0; i < n; i++) {
            int b = head[i] & 0xFF;
            if (b >= 32 && b < 127) {
                sb.append((char) b);
            } else {
                sb.append('.');
            }
        }
        return sb.toString();
    }

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) {
            bos.write(buf, 0, n);
        }
        byte[] data = bos.toByteArray();
        String charset = "UTF-8";
        return new String(data, charset);
    }

    private static void close(java.io.Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (Throwable ignore) {
                // 忽略关闭异常
            }
        }
    }

    private static String nvl(String s) {
        return s == null ? "" : s;
    }
}