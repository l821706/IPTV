package com.freemusic.tv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 封面异步加载 + 内存缓存（不使用任何图片库）。 */
public final class ImageLoader {

    private static final int CACHE_BYTES = 8 * 1024 * 1024;

    private final LruCache<String, Bitmap> memory = new LruCache<String, Bitmap>(CACHE_BYTES) {
        @Override
        protected int sizeOf(String key, Bitmap value) {
            return value.getByteCount();
        }
    };

    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final Handler main = new Handler(Looper.getMainLooper());

    public ImageLoader() {
        Tls12.install();
    }

    public void load(final String url, final ImageView view) {
        if (url == null || url.length() == 0) {
            view.setImageBitmap(null);
            return;
        }
        Bitmap cached = memory.get(url);
        if (cached != null) {
            view.setImageBitmap(cached);
            return;
        }
        view.setTag(url);
        view.setImageBitmap(null);
        pool.execute(new Runnable() {
            @Override
            public void run() {
                final Bitmap bmp = fetch(url);
                if (bmp == null) {
                    return;
                }
                memory.put(url, bmp);
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        if (url.equals(view.getTag())) {
                            view.setImageBitmap(bmp);
                        }
                    }
                });
            }
        });
    }

    public void load(final String url, final VinylCoverView view) {
        if (url == null || url.length() == 0) {
            view.setCover(null);
            return;
        }
        Bitmap cached = memory.get(url);
        if (cached != null) {
            view.setCover(cached);
            return;
        }
        view.setTag(url);
        pool.execute(new Runnable() {
            @Override
            public void run() {
                final Bitmap bmp = fetch(url);
                if (bmp == null) {
                    return;
                }
                memory.put(url, bmp);
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        if (url.equals(view.getTag())) {
                            view.setCover(bmp);
                        }
                    }
                });
            }
        });
    }

    public void clear() {
        memory.evictAll();
    }

    private Bitmap fetch(String url) {
        HttpURLConnection conn = null;
        InputStream in = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(12000);
            conn.setInstanceFollowRedirects(true);
            conn.setUseCaches(false);
            conn.setRequestProperty("User-Agent", Http.UA);
            conn.setRequestProperty("Accept", "image/*,*/*");
            int code = conn.getResponseCode();
            if (code >= 400) {
                return null;
            }
            in = conn.getInputStream();
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            byte[] data = readAll(in, 3 * 1024 * 1024);
            BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
            int sample = 1;
            while (bounds.outWidth / (sample * 2) >= 256 && bounds.outHeight / (sample * 2) >= 256) {
                sample *= 2;
            }
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            opts.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeByteArray(data, 0, data.length, opts);
        } catch (Throwable t) {
            return null;
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Throwable ignore) {
                    // 忽略
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    private byte[] readAll(InputStream in, int max) throws Exception {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) {
            bos.write(buf, 0, n);
            if (bos.size() > max) {
                break;
            }
        }
        return bos.toByteArray();
    }

    public static ImageLoader of(Context ctx) {
        return Holder.INSTANCE;
    }

    private static final class Holder {
        static final ImageLoader INSTANCE = new ImageLoader();
    }
}