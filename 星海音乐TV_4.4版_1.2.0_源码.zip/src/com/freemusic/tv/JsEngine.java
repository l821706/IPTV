package com.freemusic.tv;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

/**
 * 「引擎执行型」音源脚本的运行支撑（QuickJS）。
 *
 * 分工：
 *   * {@link #probe()} 给导入用：把脚本跑一次，拿回它声明的元信息与平台（失败给原因）；
 *   * {@link #sessionFor(String, String)} 给取流用：常驻一个脚本会话，按「平台 + 音质 + 歌曲信息」跑出取流地址，
 *     带结果缓存与失败记忆（短时间内不重复跑同一个失败请求）。
 *
 * 线程模型：Runtime/Context 归一条专用的引擎线程所有（单线程池），所有 native 调用都在那条线程上串行执行；
 * Java 侧只 futures 等待，超时后放弃等待（native 里的中断器会把脚本掐掉）。
 */
public final class JsEngine {

    private JsEngine() {
    }

    /** 引擎线程池（单线程，daemon）。 */
    private static volatile ExecutorService pool;

    private static volatile android.content.Context app;

    /** 由 MainActivity 在启动时注入应用上下文（读 assets 里的 JS 胶水用）。 */
    public static void init(android.content.Context ctx) {
        app = ctx == null ? null : ctx.getApplicationContext();
    }

    public static boolean available() {
        return QuickJs.available();
    }

    private static ExecutorService pool() {
        if (pool == null) {
            synchronized (JsEngine.class) {
                if (pool == null) {
                    pool = Executors.newSingleThreadExecutor(new ThreadFactory() {
                        @Override
                        public Thread newThread(Runnable r) {
                            Thread t = new Thread(r, "js-engine");
                            t.setDaemon(true);
                            return t;
                        }
                    });
                }
            }
        }
        return pool;
    }

    /** 在引擎线程上跑一段活；超时返回 null。 */
    private static <T> T submit(long waitMs, Callable<T> job) {
        try {
            Future<T> f = pool().submit(job);
            return f.get(waitMs, TimeUnit.MILLISECONDS);
        } catch (Throwable t) {
            try {
                android.util.Log.w("StarMusicTV", "脚本引擎调用失败/超时：" + t);
            } catch (Throwable ignore) {
                // JVM 侧无 android.util.Log 实现，忽略
            }
            return null;
        }
    }

    // ---------------- 胶水 ----------------

    private static volatile String glueCache;

    private static String glue() {
        if (glueCache != null) {
            return glueCache;
        }
        android.content.Context ctx = app;
        if (ctx == null) {
            return "";
        }
        try {
            InputStream in = ctx.getAssets().open("js/lx-host.js");
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] tmp = new byte[8192];
            int n;
            while ((n = in.read(tmp)) > 0) {
                buf.write(tmp, 0, n);
            }
            in.close();
            glueCache = new String(buf.toByteArray(), "UTF-8");
        } catch (Throwable t) {
            glueCache = "";
        }
        return glueCache;
    }

    /** 脚本头部注释里的元信息（LX 侧通过 lx.currentScriptInfo 提供给脚本的就是这份信息 + 脚本原文）。 */
    static final class ScriptMeta {
        String name = "";
        String description = "";
        String version = "";
        String author = "";
        String homepage = "";
    }

    /** 解析脚本头部注释（@name/@description/@version/@author/@homepage）；缺项给空串。 */
    static ScriptMeta parseMeta(String script) {
        ScriptMeta m = new ScriptMeta();
        m.name = headerValue(script, "@name");
        m.description = headerValue(script, "@description");
        m.version = headerValue(script, "@version");
        m.author = headerValue(script, "@author");
        m.homepage = headerValue(script, "@homepage");
        return m;
    }

    /** 从脚本头部注释里取 @name / @version（脚本自己声明的元信息）。 */
    static String[] meta(String script) {
        ScriptMeta m = parseMeta(script);
        return new String[]{m.name, m.version};
    }

    /**
     * 装载脚本前交给宿主胶水的元信息 JSON，对应 LX 的 {@code globalThis.lx.currentScriptInfo}：
     * 头部注释解析结果 + 脚本原文 rawScript（脚本会拿它判断版本/完整性）+ 导入来源。
     * 脚本读 {@code lx.currentScriptInfo.version} 这类字段时不能是 undefined，否则脚本直接报错跑不起来。
     */
    public static String scriptMetaJson(String script, String hintName, String sourceUrl,
                                        String nameOverride, String versionOverride) {
        String text = script == null ? "" : script;
        ScriptMeta m = parseMeta(text);
        String name = (nameOverride != null && nameOverride.length() > 0) ? nameOverride : m.name;
        String version = (versionOverride != null && versionOverride.length() > 0) ? versionOverride : m.version;
        StringBuilder sb = new StringBuilder();
        sb.append("{\"name\":").append(JsHost.quote(name));
        sb.append(",\"description\":").append(JsHost.quote(m.description));
        sb.append(",\"version\":").append(JsHost.quote(version));
        sb.append(",\"author\":").append(JsHost.quote(m.author));
        sb.append(",\"homepage\":").append(JsHost.quote(m.homepage));
        sb.append(",\"rawScript\":").append(JsHost.quote(text));
        sb.append(",\"rawScriptPath\":").append(JsHost.quote(hintName == null ? "" : hintName));
        sb.append(",\"source\":").append(JsHost.quote(sourceUrl == null || sourceUrl.length() == 0 ? "local" : sourceUrl));
        sb.append('}');
        return sb.toString();
    }

    /**
     * 从脚本报错堆栈里取第一个可达的「文件:行[:列]」，如 lx-latest.js:13；取不到返回空串。
     * 用于把「脚本执行失败」变成可定位的提示（胶水/元信息这类 eval 拼出来的帧直接跳过）。
     */
    public static String positionOf(String stack) {
        if (stack == null || stack.length() == 0) {
            return "";
        }
        String[] lines = stack.split("\n");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i] == null ? "" : lines[i].trim();
            if (line.length() == 0 || line.indexOf("eval at") >= 0) {
                continue;
            }
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("([^\\s()]+):([0-9]+)(?::([0-9]+))?").matcher(line);
            if (m.find()) {
                String file = m.group(1);
                int slash = file.lastIndexOf('/');
                if (slash >= 0) {
                    file = file.substring(slash + 1);
                }
                String pos = file + ":" + m.group(2);
                if (m.group(3) != null) {
                    pos = pos + ":" + m.group(3);
                }
                return pos;
            }
        }
        return "";
    }

    /**
     * 取头部注释里某个字段的整行值（键后面的整行，去掉行尾的注释收尾标记）。
     * 与 {@link #firstOf} 的区别：地址类字段带 :// 也会完整取回（LX 的 currentScriptInfo 就是整行）。
     */
    private static String headerValue(String text, String key) {
        if (text == null) {
            return "";
        }
        int i = text.indexOf(key);
        if (i < 0) {
            return "";
        }
        int j = i + key.length();
        int e = j;
        while (e < text.length()) {
            char c = text.charAt(e);
            if (c == '\n' || c == '\r') {
                break;
            }
            e++;
        }
        String v = text.substring(j, e).trim();
        while (v.length() > 0) {
            char c = v.charAt(v.length() - 1);
            if (c == '*' || c == '/') {
                v = v.substring(0, v.length() - 1).trim();
            } else {
                break;
            }
        }
        return v;
    }

    // ---------------- 导入试跑 ----------------

    /** 导入时试跑脚本用的探针；引擎不可用时返回 null（调用方回退到既有提示）。 */
    public static SourceStore.EngineProbe probe() {
        return probe("");
    }

    /** 同上，但带上脚本的导入来源（在线地址 / 本地文件），供脚本读 lx.currentScriptInfo 时使用。 */
    public static SourceStore.EngineProbe probe(final String sourceUrl) {
        if (!available()) {
            return null;
        }
        return new SourceStore.EngineProbe() {
            @Override
            public SourceStore.EngineProbe.Result probe(String scriptText, String hintName) {
                return probeScript(scriptText, hintName, sourceUrl, 15000);
            }
        };
    }

    /** 把脚本跑一次，取回元信息与平台。 */
    public static SourceStore.EngineProbe.Result probeScript(final String scriptText, final String hintName,
                                                             final long timeoutMs) {
        return probeScript(scriptText, hintName, "", timeoutMs);
    }

    /** 把脚本跑一次，取回元信息与平台；sourceUrl 为导入来源（可为空）。 */
    public static SourceStore.EngineProbe.Result probeScript(final String scriptText, final String hintName,
                                                             final String sourceUrl, final long timeoutMs) {
        final SourceStore.EngineProbe.Result r = new SourceStore.EngineProbe.Result();
        if (!available()) {
            r.error = "端上脚本引擎不可用（libqjs.so 未加载）";
            return r;
        }
        Boolean ok = submit(timeoutMs + 4000, new Callable<Boolean>() {
            @Override
            public Boolean call() {
                Engine e = null;
                StartError startError = new StartError();
                try {
                    String metaJson = scriptMetaJson(scriptText, hintName, sourceUrl, null, null);
                    e = Engine.startChecked(scriptText, hintName, timeoutMs, startError, metaJson);
                    if (e == null) {
                        r.error = startError.error.length() == 0 ? "引擎启动失败" : startError.error;
                        return Boolean.FALSE;
                    }
                    String wait = e.waitFor("__lxInited", timeoutMs);
                    if (wait == null) {
                        r.error = "脚本没有完成初始化" + e.lastRequestHint() + e.missingHint();
                        return Boolean.FALSE;
                    }
                    Map<String, Object> sources = Json.asMap(Json.parse(e.call("__lxSourcesJson", "", 5000)));
                    if (sources == null || sources.isEmpty()) {
                        r.error = "脚本没有声明可用平台" + e.missingHint();
                        return Boolean.FALSE;
                    }
                    for (Map.Entry<String, Object> en : sources.entrySet()) {
                        String key = en.getKey();
                        r.platforms.add(key);
                        Object node = en.getValue();
                        Object typ = Json.at(node, "type");
                        if (typ != null && "music".equals(String.valueOf(typ)) == false) {
                            continue;
                        }
                        String nm = Json.strAt(node, "name");
                        r.platformNames.put(key, nm.length() == 0 ? key : nm);
                        List<Object> qs = Json.listOrEmpty(Json.at(node, "qualitys"));
                        List<String> list = new ArrayList<String>();
                        for (int i = 0; i < qs.size(); i++) {
                            String q = Json.str(qs.get(i));
                            if (q.length() > 0) {
                                list.add(q);
                            }
                        }
                        r.qualitys.put(key, list);
                    }
                    String[] me = meta(scriptText);
                    r.name = me[0];
                    r.version = me[1];
                    r.ok = r.platforms.size() > 0;
                    if (!r.ok) {
                        r.error = "脚本没有声明可用平台";
                    }
                    return Boolean.valueOf(r.ok);
                } catch (Throwable t) {
                    r.error = String.valueOf(t);
                    return Boolean.FALSE;
                } finally {
                    if (e != null) {
                        e.close();
                    }
                }
            }
        });
        if (ok == null) {
            r.ok = false;
            if (r.error.length() == 0) {
                r.error = "引擎执行超时或失败";
            }
        }
        return r;
    }

    // ---------------- 取流会话 ----------------

    /** 一次脚本取流会话。 */
    public interface Session {
        List<String> platforms();

        String platformName(String key);

        List<String> qualitys(String key);

        /**
         * 跑脚本拿取流地址；拿不到返回空串，原因见 {@link #lastError()}。
         * 调用方是任意线程（内部会切到引擎线程）。
         */
        String fetchUrl(String sourceKey, String qualityKey, Song song);

        String lastError();

        void close();
    }

    /** 会话缓存：最多 2 个，够「内置 + 一个导入音源」用，避免长期驻留占内存。 */
    private static final int MAX_SESSIONS = 2;
    private static final LinkedHashMap<String, Session> SESSIONS = new LinkedHashMap<String, Session>();

    /** 取得（或新建）某个音源的会话；引擎不可用或脚本跑不起来时返回 null。 */
    public static Session sessionFor(final String key, final String scriptText) {
        return sessionFor(key, scriptText, null);
    }

    /**
     * 同上，但显式给一份 lx.currentScriptInfo 元信息（描述文件里的名称/版本 + 脚本原文）。
     * 引擎执行型脚本取流时也会读 currentScriptInfo，缺了同样会报 cannot read property。
     */
    public static Session sessionFor(final String key, final String scriptText, final String metaJson) {
        if (!available() || scriptText == null || scriptText.length() == 0) {
            return null;
        }
        final String meta = (metaJson == null || metaJson.length() == 0)
                ? scriptMetaJson(scriptText, "source.js", "", null, null) : metaJson;
        synchronized (SESSIONS) {
            Session s = SESSIONS.get(key);
            if (s != null) {
                SESSIONS.remove(key);
                SESSIONS.put(key, s);
                return s;
            }
        }
        Session s = open(scriptText, meta);
        if (s == null) {
            return null;
        }
        synchronized (SESSIONS) {
            SESSIONS.put(key, s);
            while (SESSIONS.size() > MAX_SESSIONS) {
                String oldest = SESSIONS.keySet().iterator().next();
                Session victim = SESSIONS.remove(oldest);
                if (victim != null) {
                    victim.close();
                }
            }
        }
        return s;
    }

    /** 清掉会话缓存（音源切换/重新导入时用）。 */
    public static void clearSessions() {
        synchronized (SESSIONS) {
            for (Session s : SESSIONS.values()) {
                if (s != null) {
                    s.close();
                }
            }
            SESSIONS.clear();
        }
    }

    /** 打开一个常驻会话；失败返回 null。 */
    public static Session open(final String scriptText) {
        return open(scriptText, null);
    }

    /** 打开一个常驻会话（metaJson 为 lx.currentScriptInfo 元信息，可空）；失败返回 null。 */
    public static Session open(final String scriptText, final String metaJson) {
        if (!available()) {
            return null;
        }
        Session s = submit(10000, new Callable<Session>() {
            @Override
            public Session call() {
                Engine e = null;
                try {
                    e = Engine.start(scriptText, "source.js", 15000, metaJson);
                    if (e == null) {
                        return null;
                    }
                    e.waitFor("__lxInited", 15000);
                    Map<String, Object> sources = Json.asMap(Json.parse(e.call("__lxSourcesJson", "", 5000)));
                    if (sources == null || sources.isEmpty()) {
                        e.close();
                        return null;
                    }
                    Impl impl = new Impl(e, sources);
                    e = null;
                    return impl;
                } catch (Throwable t) {
                    return null;
                } finally {
                    if (e != null) {
                        e.close();
                    }
                }
            }
        });
        return s;
    }

    /** 会话实现：所有引擎交互都切到引擎线程。 */
    private static final class Impl implements Session {

        private final Engine engine;
        private final List<String> platforms = new ArrayList<String>();
        private final Map<String, String> names = new LinkedHashMap<String, String>();
        private final Map<String, List<String>> qualitys = new LinkedHashMap<String, List<String>>();
        private final Map<String, String> urlCache = new LinkedHashMap<String, String>();
        private final Map<String, Long> failCache = new LinkedHashMap<String, Long>();
        private volatile String lastError = "";
        private volatile boolean closed;

        Impl(Engine engine, Map<String, Object> sources) {
            this.engine = engine;
            for (Map.Entry<String, Object> en : sources.entrySet()) {
                String key = en.getKey();
                Object node = en.getValue();
                Object typ = Json.at(node, "type");
                if (typ != null && !"music".equals(String.valueOf(typ))) {
                    continue;
                }
                platforms.add(key);
                String nm = Json.strAt(node, "name");
                names.put(key, nm.length() == 0 ? key : nm);
                List<Object> qs = Json.listOrEmpty(Json.at(node, "qualitys"));
                List<String> list = new ArrayList<String>();
                for (int i = 0; i < qs.size(); i++) {
                    String q = Json.str(qs.get(i));
                    if (q.length() > 0) {
                        list.add(q);
                    }
                }
                qualitys.put(key, list);
            }
        }

        @Override
        public List<String> platforms() {
            return platforms;
        }

        @Override
        public String platformName(String key) {
            String n = names.get(key);
            return n == null ? key : n;
        }

        @Override
        public List<String> qualitys(String key) {
            List<String> q = qualitys.get(key);
            return q == null ? new ArrayList<String>() : q;
        }

        @Override
        public String lastError() {
            return lastError;
        }

        @Override
        public String fetchUrl(final String sourceKey, final String qualityKey, final Song song) {
            if (closed || sourceKey == null || qualityKey == null || song == null || song.id.length() == 0) {
                return "";
            }
            final String cacheKey = sourceKey + "|" + qualityKey + "|" + song.id;
            synchronized (urlCache) {
                String hit = urlCache.get(cacheKey);
                if (hit != null) {
                    return hit;
                }
            }
            synchronized (failCache) {
                Long at = failCache.get(cacheKey);
                if (at != null && System.currentTimeMillis() - at < 60000) {
                    return "";
                }
                failCache.remove(cacheKey);
            }
            final String payload = payload(sourceKey, qualityKey, song);
            String url = submit(28000, new Callable<String>() {
                @Override
                public String call() {
                    if (closed) {
                        return "";
                    }
                    String started = engine.call("__lxMusicUrl", payload, 0);
                    if (started == null) {
                        lastError = "脚本没跑起来";
                        return "";
                    }
                    if (engine.waitFor("__lxUrlDone", 20000) == null) {
                        lastError = "脚本取流超时";
                        return "";
                    }
                    String url = engine.call("__lxUrlResult", "", 5000);
                    String err = engine.call("__lxUrlError", "", 5000);
                    if (url == null || url.length() == 0) {
                        lastError = err == null || err.length() == 0 ? "脚本没有返回地址" : err;
                        return "";
                    }
                    return url;
                }
            });
            if (url == null || url.length() == 0) {
                synchronized (failCache) {
                    failCache.put(cacheKey, Long.valueOf(System.currentTimeMillis()));
                    while (failCache.size() > 64) {
                        failCache.remove(failCache.keySet().iterator().next());
                    }
                }
                return "";
            }
            synchronized (urlCache) {
                urlCache.put(cacheKey, url);
                while (urlCache.size() > 64) {
                    urlCache.remove(urlCache.keySet().iterator().next());
                }
            }
            return url;
        }

        @Override
        public void close() {
            closed = true;
            submit(4000, new Callable<Boolean>() {
                @Override
                public Boolean call() {
                    engine.close();
                    return Boolean.TRUE;
                }
            });
        }

        /** 组装给脚本的 musicInfo：字段名对各平台取别名（id / songmid / hash），脚本用哪个都能取到。 */
        private static String payload(String sourceKey, String qualityKey, Song song) {
            StringBuilder sb = new StringBuilder();
            String id = song.id == null ? "" : song.id;
            sb.append("{\"source\":\"").append(sourceKey).append("\",\"quality\":\"").append(qualityKey).append("\",");
            sb.append("\"music\":{");
            sb.append("\"id\":").append(JsHost.quote(id)).append(',');
            sb.append("\"songmid\":").append(JsHost.quote(id)).append(',');
            sb.append("\"hash\":").append(JsHost.quote(id)).append(',');
            sb.append("\"name\":").append(JsHost.quote(song.title)).append(',');
            sb.append("\"singer\":").append(JsHost.quote(song.artist)).append(',');
            sb.append("\"albumName\":").append(JsHost.quote(song.album)).append(',');
            sb.append("\"albumId\":\"\",");
            sb.append("\"interval\":").append(song.duration > 0 ? song.duration / 1000 : 0).append(',');
            sb.append("\"source\":").append(JsHost.quote(song.source)).append(',');
            sb.append("\"cover\":").append(JsHost.quote(song.cover)).append("}}");
            return sb.toString();
        }
    }

    /** 引擎启动失败的原因（导入时用来给出可读提示）。 */
    private static final class StartError {
        String error = "";
        /** 出错位置（形如 lx-latest.js:13），取不到为空串。 */
        String position = "";
        /** 脚本读过但宿主没提供的 lx 成员，逗号分隔，取不到为空串。 */
        String missing = "";
    }

    /** 一条引擎实例：Runtime + Context + 已装载的脚本。 */
    private static final class Engine {

        private final long handle;

        private Engine(long handle) {
            this.handle = handle;
        }

        static Engine start(String script, String hintName, long timeoutMs) {
            return startChecked(script, hintName, timeoutMs, null, null);
        }

        static Engine start(String script, String hintName, long timeoutMs, String metaJson) {
            return startChecked(script, hintName, timeoutMs, null, metaJson);
        }

        /** 启动引擎并装载脚本；失败时把原因写进 out（用于导入时的可读提示）。 */
        static Engine startChecked(String script, String hintName, long timeoutMs, StartError out) {
            return startChecked(script, hintName, timeoutMs, out, null);
        }

        /**
         * 启动引擎并装载脚本；失败时把原因（含出错位置、脚本读过但宿主没提供的接口）写进 out。
         * metaJson 是给宿主胶水的 lx.currentScriptInfo 元信息（可为空）。
         */
        static Engine startChecked(String script, String hintName, long timeoutMs, StartError out, String metaJson) {
            String glue = glue();
            if (glue.length() == 0) {
                if (out != null) {
                    out.error = "读不到宿主胶水（assets/js/lx-host.js 缺失）";
                }
                return null;
            }
            long h = QuickJs.nNew(QuickJs.MEM_LIMIT, QuickJs.STACK_LIMIT, JsHost.class);
            if (h == 0) {
                if (out != null) {
                    out.error = "创建引擎实例失败";
                }
                return null;
            }
            Engine e = new Engine(h);
            if (metaJson != null && metaJson.length() > 0) {
                // 顺序：脚本元信息 → 宿主胶水 → 脚本本体（脚本读 lx.currentScriptInfo 时要有值）
                String perr = e.evalError("globalThis.__lxScriptMeta = " + metaJson + ";",
                        "lx-script-meta.js", Math.min(timeoutMs, 8000), null);
                if (perr != null) {
                    if (out != null) {
                        out.error = "宿主元信息注入失败：" + perr;
                    }
                    e.close();
                    return null;
                }
            }
            String err = e.evalError(glue, "lx-host.js", Math.min(timeoutMs, 8000), null);
            if (err != null) {
                if (out != null) {
                    out.error = "宿主胶水执行失败：" + err;
                }
                e.close();
                return null;
            }
            err = e.evalError(script, hintName == null ? "source.js" : hintName, timeoutMs, out);
            if (err != null) {
                String miss = e.missingHint();
                if (out != null) {
                    out.missing = miss;
                    out.error = "脚本执行失败：" + err + miss;
                }
                e.close();
                return null;
            }
            return e;
        }

        /** 执行一段脚本；成功返回 null，失败返回错误文本。 */
        String evalError(String code, String fname, long timeoutMs) {
            return evalError(code, fname, timeoutMs, null);
        }

        /** 执行一段脚本；成功返回 null，失败返回错误文本（可选把「出错位置」写进 out）。 */
        String evalError(String code, String fname, long timeoutMs, StartError out) {
            String ret = QuickJs.nEval(handle, code, fname, timeoutMs);
            if (ret == null) {
                if (out != null) {
                    out.error = "引擎无响应";
                }
                return "引擎无响应";
            }
            Object root = Json.parse(ret);
            if (root != null && Json.bool(Json.at(root, "ok"))) {
                return null;
            }
            String err = root == null ? ret : Json.strAt(root, "error");
            String stack = root == null ? "" : Json.strAt(root, "stack");
            if (stack.length() > 0) {
                try {
                    android.util.Log.w("StarMusicTV", "脚本报错堆栈：" + stack);
                } catch (Throwable ignore) {
                    // JVM 侧忽略
                }
            }
            String msg = err.length() == 0 ? "未知错误" : err;
            String pos = positionOf(stack);
            if (pos.length() > 0) {
                msg = msg + "（出错位置 " + pos + "）";
            }
            if (out != null) {
                out.error = msg;
                out.position = pos;
            }
            return msg;
        }

        /** 脚本读过、但宿主没提供的 lx 成员（例如 lx.currentScriptInfo）；没有缺失时返回空串。 */
        String missingHint() {
            String text = call("__lxMissingText", "", 2000);
            if (text == null || text.length() == 0) {
                return "";
            }
            StringBuilder sb = new StringBuilder();
            String[] names = text.split(",");
            for (int i = 0; i < names.length && i < 6; i++) {
                String n = names[i] == null ? "" : names[i].trim();
                if (n.length() == 0) {
                    continue;
                }
                if (sb.length() > 0) {
                    sb.append('、');
                }
                sb.append("lx.").append(n);
            }
            if (sb.length() == 0) {
                return "";
            }
            return "；脚本读取了宿主未提供的接口：" + sb;
        }

        /** 调一个全局函数（一个字符串参数），返回它的值（字符串化的 JSON）或 null。 */
        String call(String func, String arg, long timeoutMs) {
            String ret = QuickJs.nCall(handle, func, arg == null ? "" : arg, timeoutMs);
            if (ret == null) {
                return null;
            }
            Object root = Json.parse(ret);
            if (root == null) {
                return null;
            }
            if (!Json.bool(Json.at(root, "ok"))) {
                return null;
            }
            Object v = Json.at(root, "value");
            if (v == null) {
                return "";
            }
            String s = Json.str(v);
            return s;
        }

        /** 初始化失败时的诊断：最近一次脚本发起的请求概况（接口不通时最有用）。 */
        String lastRequestHint() {
            String js = call("__lxLastRequestJson", "", 3000);
            if (js == null || js.length() == 0 || "{}".equals(js)) {
                return "（脚本未发起任何请求）";
            }
            Object root = Json.parse(js);
            String url = Json.strAt(root, "url");
            int code = Json.integer(Json.at(root, "statusCode"));
            String err = Json.strAt(root, "error");
            String snippet = Json.strAt(root, "snippet");
            StringBuilder sb = new StringBuilder("：接口 ");
            sb.append(url);
            sb.append(" 返回 ").append(code);
            if (err.length() > 0) {
                sb.append('（').append(err).append('）');
            } else if (snippet.length() > 0) {
                sb.append("，内容前 80 字：").append(snippet.length() > 80 ? snippet.substring(0, 80) : snippet);
            }
            return sb.toString();
        }

        /** 等某个返回布尔的 JS 函数变成真值；超时返回 null。 */
        String waitFor(String condFunc, long timeoutMs) {
            String ret = QuickJs.nWait(handle, condFunc, timeoutMs);
            if (ret == null) {
                return null;
            }
            Object root = Json.parse(ret);
            if (root != null && Json.bool(Json.at(root, "ok"))) {
                return "";
            }
            return null;
        }

        void close() {
            QuickJs.nFree(handle);
        }
    }

    /** 供诊断输出用：把平台与音质拼成一句话。 */
    static String describePlatforms(List<String> keys, Map<String, List<String>> qualitys) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < keys.size(); i++) {
            if (i > 0) {
                sb.append('/');
            }
            sb.append(keys.get(i));
        }
        return sb.toString();
    }
}