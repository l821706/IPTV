package com.freemusic.tv;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 脚本宿主：JS 侧胶水（assets/js/lx-host.js）通过 {@code __nativeHostCall(name, argsJson)} 把
 * 日志、HTTP、utils 三类需求交给这里实现。
 *
 * 约定：
 *   * 全部方法都是静态的，native 侧只认 {@code hostCall(String, String)} 这一个入口；
 *   * 任何异常都不外抛（返回带 error 字段的 JSON），脚本报错不会带崩应用；
 *   * HTTP 直接走 HttpURLConnection：GET/POST、自定义头、raw body、跟随 301/302/303/307/308（含跨协议）、
 *     响应体上限 512KB、gzip 解压、连接 9s / 读 15s。
 */
public final class JsHost {

    private JsHost() {
    }

    private static final int MAX_BODY = 512 * 1024;

    /** native 侧唯一入口。 */
    public static String hostCall(String name, String args) {
        try {
            if ("log".equals(name)) {
                return log(args);
            }
            if ("request".equals(name)) {
                return request(args);
            }
            if ("util".equals(name)) {
                // aes 走单独分支（参数结构不同）
                return util(args);
            }
            if ("event".equals(name)) {
                return event(args);
            }
            return "null";
        } catch (Throwable t) {
            return "{\"error\":" + quote(String.valueOf(t)) + "}";
        }
    }

    private static String log(String args) {
        Object root = Json.parse(args == null ? "{}" : args);
        String level = Json.strAt(root, "level");
        String msg = Json.strAt(root, "msg");
        if ("error".equals(level)) {
            android.util.Log.e("StarMusicTV", "脚本: " + msg);
        } else if ("warn".equals(level)) {
            android.util.Log.w("StarMusicTV", "脚本: " + msg);
        } else {
            android.util.Log.i("StarMusicTV", "脚本: " + msg);
        }
        return "null";
    }

    private static String event(String args) {
        Object root = Json.parse(args == null ? "{}" : args);
        String name = Json.strAt(root, "name");
        if ("inited".equals(name)) {
            android.util.Log.i("StarMusicTV", "脚本已就绪（inited）");
        }
        return "null";
    }

    // ---------------- HTTP ----------------

    private static String request(String args) {
        Object root = Json.parse(args == null ? "{}" : args);
        String url = Json.strAt(root, "url");
        String method = Json.strAt(root, "method");
        if (method.length() == 0) {
            method = "GET";
        }
        int timeoutMs = Json.integer(Json.at(root, "timeoutMs"));
        if (timeoutMs <= 0) {
            timeoutMs = 15000;
        }
        StringBuilder headerJson = new StringBuilder("{");
        Map<String, String> headers = new LinkedHashMap<String, String>();
        Map<String, Object> hs = Json.asMap(Json.at(root, "headers"));
        if (hs != null) {
            int n = 0;
            for (Map.Entry<String, Object> e : hs.entrySet()) {
                String v = Json.str(e.getValue());
                headers.put(e.getKey(), v);
                if (n++ > 0) {
                    headerJson.append(',');
                }
                headerJson.append(quote(e.getKey())).append(':').append(quote(v));
            }
        }
        headerJson.append('}');
        String body = "";
        Object b = Json.at(root, "body");
        if (b != null && !(b instanceof Boolean && !((Boolean) b).booleanValue())) {
            if (b instanceof String) {
                body = (String) b;
            } else {
                body = Json.write(b);
            }
        }
        Http.Res res = doRequest(url, method, headers, body, timeoutMs);
        if (res == null) {
            android.util.Log.w("StarMusicTV", "脚本请求失败(空结果): " + url);
            return "{\"error\":\"request failed\"}";
        }
        if (res.error != null && res.error.length() > 0) {
            android.util.Log.w("StarMusicTV", "脚本请求失败: " + url + " -> " + res.error);
        } else if (res.code >= 400 || isProbablyHtml(res.body)) {
            String head = res.body == null ? "" : res.body;
            android.util.Log.w("StarMusicTV", "脚本请求异常响应: " + url + " -> HTTP " + res.code + " "
                    + (head.length() > 120 ? head.substring(0, 120) : head));
        }
        return "{\"statusCode\":" + res.code + ",\"headers\":" + headerJson + ","
                + "\"bodyText\":" + quote(res.body == null ? "" : res.body) + ","
                + "\"bodyJson\":" + jsonOrNull(res.body) + ","
                + "\"finalUrl\":" + quote(res.finalUrl == null ? "" : res.finalUrl) + ","
                + "\"error\":" + quote(res.error == null ? "" : res.error) + "}";
    }

    /** GET/POST + 跟随重定向（Http 类里的 request 是私有的，这里自己走一遍，保持行为一致）。 */
    private static Http.Res doRequest(String url, String method, Map<String, String> headers,
                                      String body, int timeoutMs) {
        Tls12.install();
        String target = url;
        for (int hop = 0; hop < 5; hop++) {
            Http.Res res = once(target, method, headers, body, timeoutMs);
            if (res == null) {
                return null;
            }
            if (isRedirect(res.code) && res.location.length() > 0) {
                target = absolute(target, res.location);
                method = "GET";
                body = "";
                continue;
            }
            return res;
        }
        return null;
    }

    private static boolean isRedirect(int code) {
        return code == 301 || code == 302 || code == 303 || code == 307 || code == 308;
    }

    private static String absolute(String base, String location) {
        if (location.startsWith("http://") || location.startsWith("https://")) {
            return location;
        }
        try {
            URL u = new URL(base);
            if (location.startsWith("/")) {
                return u.getProtocol() + "://" + u.getHost() + (u.getPort() > 0 ? ":" + u.getPort() : "") + location;
            }
            String path = u.getPath();
            int slash = path.lastIndexOf('/');
            return u.getProtocol() + "://" + u.getHost() + (u.getPort() > 0 ? ":" + u.getPort() : "")
                    + (slash >= 0 ? path.substring(0, slash + 1) : "/") + location;
        } catch (Throwable t) {
            return location;
        }
    }

    private static Http.Res once(String url, String method, Map<String, String> headers,
                                 String body, int timeoutMs) {
        Http.Res res = new Http.Res();
        HttpURLConnection conn = null;
        InputStream in = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestMethod(method == null || method.length() == 0 ? "GET" : method);
            conn.setConnectTimeout(9000);
            conn.setReadTimeout(timeoutMs);
            conn.setInstanceFollowRedirects(false);
            conn.setUseCaches(false);
            conn.setRequestProperty("Accept", "*/*");
            conn.setRequestProperty("Accept-Encoding", "gzip");
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    if (e.getKey() != null && e.getValue() != null) {
                        conn.setRequestProperty(e.getKey(), e.getValue());
                    }
                }
            }
            if (conn.getRequestProperty("User-Agent") == null) {
                conn.setRequestProperty("User-Agent", Http.UA);
            }
            if (body != null && body.length() > 0) {
                conn.setDoOutput(true);
                byte[] data = body.getBytes("UTF-8");
                conn.setFixedLengthStreamingMode(data.length);
                OutputStream os = conn.getOutputStream();
                os.write(data);
                os.flush();
                os.close();
            }
            res.code = conn.getResponseCode();
            res.finalUrl = String.valueOf(conn.getURL());
            res.contentType = conn.getContentType() == null ? "" : conn.getContentType();
            res.location = conn.getHeaderField("Location") == null ? "" : conn.getHeaderField("Location");
            in = res.code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (in != null) {
                String encoding = conn.getContentEncoding() == null ? "" : conn.getContentEncoding();
                if (encoding.toLowerCase().indexOf("gzip") >= 0) {
                    in = new java.util.zip.GZIPInputStream(in);
                }
                res.body = readAll(in);
            }
        } catch (Throwable t) {
            res.error = t.getClass().getSimpleName() + ":" + (t.getMessage() == null ? "" : t.getMessage());
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Throwable ignore) {
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        return res;
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] tmp = new byte[8192];
        int n;
        while ((n = in.read(tmp)) > 0) {
            buf.write(tmp, 0, n);
            if (buf.size() >= MAX_BODY) {
                break;
            }
        }
        return new String(buf.toByteArray(), "UTF-8");
    }

    // ---------------- utils ----------------

    private static String util(String args) {
        String out = "";
        try {
            Object root = Json.parse(args == null ? "{}" : args);
            String name = Json.strAt(root, "name");
            java.util.List<Object> list = Json.listOrEmpty(Json.at(root, "args"));
            String a0 = list.size() > 0 ? Json.str(list.get(0)) : "";
            if ("md5".equals(name)) {
                out = digest("MD5", a0);
            } else if ("sha1".equals(name)) {
                out = digest("SHA-1", a0);
            } else if ("sha256".equals(name)) {
                out = digest("SHA-256", a0);
            } else if ("base64Encode".equals(name) || "str2b64".equals(name)) {
                out = android.util.Base64.encodeToString(a0.getBytes("UTF-8"), android.util.Base64.NO_WRAP);
            } else if ("base64Decode".equals(name) || "b642str".equals(name)) {
                out = new String(android.util.Base64.decode(a0.getBytes("UTF-8"), android.util.Base64.DEFAULT), "UTF-8");
            } else if ("randomBytes".equals(name)) {
                int len = 16;
                try {
                    len = Integer.parseInt(a0.length() == 0 ? "16" : a0);
                } catch (Throwable ignore) {
                }
                byte[] buf = new byte[len <= 0 ? 16 : (len > 64 ? 64 : len)];
                new java.security.SecureRandom().nextBytes(buf);
                out = toHex(buf);
            } else if ("toHex".equals(name)) {
                out = toHex(a0.getBytes("UTF-8"));
            } else if ("aes".equals(name)) {
                String op = Json.strAt(root, "op");
                String data = Json.strAt(root, "data");
                String mode = Json.strAt(root, "mode");
                String key = Json.strAt(root, "key");
                String iv = Json.strAt(root, "iv");
                out = aes(op, data, mode, key, iv);
                if (out.length() == 0) {
                    return "{\"error\":\"aes failed\"}";
                }
                return "{\"value\":" + quote(out) + "}";
            }
        } catch (Throwable t) {
            out = "";
        }
        return "{\"value\":" + quote(out) + "}";
    }

    /**
     * AES 加解密（LX 脚本 signature：aesEncrypt(buffer, mode, key, iv)）。
     * mode 形如 aes-128-cbc / aes-192-cbc / aes-256-cbc / aes-128-ecb；data/key/iv 都是 base64。
     * 返回 base64（失败返回空串）。
     */
    private static String aes(String op, String dataB64, String mode, String keyB64, String ivB64) {
        try {
            byte[] data = android.util.Base64.decode(dataB64, android.util.Base64.DEFAULT);
            byte[] key = android.util.Base64.decode(keyB64, android.util.Base64.DEFAULT);
            String m = mode == null ? "" : mode.toLowerCase();
            String algo = "AES";
            String transformation;
            if (m.indexOf("ecb") >= 0) {
                transformation = "AES/ECB/PKCS5Padding";
            } else {
                transformation = "AES/CBC/PKCS5Padding";
            }
            javax.crypto.Cipher cipher = javax.crypto.Cipher.getInstance(transformation);
            javax.crypto.spec.SecretKeySpec sk = new javax.crypto.spec.SecretKeySpec(key, algo);
            if (m.indexOf("ecb") >= 0) {
                cipher.init("decrypt".equals(op) ? javax.crypto.Cipher.DECRYPT_MODE
                        : javax.crypto.Cipher.ENCRYPT_MODE, sk);
            } else {
                byte[] iv = ivB64 == null || ivB64.length() == 0
                        ? new byte[16]
                        : android.util.Base64.decode(ivB64, android.util.Base64.DEFAULT);
                cipher.init("decrypt".equals(op) ? javax.crypto.Cipher.DECRYPT_MODE
                                : javax.crypto.Cipher.ENCRYPT_MODE, sk,
                        new javax.crypto.spec.IvParameterSpec(iv));
            }
            byte[] out = cipher.doFinal(data);
            return android.util.Base64.encodeToString(out, android.util.Base64.NO_WRAP);
        } catch (Throwable t) {
            try {
                android.util.Log.w("StarMusicTV", "AES 失败（" + mode + "）：" + t);
            } catch (Throwable ignore) {
            }
            return "";
        }
    }

    private static String digest(String algo, String text) {
        try {
            MessageDigest md = MessageDigest.getInstance(algo);
            return toHex(md.digest(text.getBytes("UTF-8")));
        } catch (Throwable t) {
            return "";
        }
    }

    private static String toHex(byte[] buf) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < buf.length; i++) {
            String h = Integer.toHexString(buf[i] & 0xFF);
            if (h.length() == 1) {
                sb.append('0');
            }
            sb.append(h);
        }
        return sb.toString();
    }

    private static boolean isProbablyHtml(String body) {
        if (body == null || body.length() == 0) {
            return false;
        }
        char c = body.charAt(0);
        return c != '{' && c != '[' && body.length() > 4;
    }

    private static String jsonOrNull(String text) {
        if (text == null || text.length() == 0) {
            return "null";
        }
        Object parsed = Json.parse(text);
        return parsed == null ? "null" : Json.write(parsed);
    }

    static String quote(String s) {
        if (s == null) {
            return "\"\"";
        }
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\\') {
                sb.append('\\').append(c);
            } else if (c == '\n') {
                sb.append("\\n");
            } else if (c == '\r') {
                sb.append("\\r");
            } else if (c == '\t') {
                sb.append("\\t");
            } else if (c < 0x20) {
                sb.append(' ');
            } else if (c == 0x2028 || c == 0x2029) {
                // 这两个是 JS 里的行分隔符（不能在 Java 里写成字符字面量，会被 javac 当换行），改成转义写法
                sb.append(String.format("\\u%04x", (int) c));
            } else {
                sb.append(c);
            }
        }
        return sb.append('"').toString();
    }
}