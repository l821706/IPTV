package com.freemusic.tv;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 极简 JSON 解析器。
 * 之所以自写而不使用 org.json / Gson：一是 Android 4.4 上不引入任何第三方依赖，
 * 二是同一份代码可以脱离 Android 直接在 JVM 上运行，便于对取流链路做真实联网验证。
 */
public final class Json {

    private Json() {
    }

    /** 把解析出来的结构（Map / List / String / Number / Boolean / null）重新序列化成 JSON 文本。 */
    public static String write(Object o) {
        StringBuilder sb = new StringBuilder();
        writeTo(sb, o);
        return sb.toString();
    }

    private static void writeTo(StringBuilder sb, Object o) {
        if (o == null) {
            sb.append("null");
            return;
        }
        if (o instanceof Map) {
            sb.append('{');
            int n = 0;
            for (Map.Entry<?, ?> e : ((Map<?, ?>) o).entrySet()) {
                if (n++ > 0) {
                    sb.append(',');
                }
                escapeTo(sb, String.valueOf(e.getKey()));
                sb.append(':');
                writeTo(sb, e.getValue());
            }
            sb.append('}');
            return;
        }
        if (o instanceof java.util.List) {
            sb.append('[');
            java.util.List<?> list = (java.util.List<?>) o;
            for (int i = 0; i < list.size(); i++) {
                if (i > 0) {
                    sb.append(',');
                }
                writeTo(sb, list.get(i));
            }
            sb.append(']');
            return;
        }
        if (o instanceof Boolean || o instanceof Number) {
            sb.append(String.valueOf(o));
            return;
        }
        escapeTo(sb, String.valueOf(o));
    }

    private static void escapeTo(StringBuilder sb, String s) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\\') {
                sb.append('\\').append(c);
            } else if (c == '\n') {
                sb.append("\\n");
            } else if (c == '\r') {
                sb.append("\\r");
            } else if (c == '\t') {
                sb.append("\\t");
            } else if (c < 0x20) {
                sb.append(' ');
            } else {
                sb.append(c);
            }
        }
        sb.append('"');
    }

    public static Object parse(String text) {
        if (text == null) {
            return null;
        }
        Parser p = new Parser(text);
        p.skipWs();
        if (p.end()) {
            return null;
        }
        try {
            return p.value();
        } catch (RuntimeException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> asMap(Object o) {
        if (o instanceof Map) {
            return (Map<String, Object>) o;
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    public static List<Object> asList(Object o) {
        if (o instanceof List) {
            return (List<Object>) o;
        }
        return null;
    }

    public static String str(Object o) {
        if (o == null) {
            return "";
        }
        if (o instanceof String) {
            return (String) o;
        }
        if (o instanceof Double) {
            double d = (Double) o;
            if (d == Math.rint(d) && !Double.isInfinite(d)) {
                return String.valueOf((long) d);
            }
            return String.valueOf(d);
        }
        return String.valueOf(o);
    }

    public static long lon(Object o) {
        if (o instanceof Double) {
            return (long) ((Double) o).doubleValue();
        }
        if (o instanceof String) {
            try {
                return (long) Double.parseDouble((String) o);
            } catch (RuntimeException e) {
                return 0L;
            }
        }
        return 0L;
    }

    public static int integer(Object o) {
        return (int) lon(o);
    }

    public static boolean bool(Object o) {
        if (o instanceof Boolean) {
            return (Boolean) o;
        }
        return "true".equals(o);
    }

    /** 依次按路径取子节点，路径中每段既可以是对象键名，也可以是数组下标（数字串）。 */
    public static Object at(Object node, String... path) {
        Object cur = node;
        for (int i = 0; i < path.length; i++) {
            if (cur == null) {
                return null;
            }
            String key = path[i];
            if (cur instanceof Map) {
                cur = ((Map<String, Object>) cur).get(key);
            } else if (cur instanceof List) {
                int idx;
                try {
                    idx = Integer.parseInt(key);
                } catch (RuntimeException e) {
                    return null;
                }
                List<Object> list = (List<Object>) cur;
                if (idx < 0 || idx >= list.size()) {
                    return null;
                }
                cur = list.get(idx);
            } else {
                return null;
            }
        }
        return cur;
    }

    public static String strAt(Object node, String... path) {
        return str(at(node, path));
    }

    public static long lonAt(Object node, String... path) {
        return lon(at(node, path));
    }

    public static List<Object> listAt(Object node, String... path) {
        return listOrEmpty(at(node, path));
    }

    public static List<Object> listOrEmpty(Object o) {
        List<Object> l = asList(o);
        if (l == null) {
            l = new ArrayList<Object>();
        }
        return l;
    }

    /** 反转义常见 HTML 实体（各平台返回的歌名/歌手名里经常带实体）。 */
    public static String html(String s) {
        if (s == null) {
            return "";
        }
        if (s.indexOf('&') < 0) {
            return s;
        }
        String r = s;
        r = r.replace("&nbsp;", " ");
        r = r.replace("&amp;", "&");
        r = r.replace("&lt;", "<");
        r = r.replace("&gt;", ">");
        r = r.replace("&quot;", "\"");
        r = r.replace("&apos;", "'");
        r = r.replace("&#39;", "'");
        r = r.replace("&#039;", "'");
        r = r.replace("&#x27;", "'");
        return r;
    }

    private static final class Parser {
        private final String s;
        private int i;

        Parser(String s) {
            this.s = s;
        }

        boolean end() {
            return i >= s.length();
        }

        void skipWs() {
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == ' ' || c == '\n' || c == '\r' || c == '\t') {
                    i++;
                } else {
                    break;
                }
            }
        }

        Object value() {
            skipWs();
            if (end()) {
                throw new RuntimeException("eof");
            }
            char c = s.charAt(i);
            switch (c) {
                case '{':
                    return object();
                case '[':
                    return array();
                case '"':
                case '\'':
                    return string(c);
                case 't':
                    expect("true");
                    return Boolean.TRUE;
                case 'f':
                    expect("false");
                    return Boolean.FALSE;
                case 'n':
                    expect("null");
                    return null;
                default:
                    return number();
            }
        }

        void expect(String word) {
            if (s.startsWith(word, i)) {
                i += word.length();
            } else {
                throw new RuntimeException("bad literal");
            }
        }

        Map<String, Object> object() {
            Map<String, Object> map = new LinkedHashMap<String, Object>();
            i++;
            skipWs();
            if (!end() && s.charAt(i) == '}') {
                i++;
                return map;
            }
            while (!end()) {
                skipWs();
                char c = s.charAt(i);
                String key;
                if (c == '"' || c == '\'') {
                    key = string(c);
                } else {
                    int start = i;
                    while (i < s.length() && s.charAt(i) != ':') {
                        i++;
                    }
                    key = s.substring(start, i).trim();
                }
                skipWs();
                if (end() || s.charAt(i) != ':') {
                    throw new RuntimeException("expect :");
                }
                i++;
                map.put(key, value());
                skipWs();
                if (end()) {
                    break;
                }
                char n = s.charAt(i);
                if (n == ',') {
                    i++;
                } else if (n == '}') {
                    i++;
                    break;
                } else {
                    throw new RuntimeException("expect , or }");
                }
            }
            return map;
        }

        List<Object> array() {
            List<Object> list = new ArrayList<Object>();
            i++;
            skipWs();
            if (!end() && s.charAt(i) == ']') {
                i++;
                return list;
            }
            while (!end()) {
                list.add(value());
                skipWs();
                if (end()) {
                    break;
                }
                char n = s.charAt(i);
                if (n == ',') {
                    i++;
                } else if (n == ']') {
                    i++;
                    break;
                } else {
                    throw new RuntimeException("expect , or ]");
                }
            }
            return list;
        }

        String string(char quote) {
            i++;
            StringBuilder sb = new StringBuilder();
            while (i < s.length()) {
                char c = s.charAt(i++);
                if (c == quote) {
                    break;
                }
                if (c == '\\' && i < s.length()) {
                    char e = s.charAt(i++);
                    switch (e) {
                        case 'n':
                            sb.append('\n');
                            break;
                        case 't':
                            sb.append('\t');
                            break;
                        case 'r':
                            sb.append('\r');
                            break;
                        case 'b':
                            sb.append('\b');
                            break;
                        case 'f':
                            sb.append('\f');
                            break;
                        case '/':
                            sb.append('/');
                            break;
                        case 'u':
                            if (i + 4 <= s.length()) {
                                String hex = s.substring(i, i + 4);
                                i += 4;
                                try {
                                    sb.append((char) Integer.parseInt(hex, 16));
                                } catch (RuntimeException ignore) {
                                    // 非法转义按原样丢弃
                                }
                            }
                            break;
                        default:
                            sb.append(e);
                    }
                } else {
                    sb.append(c);
                }
            }
            return sb.toString();
        }

        Object number() {
            int start = i;
            while (i < s.length()) {
                char c = s.charAt(i);
                if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E') {
                    i++;
                } else {
                    break;
                }
            }
            String num = s.substring(start, i);
            if (num.length() == 0) {
                throw new RuntimeException("bad number");
            }
            try {
                return Double.valueOf(num);
            } catch (RuntimeException e) {
                throw new RuntimeException("bad number " + num);
            }
        }
    }
}