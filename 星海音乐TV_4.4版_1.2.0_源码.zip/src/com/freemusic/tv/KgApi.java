package com.freemusic.tv;

import java.util.ArrayList;
import java.util.List;

/** 酷狗音乐搜索接口（搜索可用；直链接口目前对外不可用，播放交由跨平台兜底完成）。 */
public final class KgApi {

    private KgApi() {
    }

    public static List<Song> search(String keyword, int limit) {
        List<Song> out = new ArrayList<Song>();
        if (keyword == null || keyword.trim().length() == 0) {
            return out;
        }
        String url = "http://mobilecdn.kugou.com/api/v3/search/song?format=json&keyword="
                + Http.encode(keyword) + "&page=1&pagesize=" + limit;
        Http.Res res = Http.get(url, Http.headers());
        if (!res.ok()) {
            return out;
        }
        Object root = Json.parse(res.body);
        List<Object> info = Json.listAt(root, "data", "info");
        for (int i = 0; i < info.size() && out.size() < limit; i++) {
            Object node = info.get(i);
            String hash = Json.strAt(node, "hash");
            if (hash.length() == 0) {
                continue;
            }
            String title = Json.html(Json.strAt(node, "songname"));
            String artist = Json.html(Json.strAt(node, "singername"));
            String album = Json.html(Json.strAt(node, "album_name"));
            String albumId = Json.strAt(node, "album_id");
            long duration = Json.lonAt(node, "duration");
            String cover = albumId.length() > 0 && !"0".equals(albumId)
                    ? "http://imge.kugou.com/stdmusic/240/" + albumId + ".jpg" : "";
            out.add(new Song(title, artist, album, Song.SRC_KG, hash, albumId, cover, (int) (duration * 1000)));
        }
        return out;
    }
}