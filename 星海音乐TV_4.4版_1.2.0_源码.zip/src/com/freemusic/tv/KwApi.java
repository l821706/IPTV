package com.freemusic.tv;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.Inflater;

/**
 * 酷我音乐「官方三接口」。全部走酷我官方域名，不再经过任何第三方代理
 * （原 antiserver.kuwo.cn/anti.s 线路已移除）。
 *
 *   1) 搜索  http://nmobi.kuwo.cn/mobi.s?f=web&type=search&all=&lt;kw&gt;&pn=0&rn=&lt;n&gt;&ft=music&encoding=utf8
 *            → 8 字节小端头（压缩长度、原始长度）+ zlib 文本；文本首部为 TP=list / HIT / HITMODE，
 *              其后每条记录由「键=值」行组成、记录之间以空行分隔。
 *   2) 取流  http://nmobi.kuwo.cn/mobi.s?f=web&source=kwplayer_ar_5.1.0.0&type=convert_url_with_sign&br=&lt;br&gt;&rid=&lt;rid&gt;
 *            → JSON {"code":200,"data":{"url":"http://kw-*.kuwo.cn/...mp3","bitrate":128,"format":"mp3","duration":210}}
 *              实测返回的地址取前 2KB 是真音频（ID3/MP3 头）。br=128 → 128K mp3，br=48 → 48K aac，更高档位需会员故不生效。
 *   3) 歌词  http://m.kuwo.cn/newh5/singles/songinfoandlrc?musicId=&lt;rid&gt;
 *            → JSON {"data":{"lrclist":[{"lineLyric":"...","time":"0.0"}]}}，明文逐行歌词。
 *              nmobi 也有 type=lyric，但内容为加密载荷（TP=content\lrcx=1 + zlib + 酷我自定义加密），
 *              端上解不开，因此歌词取同为酷我官方的明文接口。
 *
 * 兼容保留：nmobi 搜索无结果时，回退到酷我官方搜索域名 search.kuwo.cn/r.s（返回 JS 对象字面量，
 * 用容错键值扫描器解析），仅作兜底，正常搜索路径仍然是 nmobi 官方接口。
 */
public final class KwApi {

    /** nmobi 移动端接口，酷我官方三接口中的搜索与取流都走这里。 */
    private static final String MOBI = "http://nmobi.kuwo.cn/mobi.s";

    /** 酷我官方明文歌词接口。 */
    private static final String LYRIC = "http://m.kuwo.cn/newh5/singles/songinfoandlrc?musicId=";

    /** 兼容兜底：酷我官方搜索域名（nmobi 搜索取不到结果时才用）。 */
    private static final String SEARCH = "http://search.kuwo.cn/r.s";

    private static final String KW_UA = "kwplayer_ar_9.2.2.1";

    private KwApi() {
    }

    // ------------------------------------------------------------------ 搜索

    public static List<Song> search(String keyword, int limit) {
        List<Song> out = new ArrayList<Song>();
        if (keyword == null || keyword.trim().length() == 0) {
            return out;
        }
        int rn = Math.max(limit, 20);
        String url = MOBI + "?f=web&type=search&all=" + Http.encode(keyword)
                + "&pn=0&rn=" + rn + "&ft=music&encoding=utf8";
        List<Map<String, String>> recs = parseMobiList(getBytes(url));
        for (int i = 0; i < recs.size(); i++) {
            Song s = toSong(recs.get(i));
            if (s != null) {
                out.add(s);
            }
        }
        if (out.isEmpty()) {
            out.addAll(searchLegacy(keyword, limit));
            return out;
        }
        // nmobi 搜索结果里「片段」类试听片段往往排在最前，播放只有十几秒。
        // 这里做一次稳定分区：完整歌曲在前、片段类在后，不丢弃任何结果。
        List<Song> full = new ArrayList<Song>();
        List<Song> clips = new ArrayList<Song>();
        for (int i = 0; i < out.size(); i++) {
            Song s = out.get(i);
            if (isClip(s)) {
                clips.add(s);
            } else {
                full.add(s);
            }
        }
        full.addAll(clips);
        if (full.size() > limit) {
            return new ArrayList<Song>(full.subList(0, limit));
        }
        return full;
    }

    private static boolean isClip(Song s) {
        return s.title.indexOf("片段") >= 0 || (s.duration > 0 && s.duration < 60000);
    }

    private static Song toSong(Map<String, String> rec) {
        String rid = stripPrefix(rec.get("MUSICRID"), "MUSIC_");
        if (rid.length() == 0) {
            return null;
        }
        String title = Json.html(rec.get("SONGNAME"));
        String artist = Json.html(rec.get("ARTIST"));
        String album = Json.html(rec.get("ALBUM"));
        int duration = 0;
        try {
            duration = Integer.parseInt(rec.get("DURATION")) * 1000;
        } catch (RuntimeException ignore) {
            duration = 0;
        }
        // nmobi 搜索接口不返回封面地址，界面会按歌名首字生成贴纸兜底。
        return new Song(title, artist, album, Song.SRC_KW, rid, "MUSIC_" + rid, "", duration);
    }

    /** 解析 nmobi 列表型返回：8 字节头 + zlib 文本 + 「键=值」记录块。 */
    private static List<Map<String, String>> parseMobiList(byte[] raw) {
        List<Map<String, String>> out = new ArrayList<Map<String, String>>();
        String text = inflate(raw);
        if (text.length() == 0) {
            return out;
        }
        Map<String, String> cur = new LinkedHashMap<String, String>();
        int start = 0;
        while (start <= text.length()) {
            int nl = text.indexOf('\n', start);
            String line = nl < 0 ? text.substring(start) : text.substring(start, nl);
            start = nl < 0 ? text.length() + 1 : nl + 1;
            if (line.endsWith("\r")) {
                line = line.substring(0, line.length() - 1);
            }
            if (line.length() == 0) {
                if (cur.size() > 0) {
                    out.add(cur);
                    cur = new LinkedHashMap<String, String>();
                }
                continue;
            }
            int eq = line.indexOf('=');
            if (eq > 0) {
                cur.put(line.substring(0, eq), line.substring(eq + 1));
            }
        }
        if (cur.size() > 0) {
            out.add(cur);
        }
        return out;
    }

    /**
     * nmobi 返回体：前 8 字节是小端长度头（压缩长度、原始长度），其后是 zlib 流。
     * 若首个字节就是 zlib 头（0x78）则视为没有头部的裸压缩体。
     */
    private static String inflate(byte[] raw) {
        if (raw == null || raw.length < 4) {
            return "";
        }
        int off = (raw[0] & 0xFF) == 0x78 ? 0 : 8;
        if (off >= raw.length - 2) {
            return "";
        }
        String text = inflateAt(raw, off, false);
        if (text.length() == 0) {
            text = inflateAt(raw, off, true);
        }
        return text;
    }

    private static String inflateAt(byte[] raw, int off, boolean rawDeflate) {
        Inflater inf = new Inflater(rawDeflate);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            inf.setInput(raw, off, raw.length - off);
            byte[] buf = new byte[4096];
            while (!inf.finished() && out.size() < 4 * 1024 * 1024) {
                int n;
                try {
                    n = inf.inflate(buf);
                } catch (Exception e) {
                    return "";
                }
                if (n == 0) {
                    if (inf.needsInput() || inf.needsDictionary()) {
                        break;
                    }
                    continue;
                }
                out.write(buf, 0, n);
            }
        } catch (Throwable t) {
            return "";
        } finally {
            inf.end();
        }
        try {
            return new String(out.toByteArray(), "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    // ------------------------------------------------------------------ 取流

    /** 官方取流接口，失败返回空串。br 为数字档位：128（mp3 128K）、48（aac 48K）。 */
    public static String playUrl(String rid, String br) {
        String r = stripPrefix(rid, "MUSIC_");
        if (r.length() == 0) {
            return "";
        }
        String url = MOBI + "?f=web&source=kwplayer_ar_5.1.0.0&type=convert_url_with_sign&br="
                + (br == null || br.length() == 0 ? "128" : br) + "&rid=" + r;
        Http.Res res = Http.get(url, Http.headers("User-Agent", KW_UA));
        if (!res.ok()) {
            return "";
        }
        Object root = Json.parse(res.body);
        String u = Json.strAt(root, "data", "url");
        if (u == null || u.length() == 0 || "null".equals(u)) {
            return "";
        }
        return u;
    }

    public static String playUrlMp3(String rid) {
        return playUrl(rid, "128");
    }

    public static String playUrlMp3(String rid, int quality) {
        // 官方接口免费档只有 128K mp3 与 48K aac，更高档位由上游返回 128K，这里不再区分。
        return playUrlMp3(rid);
    }

    // ------------------------------------------------------------------ 歌词

    /** 酷我官方明文歌词，返回标准 LRC 文本，取不到返回空串。 */
    public static String lyric(String rid) {
        String r = stripPrefix(rid, "MUSIC_");
        if (r.length() == 0) {
            return "";
        }
        Http.Res res = Http.get(LYRIC + r, Http.headers());
        if (!res.ok()) {
            return "";
        }
        Object root = Json.parse(res.body);
        List<Object> lines = Json.listAt(root, "data", "lrclist");
        if (lines == null || lines.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            Map<String, Object> it = Json.asMap(lines.get(i));
            if (it == null) {
                continue;
            }
            String text = Json.str(it.get("lineLyric"));
            if (text == null || text.length() == 0) {
                continue;
            }
            sb.append('[').append(stamp(Json.str(it.get("time")))).append(']').append(text).append('\n');
        }
        return sb.toString();
    }

    /** 秒（可带小数）→ LRC 时间戳 mm:ss.xx。 */
    private static String stamp(String seconds) {
        double sec = 0;
        try {
            sec = Double.parseDouble(seconds);
        } catch (RuntimeException ignore) {
            sec = 0;
        }
        int total = (int) Math.round(sec * 100);
        int mm = total / 6000;
        int ss = (total / 100) % 60;
        int cs = total % 100;
        StringBuilder sb = new StringBuilder();
        if (mm < 10) {
            sb.append('0');
        }
        sb.append(mm).append(':');
        if (ss < 10) {
            sb.append('0');
        }
        sb.append(ss).append('.');
        if (cs < 10) {
            sb.append('0');
        }
        sb.append(cs);
        return sb.toString();
    }

    // ------------------------------------------------------------------ 兼容兜底

    /** nmobi 搜索无结果时的兜底：酷我官方搜索域名，返回 JS 对象字面量。 */
    private static List<Song> searchLegacy(String keyword, int limit) {
        List<Song> out = new ArrayList<Song>();
        String url = SEARCH + "?all=" + Http.encode(keyword)
                + "&ft=music&itemset=web_2013&client=kt&pn=0&rn=" + limit
                + "&rformat=json&encoding=utf8";
        Http.Res res = Http.get(url, Http.headers());
        if (!res.ok()) {
            return out;
        }
        List<Map<String, String>> items = parseJsObjectArray(res.body, "abslist");
        for (int i = 0; i < items.size() && out.size() < limit; i++) {
            Map<String, String> it = items.get(i);
            String rid = stripPrefix(first(it, "DC_TARGETID", "MUSICRID"), "MUSIC_");
            if (rid.length() == 0) {
                continue;
            }
            String title = Json.html(unescape(first(it, "NAME", "SONGNAME")));
            String artist = Json.html(unescape(first(it, "ARTIST", "AARTIST")));
            String album = Json.html(unescape(first(it, "ALBUM")));
            String cover = first(it, "PICPATH");
            if (!cover.startsWith("http")) {
                cover = "";
            }
            int duration = 0;
            try {
                duration = (int) (Double.parseDouble(first(it, "DURATION")) * 1000);
            } catch (RuntimeException ignore) {
                duration = 0;
            }
            out.add(new Song(title, artist, album, Song.SRC_KW, rid, "MUSIC_" + rid, cover, duration));
        }
        return out;
    }

    // ------------------------------------------------------------------ 工具

    /** 需要按字节处理的返回体（nmobi 的列表接口是压缩流），Http.Res 只保留文本，这里单独取字节。 */
    private static byte[] getBytes(String url) {
        HttpURLConnection conn = null;
        InputStream in = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(9000);
            conn.setReadTimeout(16000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", KW_UA);
            int code = conn.getResponseCode();
            if (code < 200 || code >= 400) {
                return null;
            }
            in = conn.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0 && out.size() < 1024 * 1024) {
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        } catch (Throwable t) {
            return null;
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Throwable ignore) {
                // 关闭失败不影响结果
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    private static String stripPrefix(String s, String prefix) {
        if (s == null) {
            return "";
        }
        if (s.startsWith(prefix)) {
            return s.substring(prefix.length());
        }
        return s;
    }

    private static String first(Map<String, String> m, String... keys) {
        for (int i = 0; i < keys.length; i++) {
            String v = m.get(keys[i]);
            if (v != null && v.length() > 0) {
                return v;
            }
        }
        return "";
    }

    private static String unescape(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("\\'", "'").replace("\\\"", "\"").replace("\\/", "/");
    }

    /** 从 "{'a':'b'}" 这种片段里抽取键值对。 */
    private static Map<String, String> kv(String obj) {
        Map<String, String> map = new LinkedHashMap<String, String>();
        int i = 1;
        while (i < obj.length() - 1) {
            char c = obj.charAt(i);
            if (c != '\'' && c != '"') {
                i++;
                continue;
            }
            char quote = c;
            int keyEnd = findQuoteEnd(obj, i, quote);
            if (keyEnd < 0) {
                break;
            }
            String key = obj.substring(i + 1, keyEnd);
            int j = keyEnd + 1;
            while (j < obj.length() && obj.charAt(j) != ':') {
                j++;
            }
            if (j >= obj.length()) {
                break;
            }
            j++;
            if (j >= obj.length()) {
                break;
            }
            String value;
            char vc = obj.charAt(j);
            if (vc == '\'' || vc == '"') {
                int vEnd = findQuoteEnd(obj, j, vc);
                if (vEnd < 0) {
                    value = obj.substring(j + 1);
                    i = obj.length();
                } else {
                    value = obj.substring(j + 1, vEnd);
                    i = vEnd + 1;
                }
            } else {
                int vEnd = j;
                while (vEnd < obj.length() && obj.charAt(vEnd) != ',' && obj.charAt(vEnd) != '}') {
                    vEnd++;
                }
                value = obj.substring(j, vEnd).trim();
                i = vEnd;
            }
            map.put(key, value);
        }
        return map;
    }

    private static int findQuoteEnd(String s, int start, char quote) {
        int i = start + 1;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '\\') {
                i += 2;
                continue;
            }
            if (c == quote) {
                return i;
            }
            i++;
        }
        return -1;
    }

    /** 定位 "key:[{...},{...}]" 并逐个还原其中的对象文本。fish 音源的交叉匹配也复用它。 */
    static List<Map<String, String>> parseJsObjectArray(String body, String key) {
        List<Map<String, String>> out = new ArrayList<Map<String, String>>();
        if (body == null) {
            return out;
        }
        int at = body.indexOf(key);
        if (at < 0) {
            return out;
        }
        int open = body.indexOf('[', at);
        if (open < 0) {
            return out;
        }
        int depth = 0;
        int start = -1;
        for (int i = open; i < body.length(); i++) {
            char c = body.charAt(i);
            if (c == '{') {
                if (depth == 0) {
                    start = i;
                }
                depth++;
            } else if (c == '}') {
                depth--;
                if (depth == 0 && start >= 0) {
                    out.add(kv(body.substring(start, i + 1)));
                    start = -1;
                }
            } else if (c == ']' && depth == 0) {
                break;
            }
        }
        return out;
    }
}