package com.freemusic.tv;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * 两列文本列表适配器，用于榜单分类与设置项。
 * 与 SongAdapter 同理：列表项自己持有焦点，必须自己处理确认键，
 * 否则遥控器按 OK 会被列表项吞掉、什么都不发生。
 */
public class LineAdapter extends BaseAdapter {

    public static class Item {
        public String text;
        public String value;
        public int tag;

        public Item(String text, String value, int tag) {
            this.text = text;
            this.value = value;
            this.tag = tag;
        }
    }

    public interface OnClick {
        void onClick(int position, Item item);
    }

    private final Context ctx;
    private final List<Item> data = new ArrayList<Item>();
    private OnClick click;

    public LineAdapter(Context ctx) {
        this.ctx = ctx;
    }

    public void setClickListener(OnClick l) {
        this.click = l;
    }

    public void setData(List<Item> items) {
        data.clear();
        if (items != null) {
            data.addAll(items);
        }
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            v = LayoutInflater.from(ctx).inflate(R.layout.item_text, parent, false);
        }
        Item item = data.get(position);
        TextView text = (TextView) v.findViewById(R.id.itmText);
        TextView value = (TextView) v.findViewById(R.id.itmValue);
        text.setText(item.text);
        value.setText(item.value == null ? "" : item.value);
        v.setClickable(true);
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (click != null) {
                    click.onClick(position, data.get(position));
                }
            }
        });
        return v;
    }
}