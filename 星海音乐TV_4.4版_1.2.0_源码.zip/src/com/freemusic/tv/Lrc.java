package com.freemusic.tv;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** LRC 歌词解析：按时间轴排序，支持逐行高亮定位。 */
public final class Lrc {

    public static class Line {
        public int time;
        public String text;

        Line(int time, String text) {
            this.time = time;
            this.text = text;
        }
    }

    private final List<Line> lines = new ArrayList<Line>();

    public static Lrc parse(String raw) {
        Lrc lrc = new Lrc();
        if (raw == null || raw.length() == 0) {
            return lrc;
        }
        String[] rows = raw.replace("\r", "").split("\n");
        for (int r = 0; r < rows.length; r++) {
            String row = rows[r].trim();
            if (row.length() == 0) {
                continue;
            }
            int idx = 0;
            boolean matched = false;
            while (idx < row.length() && row.charAt(idx) == '[') {
                int close = row.indexOf(']', idx);
                if (close < 0) {
                    break;
                }
                String tag = row.substring(idx + 1, close);
                int time = parseTime(tag);
                if (time >= 0) {
                    String text = row.substring(close + 1).trim();
                    lrc.lines.add(new Line(time, text));
                    matched = true;
                }
                idx = close + 1;
            }
            if (!matched && !row.startsWith("[") ) {
                lrc.lines.add(new Line(-1, row));
            }
        }
        Collections.sort(lrc.lines, new Comparator<Line>() {
            @Override
            public int compare(Line a, Line b) {
                return a.time - b.time;
            }
        });
        return lrc;
    }

    private static int parseTime(String tag) {
        if (tag.length() < 4) {
            return -1;
        }
        int colon = tag.indexOf(':');
        if (colon <= 0) {
            return -1;
        }
        try {
            int minutes = Integer.parseInt(tag.substring(0, colon).trim());
            String rest = tag.substring(colon + 1).trim();
            int dot = rest.indexOf('.');
            int seconds;
            int millis = 0;
            if (dot >= 0) {
                seconds = Integer.parseInt(rest.substring(0, dot));
                String frac = rest.substring(dot + 1);
                if (frac.length() > 3) {
                    frac = frac.substring(0, 3);
                }
                while (frac.length() < 3) {
                    frac = frac + "0";
                }
                millis = Integer.parseInt(frac);
            } else {
                seconds = Integer.parseInt(rest);
            }
            return minutes * 60000 + seconds * 1000 + millis;
        } catch (RuntimeException e) {
            return -1;
        }
    }

    public boolean isEmpty() {
        return lines.isEmpty();
    }

    public int size() {
        return lines.size();
    }

    public List<Line> lines() {
        return lines;
    }

    public String plainText() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (sb.length() > 0) {
                sb.append('\n');
            }
            sb.append(lines.get(i).text);
        }
        return sb.toString();
    }

    /** 返回当前播放位置对应的歌词行下标，无匹配返回 -1。 */
    public int indexAt(int positionMs) {
        int found = -1;
        for (int i = 0; i < lines.size(); i++) {
            int t = lines.get(i).time;
            if (t < 0) {
                continue;
            }
            if (t <= positionMs) {
                found = i;
            } else {
                break;
            }
        }
        return found;
    }
}