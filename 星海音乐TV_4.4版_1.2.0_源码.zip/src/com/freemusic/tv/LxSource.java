package com.freemusic.tv;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 长青SVIP音源（用户上传的 lx-music-source 脚本）的行为描述文件读取器。
 *
 * 描述文件 assets/lx_source.json 由 tools/extract_lx_source.js 在构建期「真实运行该脚本」后生成，
 * 里面固化了脚本对外暴露的音源键、每个平台的 id 字段、音质等级与 url 模板。
 * 端上不再需要任何 JS 引擎即可按脚本的行为取流，方案与取舍见 docs/lx-source-integration.md。
 *
 * 本类不依赖任何 android.* API，可直接在 JVM 上做验证。
 */
public final class LxSource {

    /** 一个平台的取流描述。 */
    public static class Entry {
        public String key = "";
        public String name = "";
        public String idField = "";
        public final List<String> qualitys = new ArrayList<String>();
        /** 音质键 -> 已经填好 level 的 url 模板，模板里含 {id} 占位符 */
        public final Map<String, String> templates = new LinkedHashMap<String, String>();
        /** 音质键 -> level 参数值（standard / exhigh / lossless） */
        public final Map<String, String> levelTokens = new LinkedHashMap<String, String>();
    }

    private String displayName = "";
    private String version = "";
    private String scriptFile = "";
    /** 取流方式：空=按 urlTemplates 模板取流；"quickjs"=由端上 JS 引擎运行脚本取流。 */
    private String runner = "";
    /** 内置音源接口的官方地址（例如 pdone/lx-music-source 的 changqing/latest.js）。 */
    private String sourceUrl = "";
    private final Map<String, Entry> entries = new LinkedHashMap<String, Entry>();

    /** 当前生效的脚本音源（由界面在启动时装载描述文件后注入）。 */
    private static volatile LxSource active;

    public static void setActive(LxSource source) {
        active = source;
    }

    public static LxSource active() {
        return active;
    }

    public static LxSource parse(String json) {
        LxSource src = new LxSource();
        Object root = Json.parse(json);
        if (root == null) {
            return src;
        }
        src.scriptFile = Json.strAt(root, "scriptFile");
        src.sourceUrl = Json.strAt(root, "sourceUrl");
        src.runner = Json.strAt(root, "runner");
        src.displayName = Json.strAt(root, "metadata", "name");
        src.version = Json.strAt(root, "metadata", "version");
        List<Object> keys = Json.listOrEmpty(Json.at(root, "behaviour", "sources"));
        Map<String, Object> sources = Json.asMap(Json.at(root, "sources"));
        if (sources != null) {
            for (int i = 0; i < keys.size(); i++) {
                String key = Json.str(keys.get(i));
                Object node = sources.get(key);
                if (node == null) {
                    continue;
                }
                Entry e = new Entry();
                e.key = key;
                e.name = Json.strAt(node, "name");
                e.idField = Json.strAt(node, "idField");
                List<Object> qs = Json.listOrEmpty(Json.at(node, "qualitys"));
                for (int k = 0; k < qs.size(); k++) {
                    e.qualitys.add(Json.str(qs.get(k)));
                }
                Map<String, Object> templates = Json.asMap(Json.at(node, "urlTemplates"));
                if (templates != null) {
                    for (Map.Entry<String, Object> t : templates.entrySet()) {
                        e.templates.put(t.getKey(), Json.str(t.getValue()));
                    }
                }
                Map<String, Object> levels = Json.asMap(Json.at(node, "levelTokens"));
                if (levels != null) {
                    for (Map.Entry<String, Object> t : levels.entrySet()) {
                        e.levelTokens.put(t.getKey(), Json.str(t.getValue()));
                    }
                }
                src.entries.put(key, e);
            }
        }
        return src;
    }

    public boolean isReady() {
        return entries.size() > 0;
    }

    public String scriptFile() {
        return scriptFile;
    }

    /** 取流方式标记：""（模板型）或 "quickjs"（引擎执行型）。 */
    public String runner() {
        return runner;
    }

    /** 引擎执行型脚本的正文（由界面在装载时从落盘的 <id>.js 读入并挂上）。 */
    private String scriptBody = "";

    public void setScriptBody(String body) {
        this.scriptBody = body == null ? "" : body;
    }

    public String scriptBody() {
        return scriptBody == null ? "" : scriptBody;
    }

    /**
     * 引擎执行型：描述里声明了 runner=quickjs 且列出了平台，取流时由端上 JS 引擎运行脚本拿地址
     * （这类脚本没有 urlTemplates，仍然可用）。
     */
    public boolean engineReady() {
        return "quickjs".equals(runner) && !entries.isEmpty();
    }

    /** 内置音源接口的官方地址（便于在界面上说明“内置音源来自哪里”）。 */
    public String sourceUrl() {
        return sourceUrl == null ? "" : sourceUrl;
    }

    /** 形如「长青SVIP音源 v1.3.0」，用于界面显示与线路命名。 */
    public String describe() {
        if (displayName.length() == 0) {
            return engineReady() ? "脚本音源（引擎执行）" : "脚本音源";
        }
        String base = version.length() == 0 ? displayName : displayName + " v" + version;
        return engineReady() ? base + "（引擎执行）" : base;
    }

    public String displayName() {
        return displayName;
    }

    public String version() {
        return version;
    }

    public List<String> sourceKeys() {
        return new ArrayList<String>(entries.keySet());
    }

    public Entry entry(String sourceKey) {
        return sourceKey == null ? null : entries.get(sourceKey);
    }

    /** 应用内部音源代号 -> 脚本音源键：qq 音乐在脚本里叫 tx。 */
    public static String appSourceToKey(String appSource) {
        if (Song.SRC_QQ.equals(appSource)) {
            return "tx";
        }
        if (Song.SRC_WY.equals(appSource) || Song.SRC_KW.equals(appSource)
                || Song.SRC_KG.equals(appSource) || "mg".equals(appSource)) {
            return appSource;
        }
        return null;
    }

    /** 应用音质档（1 高品 128K / 2 超品 320K / 3 无损 FLAC）-> 首选脚本音质键。 */
    public static String qualityKey(int quality) {
        if (quality == PlayResolver.QUALITY_128) {
            return "128k";
        }
        if (quality == PlayResolver.QUALITY_FLAC) {
            return "flac";
        }
        return "320k";
    }

    /** 首选音质在脚本侧没有模板时的次选音质键（无损回落到 320K），其余档位返回 null。 */
    public static String qualityKeyFallback(int quality) {
        return quality == PlayResolver.QUALITY_FLAC ? "320k" : null;
    }

    /** 该音源是否具备这个音质键的模板。 */
    public boolean supports(String sourceKey, String qualityKey) {
        Entry e = entry(sourceKey);
        return e != null && qualityKey != null && e.templates.containsKey(qualityKey)
                && e.templates.get(qualityKey).length() > 0;
    }

    /**
     * 按脚本的模板拼出取流地址；缺 id 或缺模板时返回空串。
     * 模板支持两个占位：{id} 换歌曲 id；{level} 换该音质对应的 level 参数
     * （描述里给了 levelTokens 就用它，没给就按音质键本身传）。
     */
    public String buildUrl(String sourceKey, String id, String qualityKey) {
        if (id == null || id.length() == 0 || qualityKey == null) {
            return "";
        }
        Entry e = entry(sourceKey);
        if (e == null) {
            return "";
        }
        String template = e.templates.get(qualityKey);
        if (template == null || template.length() == 0) {
            return "";
        }
        String level = levelToken(sourceKey, qualityKey);
        if (level.length() == 0) {
            level = qualityKey;
        }
        return template.replace("{id}", id).replace("{level}", level);
    }

    /** 该平台取 id 时脚本读的字段名（hash / songmid），用于诊断展示。 */
    public String idField(String sourceKey) {
        Entry e = entry(sourceKey);
        return e == null ? "" : e.idField;
    }

    /**
     * 是否有任一平台的非空取流模板。
     * 模板型音源（导入的 .json 描述）为 true；运行时装接口型的脚本（内置 fish_music）没有模板，为 false。
     * 取流时用它决定「模板线路」是否要排到平台线路之前。
     */
    public boolean hasTemplates() {
        for (Entry e : entries.values()) {
            for (String v : e.templates.values()) {
                if (v != null && v.length() > 0) {
                    return true;
                }
            }
        }
        return false;
    }

    /** 所有平台条目的键（按描述文件里的顺序）。 */
    public List<String> keys() {
        return sourceKeys();
    }

    public String levelToken(String sourceKey, String qualityKey) {
        Entry e = entry(sourceKey);
        if (e == null || qualityKey == null) {
            return "";
        }
        String v = e.levelTokens.get(qualityKey);
        return v == null ? "" : v;
    }
}