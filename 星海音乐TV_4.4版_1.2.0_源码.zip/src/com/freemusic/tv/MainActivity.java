package com.freemusic.tv;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 星海音乐TV 主界面。
 * 全程遥控器操作：方向键移动焦点、OK 键确认、菜单键进设置、返回键退出播放页。
 */
public class MainActivity extends Activity implements MusicPlayer.Listener {

    private static final int PAGE_SEARCH = 0;
    private static final int PAGE_RANK = 1;
    private static final int PAGE_FAV = 2;
    private static final int PAGE_SETTING = 3;

    private static final String[] HOT_WORDS = new String[]{
            "周杰伦", "林俊杰", "邓紫棋", "陈奕迅", "薛之谦", "李荣浩",
            "毛不易", "许嵩", "王菲", "五月天", "经典老歌", "纯音乐"
    };

    private static final String SET_QUALITY = "音质";
    private static final String SET_DOWNLOAD = "取流方式";
    private static final String SET_SOURCE_IMPORT = "导入在线音源";
    private static final String SET_SOURCE_ACTIVE = "内置 / 导入音源切换";
    private static final String SET_LYRIC_LEAD = "歌词提前量";
    private static final String SET_CLEAR = "清除封面缓存";
    private static final String SET_ABOUT = "关于本软件";

    /** 快进/快退步长（毫秒）。 */
    private static final int SEEK_STEP_MS = 10000;

    /** 播放页长按 ← / → 快退快进：记录这次按住是否已经触发过，避免继续按住时进度条反复抖动。 */
    private boolean arrowHoldConsumed;
    private int arrowHoldKey = -1;

    private FrameLayout pageContainer;
    private TextView navSearch, navRank, navFav, navSetting;

    private View searchPage;
    private EditText etSearch;
    private TextView btnSearch, btnPlayAll, searchStatus;
    private LinearLayout hotRow, hotRow2, platformRow;
    private ListView lvResults;
    private SongAdapter searchAdapter;

    private View rankPage;
    private ListView lvRankCats, lvRankSongs;
    private TextView rankTitle, rankStatus;
    private SongAdapter rankAdapter;
    private LineAdapter catAdapter;
    private String currentStation = "热歌榜";
    private boolean rankLoaded;

    private View favPage;
    private ListView lvFav;
    private SongAdapter favAdapter;
    private TextView favSummary;

    private View settingPage;
    private ListView lvSettings;
    private LineAdapter settingAdapter;
    private TextView setHint;

    private View playerPage;
    private VinylCoverView vinyl;
    private TextView plTitle, plArtist, plAlbum, plPos, plDur, plSource;
    private TextView btnPrev, btnPlay, btnNext, btnFav, btnQuality, btnMode;
    private TextView btnRew, btnFwd;
    private SeekBar seek;
    private ScrollView lyricScroll;
    /** 逐行歌词容器：每行一个 TextView，当前行按时间轴改色高亮。 */
    private LinearLayout lyricBox;
    /** 当前高亮的歌词行下标，-1 表示尚未定位。 */
    private int lyricLineIndex = -1;
    /** 精确换行调度：到「下一行时间戳 − 提前量」时刻跑一次，用当时的播放位置重算（自校正）。 */
    private final Runnable lyricSwitchTask = new Runnable() {
        @Override
        public void run() {
            if (!playerVisible) {
                return;
            }
            int before = lyricLineIndex;
            syncLyricHighlight(player.position(), false);
            if (lyricLineIndex == before) {
                // 这次没换行（还没到点，或调度被截断）：重新排一次，别把精度丢掉
                scheduleLyricSwitch();
            }
        }
    };
    private ProgressBar playerBusy;

    private MusicPlayer player;
    private Prefs prefs;
    private ImageLoader images;
    private final ExecutorService netPool = Executors.newFixedThreadPool(3);
    private final Handler main = new Handler(Looper.getMainLooper());
    /** 音源仓库：内置描述 + 应用内导入的音源（列表顺序就是切换顺序）。 */
    private final List<SourceStore.Item> sources = new ArrayList<SourceStore.Item>();

    private int page = PAGE_SEARCH;
    private boolean playerVisible;
    private Lrc lrc = Lrc.parse("");
    private boolean seeking;
    private String lastLog = "";
    private String lastNote = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        CrashGuard.install(this);
        try {
            initUi();
        } catch (Throwable t) {
            CrashGuard.write(this, t);
            CrashGuard.showFailureScreen(this, t);
        }
    }

    private void initUi() {
        setContentView(R.layout.activity_main);

        prefs = new Prefs(this);
        // 脚本引擎（QuickJS）：给「引擎执行型」音源用，加载失败时应用照常运行
        Tls12.install();
        JsEngine.init(this);
        // 装载音源仓库：内置音源描述（assets/lx_source.json）+ 应用内已导入的音源（filesDir/lx_sources）
        loadSources();
        images = ImageLoader.of(this);
        player = new MusicPlayer(this, prefs);
        player.setListener(this);

        pageContainer = (FrameLayout) findViewById(R.id.pageContainer);
        navSearch = (TextView) findViewById(R.id.navSearch);
        navRank = (TextView) findViewById(R.id.navRank);
        navFav = (TextView) findViewById(R.id.navFav);
        navSetting = (TextView) findViewById(R.id.navSetting);

        LayoutInflater inflater = LayoutInflater.from(this);
        searchPage = inflater.inflate(R.layout.page_search, pageContainer, false);
        rankPage = inflater.inflate(R.layout.page_rank, pageContainer, false);
        favPage = inflater.inflate(R.layout.page_fav, pageContainer, false);
        settingPage = inflater.inflate(R.layout.page_settings, pageContainer, false);
        pageContainer.addView(searchPage);
        pageContainer.addView(rankPage);
        pageContainer.addView(favPage);
        pageContainer.addView(settingPage);

        playerPage = inflater.inflate(R.layout.page_player, (FrameLayout) findViewById(R.id.root), false);
        ((FrameLayout) findViewById(R.id.root)).addView(playerPage);
        playerPage.setVisibility(View.GONE);

        bindSearchPage();
        bindRankPage();
        bindFavPage();
        bindSettingPage();
        bindPlayerPage();

        // 列表项自己持有焦点，遥控器确认键（OK）会落在列表项上。
        // 这里统一把每一项的点击回接到列表原有的条目点击逻辑，保证按 OK 能真正生效。
        searchAdapter.setClickListener(new SongAdapter.OnClick() {
            @Override
            public void onClick(int position, Song song) {
                lvResults.performItemClick(null, position, position);
            }
        });
        rankAdapter.setClickListener(new SongAdapter.OnClick() {
            @Override
            public void onClick(int position, Song song) {
                lvRankSongs.performItemClick(null, position, position);
            }
        });
        favAdapter.setClickListener(new SongAdapter.OnClick() {
            @Override
            public void onClick(int position, Song song) {
                lvFav.performItemClick(null, position, position);
            }
        });
        catAdapter.setClickListener(new LineAdapter.OnClick() {
            @Override
            public void onClick(int position, LineAdapter.Item item) {
                lvRankCats.performItemClick(null, position, position);
            }
        });
        settingAdapter.setClickListener(new LineAdapter.OnClick() {
            @Override
            public void onClick(int position, LineAdapter.Item item) {
                lvSettings.performItemClick(null, position, position);
            }
        });

        // 再兜一层：Android 4.4 上 ListView 自己持有焦点，其内部确认键处理在部分机型上
        // 不会触发条目点击，所以在列表上直接拦确认键并回接到同样的条目点击逻辑。
        ListView[] lists = new ListView[]{lvResults, lvRankSongs, lvRankCats, lvFav, lvSettings};
        for (int i = 0; i < lists.length; i++) {
            attachConfirmKeyListener(lists[i]);
        }

        navSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPage(PAGE_SEARCH);
            }
        });
        navRank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPage(PAGE_RANK);
            }
        });
        navFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPage(PAGE_FAV);
            }
        });
        navSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPage(PAGE_SETTING);
            }
        });

        showPage(PAGE_SEARCH);
        String last = prefs.lastQuery();
        if (last.length() > 0) {
            etSearch.setText(last);
            searchStatus.setText("上次搜索：" + last + "，可直接回车再次搜索");
        }
    }

    // ---------------- 搜索页 ----------------

    private void bindSearchPage() {
        etSearch = (EditText) searchPage.findViewById(R.id.etSearch);
        btnSearch = (TextView) searchPage.findViewById(R.id.btnSearch);
        btnPlayAll = (TextView) searchPage.findViewById(R.id.btnPlayAll);
        searchStatus = (TextView) searchPage.findViewById(R.id.searchStatus);
        hotRow = (LinearLayout) searchPage.findViewById(R.id.hotRow);
        hotRow2 = (LinearLayout) searchPage.findViewById(R.id.hotRow2);
        platformRow = (LinearLayout) searchPage.findViewById(R.id.platformRow);
        lvResults = (ListView) searchPage.findViewById(R.id.lvResults);
        searchAdapter = new SongAdapter(this);
        lvResults.setAdapter(searchAdapter);

        for (int i = 0; i < HOT_WORDS.length; i++) {
            final String word = HOT_WORDS[i];
            TextView chip = Ui.chip(this, word);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    etSearch.setText(word);
                    performSearch(word);
                }
            });
            if (i < 6) {
                hotRow.addView(chip);
            } else {
                hotRow2.addView(chip);
            }
        }

        buildPlatformChips();

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performSearch(etSearch.getText().toString().trim());
            }
        });
        btnPlayAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playFromList(searchAdapter.data(), 0, "搜索结果");
            }
        });
        etSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                performSearch(v.getText().toString().trim());
                return true;
            }
        });
        lvResults.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                playFromList(searchAdapter.data(), position, "搜索结果");
            }
        });
    }

    private void buildPlatformChips() {
        platformRow.removeAllViews();
        final String[] keys = new String[]{Prefs.FILTER_ALL, Song.SRC_QQ, Song.SRC_KG, Song.SRC_KW, Song.SRC_WY};
        final String[] labels = new String[]{"全部音源", "QQ音乐", "酷狗", "酷我", "网易云"};
        String current = prefs.sourceFilter();
        for (int i = 0; i < keys.length; i++) {
            final String key = keys[i];
            TextView chip = Ui.chip(this, labels[i]);
            chip.setSelected(key.equals(current));
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    prefs.setSourceFilter(key);
                    buildPlatformChips();
                    String q = etSearch.getText().toString().trim();
                    if (q.length() > 0) {
                        performSearch(q);
                    }
                }
            });
            platformRow.addView(chip);
        }
    }

    private void performSearch(final String keyword) {
        if (keyword == null || keyword.length() == 0) {
            Ui.toast(this, "请先输入关键词或点一个热门搜索");
            return;
        }
        prefs.setLastQuery(keyword);
        searchStatus.setText("正在搜索「" + keyword + "」…");
        final String filter = prefs.sourceFilter();
        netPool.execute(new Runnable() {
            @Override
            public void run() {
                final List<Song> found = searchAll(keyword, filter);
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        searchAdapter.setData(found);
                        syncListFollow();
                        if (found.isEmpty()) {
                            searchStatus.setText("没有找到「" + keyword + "」相关歌曲，换个关键词试试");
                        } else {
                            searchStatus.setText("「" + keyword + "」共 " + found.size()
                                    + " 首（音源：" + filterLabel(filter) + "），按 OK 键开始播放");
                            lvResults.requestFocus();
                        }
                    }
                });
            }
        });
    }

    private String filterLabel(String filter) {
        if (Song.SRC_QQ.equals(filter)) {
            return "QQ音乐";
        }
        if (Song.SRC_KG.equals(filter)) {
            return "酷狗";
        }
        if (Song.SRC_KW.equals(filter)) {
            return "酷我";
        }
        if (Song.SRC_WY.equals(filter)) {
            return "网易云";
        }
        return "全部";
    }

    private List<Song> searchAll(String keyword, String filter) {
        List<Song> out = new ArrayList<Song>();
        // 搜索解析顺序：QQ音乐 → 酷狗音乐 → 酷我音乐 → 网易云音乐
        if (Prefs.FILTER_ALL.equals(filter) || Song.SRC_QQ.equals(filter)) {
            out.addAll(QqApi.search(keyword, 15));
        }
        if (Prefs.FILTER_ALL.equals(filter) || Song.SRC_KG.equals(filter)) {
            out.addAll(KgApi.search(keyword, 15));
        }
        if (Prefs.FILTER_ALL.equals(filter) || Song.SRC_KW.equals(filter)) {
            out.addAll(KwApi.search(keyword, 15));
        }
        if (Prefs.FILTER_ALL.equals(filter) || Song.SRC_WY.equals(filter)) {
            out.addAll(WyApi.search(keyword, 15));
        }
        return dedupe(out);
    }

    private List<Song> dedupe(List<Song> songs) {
        List<Song> out = new ArrayList<Song>();
        for (int i = 0; i < songs.size(); i++) {
            Song s = songs.get(i);
            boolean dup = false;
            for (int k = 0; k < out.size(); k++) {
                if (out.get(k).key().equals(s.key()) || out.get(k).sameTitleArtist(s)) {
                    dup = true;
                    break;
                }
            }
            if (!dup) {
                out.add(s);
            }
        }
        return out;
    }

    // ---------------- 榜单页 ----------------

    private void bindRankPage() {
        lvRankCats = (ListView) rankPage.findViewById(R.id.lvRankCats);
        lvRankSongs = (ListView) rankPage.findViewById(R.id.lvRankSongs);
        rankTitle = (TextView) rankPage.findViewById(R.id.rankTitle);
        rankStatus = (TextView) rankPage.findViewById(R.id.rankStatus);
        catAdapter = new LineAdapter(this);
        lvRankCats.setAdapter(catAdapter);
        rankAdapter = new SongAdapter(this);
        lvRankSongs.setAdapter(rankAdapter);

        List<LineAdapter.Item> cats = new ArrayList<LineAdapter.Item>();
        String[] stations = WyApi.stationNames();
        for (int i = 0; i < stations.length; i++) {
            cats.add(new LineAdapter.Item(stations[i], "网易云", i));
        }
        catAdapter.setData(cats);

        lvRankCats.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                LineAdapter.Item item = (LineAdapter.Item) catAdapter.getItem(position);
                currentStation = item.text;
                rankTitle.setText(currentStation);
                loadStation(item.text);
            }
        });
        lvRankSongs.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                playFromList(rankAdapter.data(), position, "榜单 · " + currentStation);
            }
        });
    }

    private void loadStation(final String station) {
        rankStatus.setText("正在加载《" + station + "》…");
        final String id = WyApi.stations().get(station);
        netPool.execute(new Runnable() {
            @Override
            public void run() {
                final List<Song> tracks = WyApi.playlist(id, 100);
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        rankLoaded = true;
                        rankAdapter.setData(tracks);
                        syncListFollow();
                        if (tracks.isEmpty()) {
                            rankStatus.setText("《" + station + "》暂时取不到数据，可稍后重试或换个分类");
                        } else {
                            rankStatus.setText("《" + station + "》共 " + tracks.size() + " 首，按 OK 键播放");
                            lvRankSongs.requestFocus();
                        }
                    }
                });
            }
        });
    }

    // ---------------- 收藏页 ----------------

    private void bindFavPage() {
        lvFav = (ListView) favPage.findViewById(R.id.lvFav);
        favSummary = (TextView) favPage.findViewById(R.id.favSummary);
        favAdapter = new SongAdapter(this);
        favAdapter.setLongClickListener(new SongAdapter.OnLongClick() {
            @Override
            public void onLongClick(int position, Song song) {
                prefs.toggleFavorite(song);
                refreshFavorites();
                Ui.toast(MainActivity.this, "已取消收藏：" + song.displayTitle());
            }
        });
        lvFav.setAdapter(favAdapter);
        lvFav.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                playFromList(favAdapter.data(), position, "我的收藏");
            }
        });
        refreshFavorites();
    }

    private void refreshFavorites() {
        List<Song> favs = prefs.favorites();
        favAdapter.setData(favs);
        favSummary.setText("我收藏的歌曲（" + favs.size() + " 首）");
        syncListFollow();
    }

    // ---------------- 列表跟随正在播放的歌曲 ----------------

    /**
     * 把三个歌曲列表（搜索结果 / 榜单 / 收藏）的选中行跟到正在播放的歌曲：
     * 只改 ListView 的选中行（setSelection 会顺带把它滚到可见区），不 requestFocus，
     * 因此不会抢走遥控器当前的焦点；当下看不到的列表也一并同步，切回去时光标已经在正确的行上。
     */
    private void syncListFollow() {
        Song cur = player.current();
        if (cur == null) {
            return;
        }
        followPlayingSong(lvResults, searchAdapter, cur);
        followPlayingSong(lvRankSongs, rankAdapter, cur);
        followPlayingSong(lvFav, favAdapter, cur);
    }

    /** 在单个列表里按歌曲 key 定位正在播放的那首歌，找到就把选中行移过去。 */
    private void followPlayingSong(ListView list, SongAdapter adapter, Song cur) {
        if (list == null || adapter == null) {
            return;
        }
        List<Song> data = adapter.data();
        int idx = -1;
        for (int i = 0; i < data.size(); i++) {
            if (data.get(i).key().equals(cur.key())) {
                idx = i;
                break;
            }
        }
        if (idx < 0) {
            // 这首歌不在这个列表里（例如从榜单里播的，搜索结果里没有），保持原样
            return;
        }
        if (list.getSelectedItemPosition() == idx) {
            return;
        }
        list.setSelection(idx);
        android.util.Log.i("StarMusicTV", "列表跟随 => " + listName(list)
                + " 第" + (idx + 1) + "行 " + cur.displayTitle());
    }

    private String listName(ListView list) {
        if (list == lvResults) {
            return "搜索结果";
        }
        if (list == lvRankSongs) {
            return "榜单";
        }
        if (list == lvFav) {
            return "收藏";
        }
        return "列表";
    }

    /**
     * 收藏页菜单键：取消列表中当前选中（遥控器上下键选中的那一行）歌曲的收藏。
     * 长按确认键取消收藏的老入口仍然保留。
     */
    private void removeFocusedFavorite() {
        int position = lvFav.getSelectedItemPosition();
        if (position == ListView.INVALID_POSITION) {
            position = lvFav.getCheckedItemPosition();
        }
        List<Song> favs = favAdapter.data();
        if (position == ListView.INVALID_POSITION || position < 0 || position >= favs.size()) {
            Ui.toast(this, "请先用遥控器上下键选中要取消收藏的歌曲");
            return;
        }
        Song song = favs.get(position);
        prefs.toggleFavorite(song);
        refreshFavorites();
        Ui.toast(this, "已取消收藏：" + song.displayTitle());
        android.util.Log.i("StarMusicTV", "收藏页菜单键取消收藏 position=" + position + " song=" + song.displayTitle());
    }

    // ---------------- 音源仓库：导入 ----------------

    /** 读 assets 里的文本（内置音源描述）。 */
    private String readAsset(String name) {
        try {
            java.io.InputStream in = getAssets().open(name);
            java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
            byte[] chunk = new byte[4096];
            int n;
            while ((n = in.read(chunk)) > 0) {
                buf.write(chunk, 0, n);
            }
            in.close();
            return new String(buf.toByteArray(), "UTF-8");
        } catch (Throwable t) {
            return "";
        }
    }

    private String readText(java.io.File f) {
        try {
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
            byte[] chunk = new byte[4096];
            int n;
            while ((n = in.read(chunk)) > 0) {
                buf.write(chunk, 0, n);
            }
            in.close();
            return new String(buf.toByteArray(), "UTF-8");
        } catch (Throwable t) {
            return "";
        }
    }

    /**
     * 重新装载音源仓库：内置描述（assets/lx_source.json）+ 应用内已导入的音源（filesDir/lx_sources/*.json）。
     * 装完按偏好决定当前生效音源，并交给 LxSource 全局生效。
     */
    private void loadSources() {
        sources.clear();
        SourceStore.Item builtin = SourceStore.fromJson(SourceStore.ID_BUILTIN,
                readAsset("lx_source.json"), "", true);
        if (builtin != null) {
            sources.add(builtin);
        }
        int imported = 0;
        java.io.File dir = new java.io.File(getFilesDir(), SourceStore.DIR);
        List<java.io.File> files = SourceStore.listImportable(dir);
        for (int i = 0; i < files.size(); i++) {
            java.io.File f = files.get(i);
            if (!f.getName().endsWith(".json")) {
                continue;
            }
            SourceStore.Item it = SourceStore.fromJson(SourceStore.idFrom(f.getName()),
                    readText(f), f.getAbsolutePath(), false);
            if (it != null) {
                if (it.engine && it.parsed != null) {
                    // 引擎执行型：把同目录下的 <id>.js 正文挂到描述上，取流时交给引擎跑
                    java.io.File js = new java.io.File(dir, it.id + ".js");
                    if (js.isFile()) {
                        it.parsed.setScriptBody(readText(js));
                    } else {
                        it.usable = false;
                    }
                }
                sources.add(it);
                imported++;
            }
        }
        applyActiveSource();
        android.util.Log.i("StarMusicTV", "音源仓库 => 共 " + sources.size() + " 个（内置 "
                + (builtin == null ? 0 : 1) + "，导入 " + imported + "）");
    }

    /**
     * 决定当前生效的音源（按偏好 active_source）并交给 LxSource 全局生效。
     * 偏好里的音源不存在或已不可用时回落内置；LxSource 为 null 时取流只用平台直连线路。
     */
    private void applyActiveSource() {
        SourceStore.Item it = activeSource();
        if (it == null) {
            for (int i = 0; i < sources.size(); i++) {
                if (sources.get(i).builtin) {
                    it = sources.get(i);
                    break;
                }
            }
            if (it != null) {
                prefs.setActiveSource(it.id);
            }
        }
        LxSource.setActive(it == null ? null : it.parsed);
        android.util.Log.i("StarMusicTV", "当前音源 => " + (it == null ? "未装载" : it.title()
                + "（" + it.id + "，平台 " + it.platforms() + "）"));
    }

    /** 可被选中的音源：内置始终可选；导入源在导入时就已校验过模板，能进来就可选。 */
    private boolean selectable(SourceStore.Item it) {
        return it != null && (it.builtin || it.usable);
    }

    /** 偏好指向的那个音源条目（不在列表或不可选时返回 null）。 */
    private SourceStore.Item activeSource() {
        String id = prefs.activeSource();
        for (int i = 0; i < sources.size(); i++) {
            SourceStore.Item it = sources.get(i);
            if (it.id.equals(id) && selectable(it)) {
                return it;
            }
        }
        return null;
    }

    /** 设置页「内置 / 导入音源切换」那一行的显示值：标出当前是内置还是导入，并给出内置/导入个数。 */
    private String activeSourceLabel() {
        SourceStore.Item it = activeSource();
        String kind = "";
        String name = "未装载";
        if (it != null) {
            kind = it.builtin ? "内置音源 " : "导入音源 ";
            name = it.title();
        }
        return kind + name + "（按 OK 切换，共 " + sources.size() + " 个：内置 " + builtinCount()
                + " / 导入 " + importedCount() + "）";
    }

    /** 设置页「内置 / 导入音源切换」：按 OK 在所有可切换音源之间循环，切换后立即对取流生效并落盘。 */
    private void cycleActiveSource() {
        List<SourceStore.Item> list = new ArrayList<SourceStore.Item>();
        for (int i = 0; i < sources.size(); i++) {
            if (selectable(sources.get(i))) {
                list.add(sources.get(i));
            }
        }
        if (list.isEmpty()) {
            Ui.toast(this, "当前没有可用音源");
            return;
        }
        String cur = prefs.activeSource();
        int idx = -1;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(cur)) {
                idx = i;
            }
        }
        SourceStore.Item next = list.get((idx + 1) % list.size());
        prefs.setActiveSource(next.id);
        JsEngine.clearSessions();
        applyActiveSource();
        refreshSettings();
        String kind = next.builtin ? "内置音源" : "导入音源";
        Ui.toast(this, "已切换音源：" + kind + " " + next.title() + "（取流会先走它，取不到仍按平台回退）");
        android.util.Log.i("StarMusicTV", "切换音源 => " + kind + " " + next.title()
                + " 平台=" + next.platforms());
    }

    /** 设置页「导入在线音源」：地址联网导入（.json 描述 / .js 脚本）+ 扫描本地目录导入。 */
    private void showImportDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 18);
        box.setPadding(pad, Ui.dp(this, 10), pad, 0);

        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("音源地址（.json 描述 / .js 脚本）");
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        input.setTextColor(Ui.color(this, R.color.text));
        input.setHintTextColor(Ui.color(this, R.color.text_dim));
        box.addView(input, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView tip = new TextView(this);
        tip.setText("① 在线导入：输入 .json 描述或 .js 脚本的地址，按「地址导入」联网下载后识别入库；\n"
                + "② 本地导入：也可把 .json / .js 放到共享存储 Android/data/" + getPackageName()
                + "/files（或应用私有 import 目录）再按「扫描本地目录」；\n"
                + "③ 端上已内置 JS 引擎（QuickJS）：.js 先做静态提取，提取不到就把脚本交给引擎真跑一次——"
                + "能跑起来（脚本 lx.send(inited) 声明了平台）就按「引擎执行型」收下，播放时按歌实时跑脚本取地址；"
                + "接口返回 4xx/超时/脚本报错会写明原因。.json 描述最稳，格式见 docs/音源描述文件格式.md；\n"
                + "④ 导入后回设置页，在「内置 / 导入音源切换」里按 OK 就能切到它，切换立即生效并重启保持。");
        tip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tip.setTextColor(Ui.color(this, R.color.text_dim));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tp.topMargin = Ui.dp(this, 8);
        box.addView(tip, tp);

        new android.app.AlertDialog.Builder(this)
                .setTitle("导入在线音源")
                .setView(box)
                .setPositiveButton("地址导入", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        importFromUrl(input.getText().toString());
                    }
                })
                .setNeutralButton("扫描本地目录", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        scanLocalSources();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void importFromUrl(final String url) {
        final String u = url == null ? "" : url.trim();
        if (u.length() == 0) {
            Ui.toast(this, "先输入音源地址，再按「地址导入」");
            return;
        }
        Ui.toast(this, "正在下载音源…");
        netPool.execute(new Runnable() {
            @Override
            public void run() {
                Http.Res res = Http.get(u, Http.headers());
                final String body = res != null && res.ok() ? res.body : "";
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        if (body == null || body.trim().length() == 0) {
                            Ui.toast(MainActivity.this, "下载失败：地址不可达或返回为空");
                            android.util.Log.i("StarMusicTV", "音源导入失败 => 下载 " + u);
                            return;
                        }
                        SourceStore.Item it = doImport(body, baseName(u), u, false);
                        if (it == null) {
                            return;      // doImport 里已经提示过原因
                        }
                        Ui.toast(MainActivity.this, "已导入音源：" + it.title()
                                + "（在「当前音源」里可切换生效）");
                    }
                });
            }
        });
    }

    /** 扫描两处目录：应用私有 import 目录、共享存储 Android/data/<包名>/files（及其 import 子目录）。 */
    private void scanLocalSources() {
        List<java.io.File> found = new ArrayList<java.io.File>();
        found.addAll(SourceStore.listImportable(new java.io.File(getFilesDir(), "import")));
        try {
            java.io.File ext = getExternalFilesDir(null);
            if (ext != null) {
                found.addAll(SourceStore.listImportable(ext));
                found.addAll(SourceStore.listImportable(new java.io.File(ext, "import")));
            }
        } catch (Throwable ignore) {
            // 外部存储不可用时只看应用内目录
        }
        if (found.isEmpty()) {
            Ui.toast(this, "没找到可导入的文件：把 .json / .js 放进应用私有 import 目录，或共享存储 "
                    + "Android/data/" + getPackageName() + "/files，再点「扫描本地目录」");
            return;
        }
        int ok = 0;
        StringBuilder names = new StringBuilder();
        for (int i = 0; i < found.size(); i++) {
            java.io.File f = found.get(i);
            SourceStore.Item it = doImport(readText(f), f.getName(), "", true);
            if (it != null) {
                ok++;
                if (names.length() > 0) {
                    names.append('、');
                }
                names.append(it.title());
            }
        }
        Ui.toast(this, ok > 0 ? "已导入 " + ok + " 个音源：" + names
                : "扫描到 " + found.size() + " 个文件，但都没有可用取流模板"
                        + "（描述缺 urlTemplates，或 .js 属「运行时装接口型」）");
    }

    /** 识别 + 校验 + 落盘 + 刷新列表；失败返回 null（quiet=true 时不弹提示，由调用方汇总）。 */
    private SourceStore.Item doImport(String raw, String hintName, String sourceUrl, boolean quiet) {
        // 把导入来源（在线地址，本地文件为空串）一并交给引擎：脚本读 lx.currentScriptInfo 时要用
        SourceStore.Outcome outcome = SourceStore.normalizeFor(raw, hintName, JsEngine.probe(sourceUrl));
        String json = outcome.json;
        if (json.length() == 0) {
            if (!quiet) {
                Ui.toast(this, "未导入：" + outcome.reason + "（格式见工程 docs/音源描述文件格式.md）");
            }
            android.util.Log.i("StarMusicTV", "音源导入失败 => " + hintName + "（" + outcome.reason + "）");
            return null;
        }
        boolean isScript = raw != null && raw.trim().length() > 0 && raw.trim().charAt(0) != '{';
        java.io.File dir = new java.io.File(getFilesDir(), SourceStore.DIR);
        SourceStore.Item saved = SourceStore.save(dir, SourceStore.idFrom(hintName), json, raw, isScript);
        if (saved == null) {
            if (!quiet) {
                Ui.toast(this, "保存音源失败，请重试");
            }
            return null;
        }
        loadSources();
        refreshSettings();
        android.util.Log.i("StarMusicTV", "音源导入成功 => " + saved.title() + " 平台=" + saved.platforms());
        return saved;
    }

    private static String baseName(String urlOrName) {
        String s = urlOrName == null ? "" : urlOrName.trim();
        int slash = s.lastIndexOf('/');
        String n = slash >= 0 ? s.substring(slash + 1) : s;
        int q = n.indexOf('?');
        return q >= 0 ? n.substring(0, q) : n;
    }

    /** 已导入音源个数（不含内置）。 */
    private int importedCount() {
        int n = 0;
        for (int i = 0; i < sources.size(); i++) {
            if (!sources.get(i).builtin) {
                n++;
            }
        }
        return n;
    }

    /** 内置音源个数（正常为 1；内置缺失时为 0）。 */
    private int builtinCount() {
        int n = 0;
        for (int i = 0; i < sources.size(); i++) {
            if (sources.get(i).builtin) {
                n++;
            }
        }
        return n;
    }

    // ---------------- 设置页 ----------------

    private void bindSettingPage() {
        lvSettings = (ListView) settingPage.findViewById(R.id.lvSettings);
        setHint = (TextView) settingPage.findViewById(R.id.setHint);
        settingAdapter = new LineAdapter(this);
        lvSettings.setAdapter(settingAdapter);
        lvSettings.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                LineAdapter.Item item = (LineAdapter.Item) settingAdapter.getItem(position);
                if (SET_QUALITY.equals(item.text)) {
                    int q = prefs.quality();
                    q = q == PlayResolver.QUALITY_128 ? PlayResolver.QUALITY_320
                            : (q == PlayResolver.QUALITY_320 ? PlayResolver.QUALITY_FLAC
                            : PlayResolver.QUALITY_128);
                    prefs.setQuality(q);
                    refreshSettings();
                    applyQualityChange();
                } else if (SET_DOWNLOAD.equals(item.text)) {
                    prefs.setDownloadFirst(!prefs.downloadFirst());
                    refreshSettings();
                } else if (SET_SOURCE_ACTIVE.equals(item.text)) {
                    cycleActiveSource();
                } else if (SET_SOURCE_IMPORT.equals(item.text)) {
                    showImportDialog();
                } else if (SET_LYRIC_LEAD.equals(item.text)) {
                    // 人声领先、歌词没跟上就先调大提前量：高亮判定读的是 播放位置 + 提前量
                    prefs.cycleLyricLead();
                    refreshSettings();
                    syncLyricHighlight(player.position(), true);
                    Ui.toast(MainActivity.this, "歌词" + prefs.lyricLeadLabel()
                            + "（人声领先就继续按，档位会加大提前量）");
                    android.util.Log.i("StarMusicTV", "歌词提前量 => " + prefs.lyricLeadMs() + "ms");
                } else if (SET_CLEAR.equals(item.text)) {
                    images.clear();
                    Ui.toast(MainActivity.this, "已清除封面内存缓存");
                } else if (SET_ABOUT.equals(item.text)) {
                    Ui.toast(MainActivity.this, "星海音乐TV " + appVersion() + " · 聚合平台公开试听接口，仅供个人学习研究");
                }
            }
        });
        refreshSettings();
    }

    private void refreshSettings() {
        List<LineAdapter.Item> items = new ArrayList<LineAdapter.Item>();
        items.add(new LineAdapter.Item(SET_QUALITY, prefs.qualityLabel(), 0));
        items.add(new LineAdapter.Item(SET_DOWNLOAD, prefs.downloadFirstLabel(), 1));
        items.add(new LineAdapter.Item(SET_SOURCE_ACTIVE, activeSourceLabel(), 2));
        items.add(new LineAdapter.Item(SET_SOURCE_IMPORT, "按 OK 导入 .json 描述 / .js 脚本（在线地址或本地目录）", 3));
        items.add(new LineAdapter.Item(SET_LYRIC_LEAD,
                prefs.lyricLeadLabel() + "（按 OK 逐档切换，默认不提前）", 4));
        items.add(new LineAdapter.Item(SET_CLEAR, "按 OK 立即清除", 5));
        items.add(new LineAdapter.Item(SET_ABOUT, appVersion(), 6));
        settingAdapter.setData(items);
        LxSource lx = LxSource.active();
        String lxLine;
        if (lx != null && lx.isReady()) {
            String url = lx.sourceUrl().replace("https://raw.githubusercontent.com/", "GitHub ");
            lxLine = "音源脚本：" + lx.describe() + "（" + lx.scriptFile() + "，线路优先"
                    + (url.length() == 0 ? "" : "；内置音源接口 " + url) + "）";
        } else {
            lxLine = "音源脚本：未装载，使用内置直连线路";
        }
        setHint.setText("说明：默认取流音源线路是内置音源脚本"
                + "（官方地址 pdone/lx-music-source/main/fish/latest.js，见下方音源脚本行）；"
                + "该线路取不到时按 QQ音乐 → 酷狗 → 酷我 → 网易云的顺序回退。"
                + "搜索与歌词仍走各平台官方接口（QQ 官方歌词 / 酷我官方明文歌词 / 网易云兜底），"
                + "不提供下载与转载。"
                + "播放页长按 ← / → 可快退 / 快进 10 秒；从列表页点回正在播放的歌会保留播放进度。"
                + "歌词逐行高亮跟随人声：默认「不提前」，真机上若人声领先（歌词没跟上）就把「歌词提前量」往上调——"
                + "0.25 秒起可微调，最大可提前 8 秒，反向也有延后档。" + lxLine
                + "；当前音质：" + prefs.qualityLabel()
                + "；当前音源筛选：" + filterLabel(prefs.sourceFilter())
                + "；收藏 " + prefs.favorites().size() + " 首"
                + "；当前音源：" + activeSourceLabel() + "，另导入 " + importedCount() + " 个。");
    }

    /** 读清单里的版本号，避免界面上的版本信息与实际包不一致。 */
    private String appVersion() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Throwable t) {
            return "1.0.1";
        }
    }

    private void applyQualityChange() {
        if (player.index() >= 0) {
            Ui.toast(this, "音质已切换为 " + prefs.qualityLabel() + "，正在重新取流");
            player.playIndex(player.index());
        }
    }

    // ---------------- 播放页 ----------------

    private void bindPlayerPage() {
        vinyl = (VinylCoverView) playerPage.findViewById(R.id.vinyl);
        plTitle = (TextView) playerPage.findViewById(R.id.plTitle);
        plArtist = (TextView) playerPage.findViewById(R.id.plArtist);
        plAlbum = (TextView) playerPage.findViewById(R.id.plAlbum);
        lyricBox = (LinearLayout) playerPage.findViewById(R.id.lyricBox);
        plPos = (TextView) playerPage.findViewById(R.id.plPos);
        plDur = (TextView) playerPage.findViewById(R.id.plDur);
        plSource = (TextView) playerPage.findViewById(R.id.plSource);
        lyricScroll = (ScrollView) playerPage.findViewById(R.id.lyricScroll);
        seek = (SeekBar) playerPage.findViewById(R.id.seek);
        playerBusy = (ProgressBar) playerPage.findViewById(R.id.playerBusy);
        btnPrev = (TextView) playerPage.findViewById(R.id.btnPrev);
        btnPlay = (TextView) playerPage.findViewById(R.id.btnPlay);
        btnNext = (TextView) playerPage.findViewById(R.id.btnNext);
        btnRew = (TextView) playerPage.findViewById(R.id.btnRew);
        btnFwd = (TextView) playerPage.findViewById(R.id.btnFwd);
        btnFav = (TextView) playerPage.findViewById(R.id.btnFav);
        btnQuality = (TextView) playerPage.findViewById(R.id.btnQuality);
        btnMode = (TextView) playerPage.findViewById(R.id.btnMode);

        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                player.prev();
            }
        });
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                player.toggle();
            }
        });
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                player.next();
            }
        });
        btnRew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seekBy(-SEEK_STEP_MS);
            }
        });
        btnFwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seekBy(SEEK_STEP_MS);
            }
        });
        btnFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Song song = player.current();
                if (song == null) {
                    return;
                }
                boolean now = prefs.toggleFavorite(song);
                btnFav.setText(now ? "已收藏" : "收藏");
                refreshFavorites();
                Ui.toast(MainActivity.this, now ? "已加入收藏" : "已取消收藏");
            }
        });
        btnQuality.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int q = prefs.quality();
                q = q == PlayResolver.QUALITY_128 ? PlayResolver.QUALITY_320
                        : (q == PlayResolver.QUALITY_320 ? PlayResolver.QUALITY_FLAC
                        : PlayResolver.QUALITY_128);
                prefs.setQuality(q);
                btnQuality.setText(prefs.qualityLabel());
                refreshSettings();
                applyQualityChange();
            }
        });
        // 原「关闭」按钮（关闭播放页改用返回键）→ 播放模式切换：
        // 顺序播放 → 列表循环 → 单曲循环 → 随机播放，按钮上显示当前模式，选择存偏好、跨曲目保持。
        btnMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.cyclePlayMode();
                btnMode.setText(prefs.playModeLabel());
                Ui.toast(MainActivity.this, "播放模式：" + prefs.playModeLabel());
                android.util.Log.i("StarMusicTV", "播放模式 => " + prefs.playMode());
            }
        });
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (fromUser) {
                    plPos.setText(Ui.time(progress));
                    // 拖动进度条时歌词高亮实时跟着手感走
                    syncLyricHighlight(progress, false);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
                seeking = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                seeking = false;
                player.seekTo(bar.getProgress());
            }
        });
    }

    private void showPlayer() {
        if (!playerVisible) {
            playerVisible = true;
            playerPage.setVisibility(View.VISIBLE);
            playerPage.requestFocus();
            btnPlay.requestFocus();
            // 重新进入播放页时，歌词高亮同步到当前进度（歌词区刚可见时 getTop() 才有效）
            lyricBox.post(new Runnable() {
                @Override
                public void run() {
                    syncLyricHighlight(player.position(), true);
                }
            });
            updateLyricTick();
        }
    }

    private void hidePlayer() {
        if (playerVisible) {
            playerVisible = false;
            playerPage.setVisibility(View.GONE);
            if (page == PAGE_RANK) {
                lvRankSongs.requestFocus();
            } else if (page == PAGE_FAV) {
                lvFav.requestFocus();
            } else {
                lvResults.requestFocus();
            }
            updateLyricTick();
        }
    }

    /**
     * 列表页点歌入口。
     * 如果点的正是当前这首歌（正在播放 / 已暂停 / 正在解析），只切回播放页并保留播放进度，
     * 不重新取流、不从头播放；点别的歌才按新歌从头开始。
     */
    private void playFromList(List<Song> songs, int position, String from) {
        if (songs == null || songs.isEmpty()) {
            Ui.toast(this, "列表为空");
            return;
        }
        if (position < 0 || position >= songs.size()) {
            position = 0;
        }
        Song target = songs.get(position);
        Song cur = player.current();
        int st = player.state();
        boolean sameSong = cur != null && cur.key().equals(target.key())
                && (st == MusicPlayer.STATE_PLAYING || st == MusicPlayer.STATE_PAUSED
                || st == MusicPlayer.STATE_PREPARING);
        if (sameSong) {
            // 只切回播放页并保留进度：不重新取流、不重放，界面状态由 refreshPlayerUi 同步。
            // 这里不再弹「继续播放 / 已保留进度」的文字提示（按用户要求去掉），状态栏沿用播放器自己上报的最近一条状态。
            showPlayer();
            refreshPlayerUi();
            return;
        }
        playList(songs, position, from);
    }

    /** 切回播放页时把标题、进度条、时间、按钮状态同步到播放器当前状态（播放进度不丢）。 */
    private void refreshPlayerUi() {
        Song song = player.current();
        if (song == null) {
            return;
        }
        plTitle.setText(song.displayTitle());
        plArtist.setText(song.displayArtist());
        plAlbum.setText(song.album.length() == 0 ? song.sourceName() : song.album + " · " + song.sourceName());
        vinyl.setLabel(song.displayTitle());
        btnFav.setText(prefs.isFavorite(song) ? "已收藏" : "收藏");
        btnQuality.setText(prefs.qualityLabel());
        btnMode.setText(prefs.playModeLabel());
        int dur = player.duration();
        if (dur <= 0) {
            dur = song.duration;
        }
        int pos = player.position();
        if (dur > 0) {
            seek.setMax(dur);
            plDur.setText(Ui.time(dur));
        }
        seek.setProgress(pos);
        plPos.setText(Ui.time(pos));
        int st = player.state();
        vinyl.setPlaying(st == MusicPlayer.STATE_PLAYING);
        btnPlay.setText(st == MusicPlayer.STATE_PLAYING ? "暂停" : "播放");
        playerBusy.setVisibility(st == MusicPlayer.STATE_PREPARING ? View.VISIBLE : View.GONE);
        // 换歌 / 重新进入播放页时，歌词高亮立刻定位到当前进度
        syncLyricHighlight(pos, true);
    }

    private void playList(List<Song> songs, int position, String from) {
        if (songs == null || songs.isEmpty()) {
            Ui.toast(this, "列表为空");
            return;
        }
        lastNote = "来源：" + from;
        lastLog = "";
        showPlayer();
        player.playList(songs, position);
    }

    private void loadLyric(final Song song) {
        lrc = Lrc.parse("");
        setLyricMessage("歌词加载中…");
        netPool.execute(new Runnable() {
            @Override
            public void run() {
                String raw = "";
                if (Song.SRC_QQ.equals(song.source) && song.id.length() > 0) {
                    // QQ 音乐官方歌词接口（c.y.qq.com lyric）
                    raw = QqApi.lyric(song.id);
                }
                if (Song.SRC_KW.equals(song.source) && song.id.length() > 0 && raw.trim().length() == 0) {
                    // 酷我官方明文歌词接口（m.kuwo.cn），与搜索结果里的 rid 一一对应
                    raw = KwApi.lyric(song.id);
                }
                if (Song.SRC_WY.equals(song.source) && song.id.length() > 0 && raw.trim().length() == 0) {
                    raw = WyApi.lyric(song.id);
                }
                if (raw == null || raw.trim().length() == 0) {
                    // 非自身平台：先去 QQ 音乐官方接口按歌名+歌手找这首歌的歌词
                    List<Song> qq = QqApi.search(song.title + " " + song.artist, 5);
                    for (int i = 0; i < qq.size(); i++) {
                        if (qq.get(i).sameTitleArtist(song)) {
                            raw = QqApi.lyric(qq.get(i).id);
                            break;
                        }
                    }
                }
                if (raw == null || raw.trim().length() == 0) {
                    List<Song> found = WyApi.search(song.title + " " + song.artist, 5);
                    for (int i = 0; i < found.size(); i++) {
                        if (found.get(i).sameTitleArtist(song)) {
                            raw = WyApi.lyric(found.get(i).id);
                            break;
                        }
                    }
                }
                final String lyricRaw = raw == null ? "" : raw;
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        Song cur = player.current();
                        if (cur == null || !cur.key().equals(song.key())) {
                            return;
                        }
                        lrc = Lrc.parse(lyricRaw);
                        if (lrc.isEmpty()) {
                            setLyricMessage("暂无歌词");
                        } else {
                            renderLyricLines();
                        }
                    }
                });
            }
        });
    }

    // ---------------- 逐行歌词（当前行高亮 + 与人声同步） ----------------

    /** 歌词区只显示一行提示（加载中 / 暂无歌词）。 */
    private void setLyricMessage(String msg) {
        lyricLineIndex = -1;
        lyricBox.removeAllViews();
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
        tv.setTextColor(Ui.color(this, R.color.text_dim));
        tv.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
        lyricBox.addView(tv);
        lyricScroll.scrollTo(0, 0);
        updateLyricTick();
    }

    /**
     * 把歌词铺成逐行视图：一行一个 TextView。
     * 逐行渲染的好处是当前行只需要改颜色（invalidate），不会像整段大文本那样每次刷新都触发
     * 昂贵的 StaticLayout 重新测量——API 19 软渲染电视端尤其在意这一点。
     */
    private void renderLyricLines() {
        lyricLineIndex = -1;
        lyricBox.removeAllViews();
        if (lrc.isEmpty()) {
            setLyricMessage("暂无歌词");
            return;
        }
        int normal = Ui.color(this, R.color.text_dim);
        List<Lrc.Line> lines = lrc.lines();
        for (int i = 0; i < lines.size(); i++) {
            String text = lines.get(i).text;
            TextView tv = new TextView(this);
            // 空行（纯伴奏段）保留一行高度，让滚动节奏与时间轴一致
            tv.setText(text.length() == 0 ? " " : text);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
            tv.setTextColor(normal);
            tv.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
            tv.setLineSpacing(Ui.dp(this, 8), 1f);
            lyricBox.addView(tv);
        }
        lyricScroll.scrollTo(0, 0);
        // 布局完成后 getTop() 才有值，因此位置同步放到下一帧
        final int startMs = player.position();
        lyricBox.post(new Runnable() {
            @Override
            public void run() {
                syncLyricHighlight(startMs, true);
            }
        });
        updateLyricTick();
    }

    /**
     * 按播放位置同步高亮行并滚动居中。
     * 只在“高亮行发生变化”时改颜色与滚动，避免每 500ms 的进度回调里做无谓工作。
     */
    private void syncLyricHighlight(int positionMs, boolean force) {
        if (lrc.isEmpty() || lyricBox.getChildCount() == 0) {
            return;
        }
        // 高亮判定用「播放位置 + 提前量」：真机上歌词比人声慢时，提前量把它拉回来；
        // 提前量在设置页「歌词提前量」里逐档调（默认不提前，真机偏晚时逐档往上加）。
        int lead = prefs.lyricLeadMs();
        int probe = positionMs + lead;
        int idx = lrc.indexAt(probe);
        if (idx < 0 || idx >= lyricBox.getChildCount()) {
            return;
        }
        if (idx != lyricLineIndex || force) {
            if (lyricLineIndex >= 0 && lyricLineIndex < lyricBox.getChildCount()
                    && lyricLineIndex != idx) {
                ((TextView) lyricBox.getChildAt(lyricLineIndex))
                        .setTextColor(Ui.color(this, R.color.text_dim));
            }
            ((TextView) lyricBox.getChildAt(idx)).setTextColor(Ui.color(this, R.color.accent));
            lyricLineIndex = idx;
            scrollLyricToCenter(idx);
            String text = lrc.lines().get(idx).text;
            android.util.Log.i("StarMusicTV", "歌词高亮 => 第" + (idx + 1) + "行 位置="
                    + Ui.time(positionMs) + "(" + positionMs + "ms) 行时间戳="
                    + Ui.time(lrc.lines().get(idx).time) + "(" + lrc.lines().get(idx).time + "ms)"
                    + " 提前=" + lead + "ms 偏差=" + (positionMs - lrc.lines().get(idx).time) + "ms"
                    + " " + (text.length() > 18 ? text.substring(0, 18) : text));
            // 换行后按「下一行时间戳」精确排一次，把轮询的 ±250ms 量化误差压掉
            scheduleLyricSwitch();
        }
    }

    /**
     * 按「下一行时间戳 − 提前量」精确调度下一次换行判定：
     * 触发时用当时的播放位置重算（自校正），所以拖动 / 暂停 / 换歌都不会错档；
     * 超过 4 秒的长间隔交给 250ms 轮询兜底，避免长时间挂着一个调度。
     */
    private void scheduleLyricSwitch() {
        main.removeCallbacks(lyricSwitchTask);
        if (lrc.isEmpty() || !playerVisible || lyricLineIndex < 0) {
            return;
        }
        List<Lrc.Line> lines = lrc.lines();
        int next = -1;
        for (int i = lyricLineIndex + 1; i < lines.size(); i++) {
            if (lines.get(i).time >= 0) {
                next = i;
                break;
            }
        }
        if (next < 0) {
            return;   // 已经是最后一行，结尾由换歌/播完处理
        }
        int delay = lines.get(next).time - prefs.lyricLeadMs() - player.position();
        if (delay < 20) {
            delay = 20;         // 已到或已过：交给下一次轮询判定，避免空转
        } else if (delay > 10000) {
            delay = 10000;      // 用不到的超长间隔才截断（正常换行间隔 2~6 秒，要保证按点触发）
        }
        main.postDelayed(lyricSwitchTask, delay);
    }

    /**
     * 歌词页可见且已经铺好逐行歌词时，把进度回调收紧到 250ms：
     * 换行判定更密 → 高亮与歌词时间戳（也就是人声）跟得更紧；其它情况保持 500ms，不做无谓开销。
     */
    private void updateLyricTick() {
        boolean fast = playerVisible && !lrc.isEmpty() && lyricBox.getChildCount() > 0;
        player.setFastTick(fast);
        if (!fast) {
            // 播放页收起 / 没有歌词时，取消还没执行的精确调度
            main.removeCallbacks(lyricSwitchTask);
        }
    }

    /** 把第 idx 行滚到歌词区正中（歌词区高度固定，当前行居中更适合跟唱）。 */
    private void scrollLyricToCenter(int idx) {
        View line = lyricBox.getChildAt(idx);
        if (line == null || line.getHeight() == 0) {
            return;
        }
        int target = line.getTop() - (lyricScroll.getHeight() - line.getHeight()) / 2;
        lyricScroll.scrollTo(0, target < 0 ? 0 : target);
    }

    // ---------------- 页面切换 ----------------

    private void showPage(int target) {
        page = target;
        searchPage.setVisibility(target == PAGE_SEARCH ? View.VISIBLE : View.GONE);
        rankPage.setVisibility(target == PAGE_RANK ? View.VISIBLE : View.GONE);
        favPage.setVisibility(target == PAGE_FAV ? View.VISIBLE : View.GONE);
        settingPage.setVisibility(target == PAGE_SETTING ? View.VISIBLE : View.GONE);
        navSearch.setSelected(target == PAGE_SEARCH);
        navRank.setSelected(target == PAGE_RANK);
        navFav.setSelected(target == PAGE_FAV);
        navSetting.setSelected(target == PAGE_SETTING);

        if (target == PAGE_SEARCH) {
            if (searchAdapter.getCount() > 0) {
                lvResults.requestFocus();
            } else {
                btnSearch.requestFocus();
            }
        } else if (target == PAGE_RANK) {
            lvRankCats.requestFocus();
            if (!rankLoaded) {
                loadStation(currentStation);
            } else if (rankAdapter.getCount() > 0) {
                lvRankSongs.requestFocus();
            }
        } else if (target == PAGE_FAV) {
            refreshFavorites();
            if (favAdapter.getCount() > 0) {
                lvFav.requestFocus();
            } else {
                Ui.toast(this, "还没有收藏，播放页按 OK 键可收藏当前歌曲");
                navFav.requestFocus();
            }
        } else if (target == PAGE_SETTING) {
            refreshSettings();
            lvSettings.requestFocus();
        }
    }

    /**
     * 遥控器确认键兜底处理。
     * Android 4.4 上 ListView 自己持有焦点（列表项不接焦点、只显示选中态），
     * 部分机型框架内部不会把确认键转成条目点击，于是在列表上直接拦住 OK / ENTER，
     * 回接到与条目点击完全相同的逻辑，保证遥控器一定可用。
     */
    private void attachConfirmKeyListener(final ListView list) {
        list.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() != KeyEvent.ACTION_DOWN) {
                    return false;
                }
                if (keyCode != KeyEvent.KEYCODE_DPAD_CENTER && keyCode != KeyEvent.KEYCODE_ENTER
                        && keyCode != KeyEvent.KEYCODE_NUMPAD_ENTER) {
                    return false;
                }
                if (list.getAdapter() == null || list.getAdapter().getCount() == 0) {
                    return false;
                }
                int position = list.getSelectedItemPosition();
                if (position < 0) {
                    position = 0;
                }
                android.util.Log.i("StarMusicTV", "确认键 -> 列表条目 " + position);
                list.performItemClick(null, position, position);
                return true;
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY
                || keyCode == KeyEvent.KEYCODE_MEDIA_PAUSE) {
            player.toggle();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
            player.next();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
            player.prev();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_MEDIA_REWIND) {
            seekBy(-SEEK_STEP_MS);
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD) {
            seekBy(SEEK_STEP_MS);
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            // 收藏页：菜单键 = 取消当前选中这一行的收藏（新增）；
            // 其它页面仍然跳设置页（保持原有行为不变）。
            if (page == PAGE_FAV && !playerVisible) {
                removeFocusedFavorite();
                return true;
            }
            showPage(PAGE_SETTING);
            return true;
        }
        if (playerVisible && (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)) {
            // 播放页长按 ← / → = 快退 / 快进 10 秒。
            // 长按的判定同时看两种信号：按住时的重复事件（真机遥控器长按会持续补发，首次约 0.5 秒后到达），
            // 以及系统打上的 FLAG_LONG_PRESS（部分遥控/注入方式只给这个标志）。
            // 短按两种都不满足，因此仍然保持原来的焦点移动 / 进度条拖动行为。
            boolean longPress = event.getRepeatCount() > 0
                    || (event.getFlags() & KeyEvent.FLAG_LONG_PRESS) != 0;
            android.util.Log.i("StarMusicTV", "方向键 keyCode=" + keyCode
                    + " repeat=" + event.getRepeatCount() + " flags=" + event.getFlags()
                    + " => longPress=" + longPress);
            if (!longPress) {
                arrowHoldKey = keyCode;
                arrowHoldConsumed = false;
            } else {
                if (!arrowHoldConsumed) {
                    arrowHoldConsumed = true;
                    arrowHoldKey = keyCode;
                    seekBy(keyCode == KeyEvent.KEYCODE_DPAD_LEFT ? -SEEK_STEP_MS : SEEK_STEP_MS);
                }
                return true;   // 长按已处理，继续按住时不让进度条跟着反复抖动
            }
        }
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (playerVisible) {
                hidePlayer();
                return true;
            }
            if (page != PAGE_SEARCH) {
                showPage(PAGE_SEARCH);
                return true;
            }
            // 已经在首页：退出前弹确认框，遥控器误触不会直接退出
            confirmExit();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /** 退出确认框（防遥控器误触）。 */
    private void confirmExit() {
        try {
            new android.app.AlertDialog.Builder(this)
                    .setTitle("退出应用")
                    .setMessage("确定要退出" + getString(R.string.app_name) + "吗？")
                    .setPositiveButton("退出", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface dialog, int which) {
                            dialog.dismiss();
                            finish();
                        }
                    })
                    .setNegativeButton("取消", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .setCancelable(true)
                    .show();
        } catch (Throwable t) {
            // 弹窗起不来时不要卡住用户
            finish();
        }
    }

    /** 快进/快退（毫秒），带 0 与曲目时长边界保护。 */
    private void seekBy(int deltaMs) {
        Song song = player.current();
        if (song == null) {
            Ui.toast(this, "还没有在播放的歌曲");
            return;
        }
        player.seekBy(deltaMs);
        int pos = player.position();
        // 暂停状态下进度条不会再被 ticker 刷新，这里直接把界面同步过去
        seek.setProgress(pos);
        plPos.setText(Ui.time(pos));
        Ui.toast(this, (deltaMs > 0 ? "快进 " : "快退 ") + Math.abs(deltaMs / 1000) + " 秒 → " + Ui.time(pos));
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == arrowHoldKey) {
            arrowHoldConsumed = false;
            arrowHoldKey = -1;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        if (player != null) {
            player.stopAndRelease();
        }
        netPool.shutdownNow();
        super.onDestroy();
    }

    // ---------------- 播放回调 ----------------

    @Override
    public void onSongChanged(final Song song, int index) {
        lastLog = "";
        plTitle.setText(song.displayTitle());
        plArtist.setText(song.displayArtist());
        plAlbum.setText(song.album.length() == 0 ? song.sourceName() : song.album + " · " + song.sourceName());
        vinyl.setLabel(song.displayTitle());
        vinyl.setCover(null);
        images.load(song.cover, vinyl);
        btnFav.setText(prefs.isFavorite(song) ? "已收藏" : "收藏");
        btnQuality.setText(prefs.qualityLabel());
        btnMode.setText(prefs.playModeLabel());
        plPos.setText("00:00");
        plDur.setText(song.duration > 0 ? Ui.time(song.duration) : "00:00");
        seek.setMax(song.duration > 0 ? song.duration : 1);
        seek.setProgress(0);
        playerBusy.setVisibility(View.VISIBLE);
        plSource.setText("正在准备：" + song.displayTitle());
        loadLyric(song);
        // 换歌（含播完自动切下一首、手动上一首/下一首）后，列表页光标跟着走到当前歌曲所在行
        syncListFollow();
    }

    @Override
    public void onStateChanged(int state) {
        boolean playing = state == MusicPlayer.STATE_PLAYING;
        vinyl.setPlaying(playing);
        btnPlay.setText(playing ? "暂停" : "播放");
        playerBusy.setVisibility(state == MusicPlayer.STATE_PREPARING ? View.VISIBLE : View.GONE);
        if (state == MusicPlayer.STATE_ERROR) {
            vinyl.setPlaying(false);
        }
    }

    @Override
    public void onProgress(int positionMs, int durationMs) {
        if (!seeking && durationMs > 0) {
            seek.setMax(durationMs);
            seek.setProgress(positionMs);
        }
        plPos.setText(Ui.time(positionMs));
        if (durationMs > 0) {
            plDur.setText(Ui.time(durationMs));
        }
        // 逐行歌词高亮：按 LRC 时间轴换行并滚动居中（只在换行时改颜色 / 滚动）
        if (playerVisible) {
            syncLyricHighlight(positionMs, false);
        }
    }

    @Override
    public void onStatusNote(String note) {
        lastNote = note;
        renderSource();
    }

    @Override
    public void onResolveLog(String log) {
        lastLog = log == null ? "" : log;
        renderSource();
    }

    private void renderSource() {
        StringBuilder sb = new StringBuilder();
        if (lastNote.length() > 0) {
            sb.append(lastNote);
        }
        if (lastLog.length() > 0) {
            if (sb.length() > 0) {
                sb.append('\n');
            }
            sb.append(lastLog);
        }
        plSource.setText(sb.toString());
    }
}