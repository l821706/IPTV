package com.freemusic.tv;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 播放器：解析线路 → 播放 → 失败换线路 → 仍失败则整曲下载到本地再播。
 * 老设备上 HTTPS 音频流经常播不出来，因此 HTTPS 线路默认走“先缓存再播”。
 */
public final class MusicPlayer {

    public interface Listener {
        void onSongChanged(Song song, int index);

        void onStateChanged(int state);

        void onProgress(int positionMs, int durationMs);

        void onStatusNote(String note);

        void onResolveLog(String log);
    }

    public static final int STATE_IDLE = 0;
    public static final int STATE_PREPARING = 1;
    public static final int STATE_PLAYING = 2;
    public static final int STATE_PAUSED = 3;
    public static final int STATE_ERROR = 4;

    private final ContextRef ctxRef;
    private final Prefs prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private final List<Song> playlist = new ArrayList<Song>();

    private Listener listener;
    private MediaPlayer mp;
    private int index = -1;
    private int state = STATE_IDLE;
    private int pendingSeek = -1;
    /** 最近一次上报的播放位置与时长，供快进/快退取边界用。 */
    private int lastPosition;
    private int lastDuration;
    private long token;
    private boolean released;
    /**
     * 歌词页可见时打开：进度回调从 500ms 收紧到 250ms，
     * 让逐行高亮换行点更贴近歌词时间戳（跟随率的量化改善）。
     */
    private boolean fastTick;

    /** 本地音频缓存上限：cacheDir 下 stream_* 总量最大 40MB、最多 6 个（超出按最旧的先删）。 */
    private static final long CACHE_MAX_BYTES = 40L * 1024 * 1024;
    private static final int CACHE_MAX_FILES = 6;
    /** 当前播放所依赖的本地缓存文件（只有「下载后再播」路径非空）；播完 / 切歌 / 停止时回收。 */
    private volatile File currentCacheFile;
    /** 正在下载中的缓存文件（修剪时跳过，避免删掉写了半截的文件）。 */
    private volatile File pendingCacheFile;

    /** 只用来拿 cacheDir，避免持有 Activity。 */
    public static final class ContextRef {
        public final android.content.Context app;

        public ContextRef(android.content.Context c) {
            this.app = c.getApplicationContext();
        }
    }

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (mp != null && listener != null) {
                try {
                    lastPosition = mp.getCurrentPosition();
                    lastDuration = mp.getDuration();
                    listener.onProgress(lastPosition, lastDuration);
                } catch (Throwable ignore) {
                    // 播放器状态瞬变时忽略
                }
            }
            if (state == STATE_PLAYING) {
                handler.postDelayed(this, fastTick ? 250 : 500);
            }
        }
    };

    public MusicPlayer(android.content.Context ctx, Prefs prefs) {
        this.ctxRef = new ContextRef(ctx);
        this.prefs = prefs;
    }

    public void setListener(Listener l) {
        this.listener = l;
    }

    /** 进度回调频率：true 时 250ms（歌词页可见），false 时 500ms。 */
    public void setFastTick(boolean v) {
        fastTick = v;
    }

    public List<Song> playlist() {
        return new ArrayList<Song>(playlist);
    }

    public int index() {
        return index;
    }

    public int state() {
        return state;
    }

    public boolean isPlaying() {
        return state == STATE_PLAYING;
    }

    public Song current() {
        if (index < 0 || index >= playlist.size()) {
            return null;
        }
        return playlist.get(index);
    }

    public Song songAt(int i) {
        if (i < 0 || i >= playlist.size()) {
            return null;
        }
        return playlist.get(i);
    }

    public void playList(List<Song> songs, int startIndex) {
        recycleCurrentCache();
        playlist.clear();
        if (songs != null) {
            playlist.addAll(songs);
        }
        if (playlist.isEmpty()) {
            note("没有可播放的歌曲");
            return;
        }
        playIndex(startIndex);
    }

    public void playIndex(int i) {
        if (released || playlist.isEmpty()) {
            return;
        }
        if (i < 0) {
            i = 0;
        }
        if (i >= playlist.size()) {
            i = playlist.size() - 1;
        }
        recycleCurrentCache();
        index = i;
        final Song song = playlist.get(i);
        if (listener != null) {
            listener.onSongChanged(song, index);
        }
        setState(STATE_PREPARING);
        note("正在解析线路…");
        final long myToken = ++token;
        releasePlayer();
        final int quality = prefs.quality();
        pool.execute(new Runnable() {
            @Override
            public void run() {
                final PlayResolver.Result result = PlayResolver.resolve(song, quality);
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (myToken != token || released) {
                            return;
                        }
                        if (listener != null) {
                            listener.onResolveLog(result.log());
                        }
                        if (!result.ok()) {
                            setState(STATE_ERROR);
                            note("取流失败：" + result.note + "（可切换音质或换一首）");
                            return;
                        }
                        note("线路：" + result.label + (result.note.length() == 0 ? "" : "；" + result.note));
                        startUrl(result.url, myToken);
                    }
                });
            }
        });
    }

    public void toggle() {
        if (state == STATE_PLAYING && mp != null) {
            try {
                mp.pause();
                setState(STATE_PAUSED);
                note("已暂停，按播放键继续");
            } catch (Throwable ignore) {
                note("暂停失败");
            }
            return;
        }
        if (state == STATE_PAUSED && mp != null) {
            try {
                mp.start();
                setState(STATE_PLAYING);
                startTicker();
                // 状态行只报当前播放状态，不再出现「继续播放」这类提示文字（按用户要求去掉）
                note("播放中");
            } catch (Throwable ignore) {
                note("恢复播放失败，重新取流");
                playIndex(index);
            }
            return;
        }
        playIndex(index < 0 ? 0 : index);
    }

    /** 下一首：随机模式随机取一首，其余按列表顺序；顺序播放已到末尾则不再继续。 */
    public void next() {
        if (playlist.isEmpty()) {
            note("播放列表为空");
            return;
        }
        int mode = prefs.playMode();
        if (mode == Prefs.MODE_SHUFFLE) {
            playIndex(randomIndex());
            return;
        }
        if (mode == Prefs.MODE_SEQUENCE && index >= playlist.size() - 1) {
            note("已是最后一首（顺序播放）");
            return;
        }
        playIndex((index + 1) % playlist.size());
    }

    /**
     * 上一首：始终按列表顺序回退（到头回到末尾）。
     * 单曲循环 / 随机模式下手动按上一首同样允许切走，符合遥控器常见预期。
     */
    public void prev() {
        if (playlist.isEmpty()) {
            note("播放列表为空");
            return;
        }
        playIndex((index - 1 + playlist.size()) % playlist.size());
    }

    /** 播完一首后按当前播放模式推进：单曲重放 / 随机选曲 / 顺序到底停 / 列表循环。 */
    private void advanceOnCompletion() {
        if (playlist.isEmpty()) {
            return;
        }
        int mode = prefs.playMode();
        if (mode == Prefs.MODE_LOOP_ONE) {
            replayCurrent();
            return;
        }
        if (mode == Prefs.MODE_SHUFFLE) {
            playIndex(randomIndex());
            return;
        }
        if (mode == Prefs.MODE_SEQUENCE) {
            if (index >= playlist.size() - 1) {
                finishPlaylist();
                return;
            }
            playIndex(index + 1);
            return;
        }
        playIndex((index + 1) % playlist.size());
    }

    /** 单曲循环：不重新取流，直接把当前曲目从头播放。 */
    private void replayCurrent() {
        if (index < 0 || index >= playlist.size()) {
            playIndex(0);
            return;
        }
        if (mp != null) {
            try {
                mp.seekTo(0);
                mp.start();
                setState(STATE_PLAYING);
                startTicker();
                note("单曲循环：重放本曲");
                return;
            } catch (Throwable ignore) {
                // 落到重新取流
            }
        }
        playIndex(index);
    }

    /** 顺序播放到列表末尾：停在最后一首的末尾，不再继续。 */
    private void finishPlaylist() {
        if (mp != null) {
            try {
                mp.pause();
            } catch (Throwable ignore) {
                // 忽略
            }
        }
        setState(STATE_PAUSED);
        note("顺序播放已到最后一首，播放结束");
    }

    /** 随机取一个不同于当前曲目的下标（列表只有一首时返回 0）。 */
    private int randomIndex() {
        int size = playlist.size();
        if (size <= 1) {
            return 0;
        }
        int cur = index;
        int pick = cur;
        for (int i = 0; i < 8 && pick == cur; i++) {
            pick = (int) (Math.random() * size);
        }
        if (pick == cur) {
            pick = (cur + 1) % size;
        }
        return pick;
    }

    public void seekTo(int ms) {
        if (mp == null) {
            pendingSeek = ms;
            return;
        }
        try {
            mp.seekTo(ms);
        } catch (Throwable ignore) {
            // 忽略
        }
    }

    /** 当前播放位置（毫秒）。 */
    public int position() {
        if (mp != null) {
            try {
                return mp.getCurrentPosition();
            } catch (Throwable ignore) {
                // 落到记录值
            }
        }
        return lastPosition < 0 ? 0 : lastPosition;
    }

    /** 当前曲目时长（毫秒），拿不到返回 0。 */
    public int duration() {
        if (mp != null) {
            try {
                int d = mp.getDuration();
                if (d > 0) {
                    return d;
                }
            } catch (Throwable ignore) {
                // 落到记录值
            }
        }
        return lastDuration < 0 ? 0 : lastDuration;
    }

    /** 快进/快退：正数快进、负数快退，自动做 0 与曲目时长的边界保护。 */
    public void seekBy(int deltaMs) {
        int dur = duration();
        if (dur <= 0) {
            Song s = current();
            dur = s == null ? 0 : s.duration;
        }
        int target = position() + deltaMs;
        if (target < 0) {
            target = 0;
        }
        if (dur > 0 && target > dur) {
            target = dur;
        }
        seekTo(target);
    }

    public void stopAndRelease() {
        token++;
        handler.removeCallbacks(ticker);
        releasePlayer();
        recycleCurrentCache();
        setState(STATE_IDLE);
    }

    private void startUrl(final String url, final long myToken) {
        boolean https = url != null && url.startsWith("https://");
        if (https || prefs.downloadFirst()) {
            downloadAndPlay(url, myToken, https ? "该线路为 HTTPS，老设备先缓存再播放" : "按设置先缓存再播放");
        } else {
            prepare(url, myToken, false, url);
        }
    }

    private void prepare(final String dataSource, final long myToken, final boolean localSource,
                         final String fallbackUrl) {
        if (!localSource) {
            currentCacheFile = null;
        }
        try {
            MediaPlayer player = new MediaPlayer();
            player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            player.setDataSource(dataSource);
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer p) {
                    if (myToken != token || released) {
                        try {
                            p.release();
                        } catch (Throwable ignore) {
                            // 忽略
                        }
                        return;
                    }
                    if (pendingSeek > 0) {
                        try {
                            p.seekTo(pendingSeek);
                        } catch (Throwable ignore) {
                            // 忽略
                        }
                        pendingSeek = -1;
                    }
                    p.start();
                    setState(STATE_PLAYING);
                    startTicker();
                }
            });
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer p) {
                    if (myToken == token && !released) {
                        // 播完先把「已缓存到本地」的那一份回收掉；单曲循环要重放，保留不删
                        if (prefs.playMode() != Prefs.MODE_LOOP_ONE) {
                            recycleCurrentCache();
                        }
                        // 播完按当前播放模式推进（顺序 / 列表循环 / 单曲循环 / 随机）
                        advanceOnCompletion();
                    }
                }
            });
            player.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer p, int what, int extra) {
                    if (myToken != token || released) {
                        return true;
                    }
                    releasePlayer();
                    if (localSource) {
                        recycleCurrentCache();
                        setState(STATE_ERROR);
                        note("本地文件播放失败（what=" + what + "）");
                    } else {
                        downloadAndPlay(fallbackUrl, myToken, "流式播放失败（what=" + what + "），改用缓存播放");
                    }
                    return true;
                }
            });
            mp = player;
            player.prepareAsync();
        } catch (Throwable t) {
            if (localSource) {
                setState(STATE_ERROR);
                note("无法打开本地音频：" + t.getClass().getSimpleName());
            } else {
                downloadAndPlay(fallbackUrl, myToken, "流式播放异常（" + t.getClass().getSimpleName() + "），改用缓存播放");
            }
        }
    }

    private void downloadAndPlay(final String url, final long myToken, final String reasonNote) {
        if (reasonNote != null) {
            note(reasonNote);
        }
        note("正在缓冲下载…");
        final File dst = cacheFileFor(url);
        final Map<String, String> headers = headersFor(url);
        pool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    trimCache();
                    pendingCacheFile = dst;
                    Http.download(url, headers, dst, new Http.Progress() {
                        @Override
                        public void onProgress(final int read, final int total) {
                            if (myToken != token) {
                                return;
                            }
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    if (myToken == token) {
                                        note(total > 0 ? "正在缓冲下载 " + (read * 100 / total) + "%"
                                                : "正在缓冲下载 " + (read / 1024) + "KB");
                                    }
                                }
                            });
                        }
                    });
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            pendingCacheFile = null;
                            if (myToken == token && !released) {
                                currentCacheFile = dst;
                                note("已缓存到本地，开始播放");
                                prepare(dst.getAbsolutePath(), myToken, true, url);
                            } else {
                                // 下载完成时用户已经切歌 / 停止：这份缓存没人用了，直接回收
                                deleteQuietly(dst, "下载完成时已切歌");
                            }
                        }
                    });
                } catch (final Exception e) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (myToken == token) {
                                setState(STATE_ERROR);
                                note("下载失败：" + e.getClass().getSimpleName()
                                        + (e.getMessage() == null ? "" : " " + e.getMessage()));
                            }
                        }
                    });
                }
            }
        });
    }

    /** 回收当前播放所用的本地缓存文件（跳过正在下载的那份）；失败静默、不影响播放。 */
    private void recycleCurrentCache() {
        File f = currentCacheFile;
        currentCacheFile = null;
        if (f == null) {
            return;
        }
        if (f.equals(pendingCacheFile)) {
            return;
        }
        deleteQuietly(f, "播完 / 切歌 / 停止回收");
    }

    private void deleteQuietly(File f, String why) {
        if (f == null) {
            return;
        }
        try {
            long size = f.length();
            if (f.isFile() && f.delete()) {
                android.util.Log.i("StarMusicTV", "缓存清理 => 删除 " + f.getName() + "（" + (size / 1024)
                        + "KB，" + why + "）");
            }
        } catch (Throwable t) {
            android.util.Log.i("StarMusicTV", "缓存清理失败（忽略）：" + f.getName() + " " + t.getClass().getSimpleName());
        }
    }

    /**
     * 修剪 cacheDir 下的本地音频缓存：总量上限 40MB、文件数上限 6 个，超出按「最旧的先删」；
     * 另外清掉上次异常退出残留的 *.part（10 分钟还没写完的）。正在播放 / 正在下载的文件绝不删。
     */
    private void trimCache() {
        try {
            java.io.File dir = ctxRef.app.getCacheDir();
            java.io.File[] files = dir == null ? null : dir.listFiles();
            if (files == null) {
                return;
            }
            List<java.io.File> streams = new ArrayList<java.io.File>();
            long total = 0;
            long now = System.currentTimeMillis();
            for (int i = 0; i < files.length; i++) {
                java.io.File f = files[i];
                if (f == null || !f.isFile()) {
                    continue;
                }
                String n = f.getName();
                if (!n.startsWith("stream_")) {
                    continue;
                }
                if (n.endsWith(".part")) {
                    if (now - f.lastModified() > 10 * 60 * 1000L) {
                        deleteQuietly(f, "残留半成品");
                    }
                    continue;
                }
                streams.add(f);
                total += f.length();
            }
            java.util.Collections.sort(streams, new java.util.Comparator<java.io.File>() {
                @Override
                public int compare(java.io.File a, java.io.File b) {
                    long x = a.lastModified();
                    long y = b.lastModified();
                    if (x == y) {
                        return 0;
                    }
                    return x < y ? -1 : 1;
                }
            });
            int count = streams.size();
            int removed = 0;
            long freed = 0;
            for (int i = 0; i < streams.size(); i++) {
                if (count <= CACHE_MAX_FILES && total <= CACHE_MAX_BYTES) {
                    break;
                }
                java.io.File f = streams.get(i);
                if (f.equals(currentCacheFile) || f.equals(pendingCacheFile)) {
                    continue;
                }
                long size = f.length();
                if (f.delete()) {
                    count--;
                    total -= size;
                    removed++;
                    freed += size;
                }
            }
            if (removed > 0) {
                android.util.Log.i("StarMusicTV", "缓存修剪 => 删 " + removed + " 个（释放 " + (freed / 1048576)
                        + "MB），剩余 " + count + " 个/" + (total / 1048576) + "MB，上限 "
                        + (CACHE_MAX_BYTES / 1048576) + "MB / " + CACHE_MAX_FILES + " 个");
            }
        } catch (Throwable t) {
            android.util.Log.i("StarMusicTV", "缓存修剪跳过：" + t.getClass().getSimpleName());
        }
    }

    private File cacheFileFor(String url) {
        String ext = ".mp3";
        if (url != null) {
            if (url.indexOf(".flac") >= 0) {
                ext = ".flac";
            } else if (url.indexOf(".m4a") >= 0 || url.indexOf(".aac") >= 0) {
                ext = ".m4a";
            }
        }
        return new File(ctxRef.app.getCacheDir(), "stream_" + Math.abs(url == null ? 0 : url.hashCode()) + ext);
    }

    private Map<String, String> headersFor(String url) {
        if (url != null && url.indexOf("music.163.com") >= 0) {
            return WyApi.headers();
        }
        return Http.headers();
    }

    private void startTicker() {
        handler.removeCallbacks(ticker);
        handler.postDelayed(ticker, 500);
    }

    private void releasePlayer() {
        handler.removeCallbacks(ticker);
        if (mp != null) {
            try {
                mp.reset();
            } catch (Throwable ignore) {
                // 忽略
            }
            try {
                mp.release();
            } catch (Throwable ignore) {
                // 忽略
            }
            mp = null;
        }
    }

    private void setState(int s) {
        state = s;
        if (listener != null) {
            listener.onStateChanged(s);
        }
    }

    private void note(String msg) {
        if (listener != null) {
            listener.onStatusNote(msg);
        }
    }
}