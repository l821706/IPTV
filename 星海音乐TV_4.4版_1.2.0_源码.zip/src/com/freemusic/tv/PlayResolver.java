package com.freemusic.tv;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 多线路取流解析器。
 *
 * 线路顺序（2026-11-05 16:17 起的用户要求：默认线路用内置音源）：
 *   ① 内置音源线路（assets/lx_sources 下由 build.sh 从官方地址取回的脚本链路，见 FishApi）
 *   ② QQ音乐官方接口  →  ③ 酷狗音乐  →  ④ 酷我音乐  →  ⑤ 网易云音乐（回退）
 *   ⑥ 模板型脚本音源线路（若有模板）
 *
 * 每一条候选都先取前 2KB 验真为音频才交给播放器；命中即停，不再继续后面的线路。
 * 「同一首歌」的跨平台匹配用歌名 + 歌手打分（见 bestMatch）。
 * 歌词接口与线路无关，仍在 MainActivity.loadLyric 里按平台走 QQ 官方 / 酷我官方 / 网易云。
 */
public final class PlayResolver {

    /** 音质档：高品 128K / 超品 320K / 无损 FLAC。 */
    public static final int QUALITY_128 = 1;
    public static final int QUALITY_320 = 2;
    public static final int QUALITY_FLAC = 3;

    public static class Attempt {
        public String label = "";
        public String url = "";
        public int code;
        public String contentType = "";
        public boolean audio;
        public String note = "";

        public String describe() {
            String state = audio ? "OK" : "FAIL";
            String ct = contentType.length() == 0 ? "-" : contentType;
            String u = url.length() > 64 ? url.substring(0, 64) + "..." : url;
            return "[" + state + "] " + label + " · HTTP " + code + " · " + ct
                    + (note.length() == 0 ? "" : " · " + note) + "\n    " + u;
        }
    }

    public static class Result {
        public String url = "";
        public String label = "";
        public String contentType = "";
        public String note = "";
        public final List<Attempt> attempts = new ArrayList<Attempt>();

        public boolean ok() {
            return url.length() > 0;
        }

        public String log() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < attempts.size(); i++) {
                if (sb.length() > 0) {
                    sb.append('\n');
                }
                sb.append(attempts.get(i).describe());
            }
            return sb.toString();
        }
    }

    private static final class Cand {
        String label;
        String url;
        String note = "";
        /** 第三方代理类线路用更短的探测超时，避免拖慢整体取流。 */
        boolean shortTimeout;
    }

    private PlayResolver() {
    }

    public static Result resolve(Song song, int quality) {
        Result r = new Result();
        if (song == null || song.id.length() == 0) {
            r.note = "没有可用线路";
            return r;
        }
        // 当前生效音源是「模板型」（设置页导入的 .json 描述）时，把它作为首选线路排在最前；
        // 内置 fish 属于「运行时装接口型」，描述里没有模板，此时保持原有顺序不变。
        LxSource cur = LxSource.active();
        boolean lxFirst = cur != null && cur.isReady() && cur.hasTemplates();
        if (lxFirst) {
            lxStep(r, song, quality);
            if (r.ok()) {
                return r;
            }
        }
        // 当前生效音源是「引擎执行型」（导入的接口型/混淆型 .js）时，同样作为首选线路：把歌交给脚本跑出地址再验真
        boolean engineFirst = cur != null && cur.isReady() && cur.engineReady();
        if (engineFirst) {
            engineStep(r, song, quality);
            if (r.ok()) {
                return r;
            }
        }
        // 默认取流音源线路：内置音源脚本（assets/lx_sources 下的 fish_music 链路，地址见设置页）
        fishStep(r, song, quality);
        if (r.ok()) {
            return r;
        }
        // 该音源线路没取到时，再按平台顺序回退：QQ音乐 → 酷狗音乐 → 酷我音乐 → 网易云音乐
        String[] order = new String[]{Song.SRC_QQ, Song.SRC_KG, Song.SRC_KW, Song.SRC_WY};
        for (int i = 0; i < order.length; i++) {
            List<Cand> cands = platformCandidates(song, quality, order[i]);
            if (cands.isEmpty()) {
                Attempt skip = new Attempt();
                skip.label = platformName(order[i]) + " · 未取到候选地址（已跳到下一家）";
                skip.code = 0;
                skip.note = order[i].equals(song.source) ? "该平台没给出可用地址" : "该平台上没有匹配到这首歌";
                r.attempts.add(skip);
                continue;
            }
            probeAll(r, cands);
            if (r.ok()) {
                return r;
            }
        }
        // 最后：模板型脚本音源线路（已经在最前面跑过的就不再跑一遍）
        if (!lxFirst) {
            lxStep(r, song, quality);
        }
        if (!r.ok()) {
            r.note = "已尝试 " + r.attempts.size() + " 条线路，均未取到可用音频";
        }
        return r;
    }

    /**
     * 交给播放器 / 下载器时优先用「验真时实际打开的那个地址」：
     * 模板型音源（以及部分平台外链）常是 302 跳到另一台机器、还可能跨 http/https，
     * 而 MediaPlayer 与下载器对跨协议跳转的处理并不一致，用最终地址最稳。
     */
    private static String playUrl(String original, String finalUrl) {
        if (finalUrl == null) {
            return original;
        }
        String f = finalUrl.trim();
        if ((f.startsWith("http://") || f.startsWith("https://")) && f.indexOf(' ') < 0) {
            return f;
        }
        return original;
    }

    /** 逐条候选取前 2KB 验真，命中第一条真音频就停下。 */
    private static void probeAll(Result r, List<Cand> cands) {
        if (cands == null) {
            return;
        }
        for (int i = 0; i < cands.size(); i++) {
            Cand c = cands.get(i);
            if (c.url == null || c.url.length() == 0) {
                // 上游没给出地址（例如 QQ 官方对匿名请求返回空 purl）：如实记一条，便于播放页排查
                Attempt empty = new Attempt();
                empty.label = c.label;
                empty.code = 0;
                empty.note = c.note.length() == 0 ? "上游未返回可用地址" : c.note;
                r.attempts.add(empty);
                continue;
            }
            Http.Probe p = c.shortTimeout
                    ? Http.probeAudio(c.url, headersFor(c.url), 4000, 6000)
                    : Http.probeAudio(c.url, headersFor(c.url));
            Attempt a = new Attempt();
            a.label = c.label;
            a.url = playUrl(c.url, p.finalUrl);
            a.code = p.code;
            a.contentType = p.contentType;
            a.audio = p.audio;
            if (p.audio) {
                a.note = "已验真为音频" + (c.note.length() == 0 ? "" : "，" + c.note);
                r.url = playUrl(c.url, p.finalUrl);
                r.label = c.label;
                r.contentType = p.contentType;
                r.note = c.note;
                r.attempts.add(a);
                return;
            }
            a.note = p.error.length() > 0
                    ? p.error
                    : ("非音频响应 " + (p.contentType.length() == 0 ? "无类型" : p.contentType));
            r.attempts.add(a);
        }
    }

    /**
     * 某个平台对这首歌的候选线路。
     * 歌曲本身就是该平台时用自身的 id；否则按「歌名 + 歌手」在该平台找同一首歌，找不到就跳过该平台。
     */
    private static List<Cand> platformCandidates(Song song, int quality, String platform) {
        List<Cand> list = new ArrayList<Cand>();
        String qk = LxSource.qualityKey(quality);
        String name = platformName(platform);
        boolean own = platform.equals(song.source);
        String id = own ? song.id : "";
        String title = song.title;
        String artist = song.artist;
        String tag = "";
        if (!own) {
            Song alt = searchOn(platform, (song.title + " " + song.artist).trim(), song);
            if (alt == null) {
                return list;
            }
            id = alt.id;
            title = alt.displayTitle();
            artist = alt.displayArtist();
            tag = "跨平台匹配「" + title + "」";
        }
        if (id.length() == 0) {
            return list;
        }
        String head = name + (tag.length() == 0 ? "" : " · " + tag);

        if (Song.SRC_QQ.equals(platform)) {
            // QQ 音乐官方 vkey 取流（匿名常返空 purl，见 QqApi 注释）
            list.add(cand(head + " · 官方取流 " + qk, QqApi.songUrl(id, qk),
                    "QQ 官方 vkey 接口"));
        } else if (Song.SRC_KG.equals(platform)) {
            list.add(cand(head + " · 换源聚合 " + qk,
                    FishApi.swapAggregate(platform, id, title, artist, qk), ""));
            list.add(cand(head + " · 官方接口", FishApi.kugouOfficial(id), ""));
        } else if (Song.SRC_KW.equals(platform)) {
            list.add(cand(head + " · 官方取流 " + qk, FishApi.carRelay(id, qk), ""));
            list.add(cand(head + " · 官方取流 128K", KwApi.playUrlMp3(id), ""));
        } else if (Song.SRC_WY.equals(platform)) {
            int[] brs = bitrates(quality);
            for (int i = 0; i < brs.length; i++) {
                String u = WyApi.songUrl(id, brs[i]);
                if (u.length() > 0) {
                    list.add(cand(head + " · 官方接口 " + (brs[i] / 1000) + "K", u, httpsNote(u)));
                }
            }
            String outer = WyApi.outerUrl(id);
            if (outer.length() > 0) {
                list.add(cand(head + " · 外链兜底", outer, httpsNote(outer)));
            }
        }
        return list;
    }

    /** 默认取流音源线路：内置音源脚本（fish_music）的链路，排在所有平台线路之前。
     *  先按设置里的音质档取，取不到或验真不过再降一档试 128k（酷我 car 接口在 320k 档会给
     *  .mgg 加密封装，FishApi 会判不可用），两次尝试都会如实写进播放页线路诊断。 */
    private static void fishStep(Result r, Song song, int quality) {
        if (!FishApi.enabled()) {
            return;
        }
        LxSource lx = LxSource.active();
        String primary = LxSource.qualityKey(quality);
        String[] tokens = "128k".equals(primary) ? new String[]{"128k"} : new String[]{primary, "128k"};
        for (int i = 0; i < tokens.length; i++) {
            String qk = tokens[i];
            FishApi.Resolved fr = FishApi.resolve(song, qk);
            if (!fr.ok()) {
                Attempt empty = new Attempt();
                empty.label = "默认音源 " + lx.describe() + " · " + song.sourceName() + " " + qk;
                empty.code = 0;
                empty.note = i + 1 < tokens.length ? "该音质没取到可用地址，改试 128k" : "没取到可用地址，回退平台线路";
                r.attempts.add(empty);
                continue;
            }
            List<Cand> one = new ArrayList<Cand>();
            one.add(cand("默认音源 " + lx.describe() + " · " + song.sourceName() + " " + qk
                            + "（" + fr.upstream + "）",
                    fr.url, "内置音源线路，" + fr.upstream));
            probeAll(r, one);
            if (r.ok()) {
                return;
            }
        }
    }

    /** 模板型脚本音源的 URL 模板线路（有模板才有候选）。 */
    private static void lxStep(Result r, Song song, int quality) {
        LxSource lx = LxSource.active();
        if (lx == null || !lx.isReady()) {
            return;
        }
        List<Cand> list = new ArrayList<Cand>();
        String key = LxSource.appSourceToKey(song.source);
        String main = LxSource.qualityKey(quality);
        String second = LxSource.qualityKeyFallback(quality);
        if (key != null && song.id.length() > 0) {
            addLxLine(list, lx, key, song.id, main, "");
            if (second != null) {
                addLxLine(list, lx, key, song.id, second, "");
            }
        }
        String query = (song.title + " " + song.artist).trim();
        String[] others = new String[]{"tx", "kg", "kw", "wy"};
        for (int i = 0; i < others.length; i++) {
            String otherKey = others[i];
            if (otherKey.equals(key)) {
                continue;
            }
            Song alt = searchOn(otherKey, query, song);
            if (alt != null) {
                addLxLine(list, lx, otherKey, alt.id, main, "跨平台匹配「" + alt.displayTitle() + "」");
                break;   // 只补一条跨平台线路，避免候选过多
            }
        }
        probeAll(r, list);
    }

/**
     * 引擎执行型脚本音源的线路：把「歌 + 音质」交给脚本（端上 QuickJS 真跑脚本），拿回地址再走 2KB 验真。
     * 脚本给出的通常是第三方中转地址，取不到就自然落到平台线路。
     */
    private static void engineStep(Result r, Song song, int quality) {
        LxSource lx = LxSource.active();
        if (lx == null || !lx.engineReady()) {
            return;
        }
        String script = lx.scriptBody();
        if (script.length() == 0) {
            Attempt a = new Attempt();
            a.label = "脚本音源 " + lx.describe() + " · 引擎执行";
            a.code = 0;
            a.note = "找不到脚本正文（音源文件不完整，可重新导入）";
            r.attempts.add(a);
            return;
        }
        // 会话也要把 lx.currentScriptInfo 备好（脚本取流时可能再读一次）
        String meta = JsEngine.scriptMetaJson(script, lx.scriptFile(), lx.sourceUrl(),
                lx.displayName(), lx.version());
        JsEngine.Session session = JsEngine.sessionFor(scriptKey(lx), script, meta);
        if (session == null) {
            Attempt a = new Attempt();
            a.label = "脚本音源 " + lx.describe() + " · 引擎执行";
            a.code = 0;
            a.note = JsEngine.available() ? "脚本没跑起来（脚本报错或初始化超时）" : "端上脚本引擎不可用";
            r.attempts.add(a);
            return;
        }
        String key = LxSource.appSourceToKey(song.source);
        String main = LxSource.qualityKey(quality);
        String second = LxSource.qualityKeyFallback(quality);
        if (key != null && song.id.length() > 0) {
            addEngineLine(r, session, lx, key, main, song, "");
            if (r.ok()) {
                return;
            }
            if (second != null) {
                addEngineLine(r, session, lx, key, second, song, "该音质没取到，改试 320K");
                if (r.ok()) {
                    return;
                }
            }
        }
        // 跨平台匹配：脚本支持别的平台时，按「歌名 + 歌手」找同一首再跑一次
        String query = (song.title + " " + song.artist).trim();
        String[] others = new String[]{"tx", "kg", "kw", "wy"};
        for (int i = 0; i < others.length; i++) {
            String otherKey = others[i];
            if (otherKey.equals(key)) {
                continue;
            }
            Song alt = searchOn(otherKey, query, song);
            if (alt == null || alt.id.length() == 0) {
                continue;
            }
            addEngineLine(r, session, lx, otherKey, main, alt, "跨平台匹配「" + alt.displayTitle() + "」");
            if (r.ok()) {
                return;
            }
        }
    }

    /** 跑一次脚本取地址并验真；失败则把原因（脚本给的原因）记进诊断。 */
    private static void addEngineLine(Result r, JsEngine.Session session, LxSource lx, String key,
                                      String qualityKey, Song song, String tag) {
        String label = "脚本音源 " + lx.describe() + " · " + (tag.length() == 0 ? "" : tag + " ")
                + enginePlatformName(key) + " " + qualityKey;
        long t0 = System.currentTimeMillis();
        String url = session.fetchUrl(key, qualityKey, song);
        long cost = System.currentTimeMillis() - t0;
        if (url.length() == 0) {
            Attempt a = new Attempt();
            a.label = label;
            a.code = 0;
            a.note = "脚本没给出地址" + (session.lastError().length() > 0
                    ? "：" + firstLine(session.lastError()) : "") + "（" + cost + "ms）";
            r.attempts.add(a);
            return;
        }
        List<Cand> one = new ArrayList<Cand>();
        one.add(cand(label, url, "引擎执行脚本线路（" + cost + "ms）"));
        probeAll(r, one);
    }

    private static String firstLine(String s) {
        if (s == null) {
            return "";
        }
        int i = s.indexOf('\n');
        String one = i >= 0 ? s.substring(0, i) : s;
        return one.length() > 120 ? one.substring(0, 120) + "…" : one;
    }

    private static String scriptKey(LxSource lx) {
        String file = lx.scriptFile();
        return "engine:" + (file.length() == 0 ? lx.describe() : file);
    }

    /** 脚本音源键（tx/kg/kw/wy/mg）的显示名。 */
    private static String enginePlatformName(String key) {
        if ("tx".equals(key)) {
            return "QQ音乐";
        }
        if ("kg".equals(key)) {
            return "酷狗音乐";
        }
        if ("kw".equals(key)) {
            return "酷我音乐";
        }
        if ("wy".equals(key)) {
            return "网易云音乐";
        }
        if ("mg".equals(key)) {
            return "咪咕音乐";
        }
        return key;
    }

    private static void addLxLine(List<Cand> list, LxSource lx, String key, String id, String qualityKey,
                                   String tag) {
        if (!lx.supports(key, qualityKey)) {
            return;
        }
        String url = lx.buildUrl(key, id, qualityKey);
        if (url.length() == 0) {
            return;
        }
        LxSource.Entry entry = lx.entry(key);
        String name = entry == null ? key : entry.name;
        list.add(new Cand());
        Cand c = list.get(list.size() - 1);
        c.label = lx.describe() + " · " + (tag.length() == 0 ? "" : tag + " ") + name + " " + qualityKey;
        c.url = url;
        c.note = "脚本音源线路（id 取自 " + lx.idField(key) + "，level=" + lx.levelToken(key, qualityKey) + "）";
    }

    /**
     * 在指定平台按歌名+歌手找同一首歌。
     * 平台既接受应用内代号（qq/kg/kw/wy），也接受脚本音源键（tx 等于 QQ音乐）。
     */
    private static Song searchOn(String platform, String query, Song target) {
        List<Song> found;
        if (Song.SRC_WY.equals(platform)) {
            found = WyApi.search(query, 6);
        } else if (Song.SRC_KW.equals(platform)) {
            found = KwApi.search(query, 6);
        } else if (Song.SRC_KG.equals(platform)) {
            found = KgApi.search(query, 6);
        } else if (Song.SRC_QQ.equals(platform) || "tx".equals(platform)) {
            found = QqApi.search(query, 6);
        } else {
            return null;
        }
        return bestMatch(found, target);
    }

    private static String platformName(String platform) {
        if (Song.SRC_QQ.equals(platform)) {
            return "QQ音乐";
        }
        if (Song.SRC_KG.equals(platform)) {
            return "酷狗音乐";
        }
        if (Song.SRC_KW.equals(platform)) {
            return "酷我音乐";
        }
        if (Song.SRC_WY.equals(platform)) {
            return "网易云音乐";
        }
        return platform;
    }

    /** 音质档 -> 网易云官方接口的 br。 */
    private static int[] bitrates(int quality) {
        if (quality == QUALITY_128) {
            return new int[]{128000};
        }
        if (quality == QUALITY_FLAC) {
            return new int[]{999000, 320000, 128000};
        }
        return new int[]{320000, 128000};
    }

    private static Cand cand(String label, String url, String note) {
        Cand c = new Cand();
        c.label = label;
        c.url = url == null ? "" : url;
        c.note = note;
        return c;
    }

    private static String httpsNote(String url) {
        return url != null && url.startsWith("https://") ? "HTTPS 线路，老设备建议下载后播放" : "";
    }

    private static Map<String, String> headersFor(String url) {
        if (url != null && url.indexOf("music.163.com") >= 0) {
            return WyApi.headers();
        }
        if (url != null && url.indexOf("qqmusic") >= 0) {
            return QqApi.headers();
        }
        return Http.headers();
    }

    /**
     * 跨平台结果打分：歌名完全一致最优，其次包含关系；歌手对得上加分。
     * 综合分为 0 时说明搜索结果与目标歌曲无关，宁可不给线路也不放错歌。
     * 同分时优先时长更长的候选：酷我搜索会把十几秒的「片段」排得很前，
     * 同分随机取会让跨平台兜底挑到片段，这里用时长把完整歌曲顶上来。
     */
    private static Song bestMatch(List<Song> list, Song target) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        String targetTitle = Song.norm(target.title);
        String targetArtist = Song.norm(target.artist);
        Song best = null;
        int bestScore = 0;
        for (int i = 0; i < list.size(); i++) {
            Song s = list.get(i);
            String title = Song.norm(s.title);
            String artist = Song.norm(s.artist);
            int score = 0;
            if (title.length() > 0 && title.equals(targetTitle)) {
                score += 6;
            } else if (targetTitle.length() > 0
                    && (title.indexOf(targetTitle) >= 0 || targetTitle.indexOf(title) >= 0)) {
                score += 3;
            } else {
                continue;
            }
            if (targetArtist.length() > 0
                    && (artist.indexOf(targetArtist) >= 0 || targetArtist.indexOf(artist) >= 0)) {
                score += 3;
            }
            boolean better = best == null || score > bestScore
                    || (score == bestScore && s.duration > best.duration);
            if (better) {
                best = s;
                bestScore = score;
            }
        }
        return best;
    }
}