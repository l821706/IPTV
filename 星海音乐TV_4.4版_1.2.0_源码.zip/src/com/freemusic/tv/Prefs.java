package com.freemusic.tv;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

/** 轻量偏好存储：音质、取流方式、音源筛选、收藏。 */
public final class Prefs {

    private static final String FILE = "freemusic_tv";
    private static final String K_QUALITY = "quality";
    private static final String K_DOWNLOAD_FIRST = "download_first";
    private static final String K_SOURCE_FILTER = "source_filter";
    private static final String K_FAVS = "favs";
    private static final String K_LAST_QUERY = "last_query";
    private static final String K_PLAY_MODE = "play_mode";
    private static final String K_LYRIC_LEAD = "lyric_lead";
    /** 1.1.7 起歌词提前量默认档改为「不提前」，这里记旧默认值的一次性迁移是否已做。 */
    private static final String K_LYRIC_LEAD_MIGRATED = "lyric_lead_default_0";
    private static final String K_ACTIVE_SOURCE = "active_source";

    public static final String FILTER_ALL = "all";

    /** 播放模式：顺序播放（播完列表末尾即停）。 */
    public static final int MODE_SEQUENCE = 0;
    /** 播放模式：列表循环（播完列表末尾回到第一首）。 */
    public static final int MODE_LOOP_LIST = 1;
    /** 播放模式：单曲循环（播完重放本曲）。 */
    public static final int MODE_LOOP_ONE = 2;
    /** 播放模式：随机播放（播完随机选一首）。 */
    public static final int MODE_SHUFFLE = 3;

    private final SharedPreferences sp;

    public Prefs(Context ctx) {
        this.sp = ctx.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public int quality() {
        int q = sp.getInt(K_QUALITY, PlayResolver.QUALITY_320);
        // 旧版本遗留的「自动」档（0）等非法值统一按超品 320K 处理，避免切换时顺序看起来跳档
        if (q != PlayResolver.QUALITY_128 && q != PlayResolver.QUALITY_320
                && q != PlayResolver.QUALITY_FLAC) {
            q = PlayResolver.QUALITY_320;
        }
        return q;
    }

    public void setQuality(int q) {
        sp.edit().putInt(K_QUALITY, q).commit();
    }

    /** 音质档：高品 128K / 超品 320K / 无损 FLAC。 */
    public String qualityLabel() {
        int q = quality();
        if (q == PlayResolver.QUALITY_128) {
            return "高品 128K";
        }
        if (q == PlayResolver.QUALITY_FLAC) {
            return "无损 FLAC";
        }
        return "超品 320K";
    }

    public boolean downloadFirst() {
        return sp.getBoolean(K_DOWNLOAD_FIRST, false);
    }

    public void setDownloadFirst(boolean v) {
        sp.edit().putBoolean(K_DOWNLOAD_FIRST, v).commit();
    }

    public String downloadFirstLabel() {
        return downloadFirst() ? "先下载再播（更稳）" : "直接流式播放";
    }

    public String sourceFilter() {
        return sp.getString(K_SOURCE_FILTER, FILTER_ALL);
    }

    public void setSourceFilter(String v) {
        sp.edit().putString(K_SOURCE_FILTER, v).commit();
    }

    public String lastQuery() {
        return sp.getString(K_LAST_QUERY, "");
    }

    public void setLastQuery(String q) {
        sp.edit().putString(K_LAST_QUERY, q == null ? "" : q).commit();
    }

    /**
     * 歌词提前量档位（毫秒）：先「延后」三档，再「不提前」与逐档加大的提前量。
     * 低档 0.25 秒步进方便微调，高档拉到 8 秒，覆盖真机上「人声领先一行半」这类较大整体偏移。
     */
    private static final int[] LYRIC_LEADS = {
            -2000, -1000, -500, 0, 250, 500, 750, 1000, 1250, 1500,
            2000, 2500, 3000, 4000, 5000, 6000, 8000};
    /** 默认「不提前」：1.1.6 及更早默认提前 0.5 秒，1.1.7 起初始档改为不提前，按真机听感逐档上调。 */
    private static final int LYRIC_LEAD_DEFAULT = 0;
    /** 1.1.6 及更早版本的默认档（提前 0.5 秒）：升级时若落盘值仍是它，说明用户没调过，跟随新默认改为 0。 */
    private static final int LYRIC_LEAD_OLD_DEFAULT = 500;

    /**
     * 歌词提前量（毫秒）：高亮判定用 positionMs + 该值，值越大歌词越早换行。
     * 默认 0（不提前）；真机上如果发现歌词比人声慢（唱到下一句了高亮还没跟上），在设置页把这一档调大即可。
     */
    public int lyricLeadMs() {
        migrateLyricLeadFromOldDefault();
        int v = sp.getInt(K_LYRIC_LEAD, LYRIC_LEAD_DEFAULT);
        for (int i = 0; i < LYRIC_LEADS.length; i++) {
            if (LYRIC_LEADS[i] == v) {
                return v;
            }
        }
        return LYRIC_LEAD_DEFAULT;
    }

    /**
     * 旧默认档（提前 0.5 秒）一次性迁移到新默认「不提前」：只动「仍是旧默认值」这一种情况，
     * 用户自己调过的其它档位（延后档、0.25/0.75 秒、1 秒以上等）保持不动。迁移只做一次。
     */
    private void migrateLyricLeadFromOldDefault() {
        if (sp.getBoolean(K_LYRIC_LEAD_MIGRATED, false)) {
            return;
        }
        int stored = sp.getInt(K_LYRIC_LEAD, LYRIC_LEAD_DEFAULT);
        android.content.SharedPreferences.Editor ed = sp.edit().putBoolean(K_LYRIC_LEAD_MIGRATED, true);
        if (stored == LYRIC_LEAD_OLD_DEFAULT) {
            ed.putInt(K_LYRIC_LEAD, LYRIC_LEAD_DEFAULT);
        }
        ed.commit();
    }

    public void setLyricLeadMs(int ms) {
        sp.edit().putInt(K_LYRIC_LEAD, ms).commit();
    }

    /** 按档位循环切到下一档，返回切换后的毫秒值。 */
    public int cycleLyricLead() {
        int cur = lyricLeadMs();
        int idx = 0;
        for (int i = 0; i < LYRIC_LEADS.length; i++) {
            if (LYRIC_LEADS[i] == cur) {
                idx = i;
            }
        }
        int next = LYRIC_LEADS[(idx + 1) % LYRIC_LEADS.length];
        setLyricLeadMs(next);
        return next;
    }

    /** 歌词提前量文案：不提前 / 提前 0.25 秒 …… 提前 8 秒 / 延后 0.5 秒 …… */
    public String lyricLeadLabel() {
        int ms = lyricLeadMs();
        if (ms == 0) {
            return "不提前";
        }
        return (ms > 0 ? "提前 " : "延后 ") + seconds(ms) + " 秒";
    }

    /** 毫秒转「秒」文案：区分 .25 / .5 / .75，避免 250ms 显示成 0.2 秒。 */
    private static String seconds(int ms) {
        int absMs = ms < 0 ? -ms : ms;
        int whole = absMs / 1000;
        int frac = absMs % 1000;
        if (frac == 0) {
            return String.valueOf(whole);
        }
        if (frac == 250) {
            return whole + ".25";
        }
        if (frac == 500) {
            return whole + ".5";
        }
        if (frac == 750) {
            return whole + ".75";
        }
        return whole + "." + frac;
    }

    /** 当前生效的音源 id：内置为 "builtin"，导入的音源用文件名（去扩展名）。 */
    public String activeSource() {
        String v = sp.getString(K_ACTIVE_SOURCE, SourceStore.ID_BUILTIN);
        return v == null || v.length() == 0 ? SourceStore.ID_BUILTIN : v;
    }

    public void setActiveSource(String id) {
        sp.edit().putString(K_ACTIVE_SOURCE, id == null ? SourceStore.ID_BUILTIN : id).commit();
    }

    /** 当前播放模式，非法值统一按列表循环处理。 */
    public int playMode() {
        int m = sp.getInt(K_PLAY_MODE, MODE_LOOP_LIST);
        if (m != MODE_SEQUENCE && m != MODE_LOOP_LIST && m != MODE_LOOP_ONE && m != MODE_SHUFFLE) {
            m = MODE_LOOP_LIST;
        }
        return m;
    }

    public void setPlayMode(int mode) {
        sp.edit().putInt(K_PLAY_MODE, mode).commit();
    }

    /** 播放模式文案：顺序播放 / 列表循环 / 单曲循环 / 随机播放。 */
    public String playModeLabel() {
        int m = playMode();
        if (m == MODE_SEQUENCE) {
            return "顺序播放";
        }
        if (m == MODE_LOOP_ONE) {
            return "单曲循环";
        }
        if (m == MODE_SHUFFLE) {
            return "随机播放";
        }
        return "列表循环";
    }

    /** 按 顺序 → 列表循环 → 单曲循环 → 随机 的顺序切到下一档，返回切换后的模式。 */
    public int cyclePlayMode() {
        int m = playMode();
        if (m == MODE_SEQUENCE) {
            m = MODE_LOOP_LIST;
        } else if (m == MODE_LOOP_LIST) {
            m = MODE_LOOP_ONE;
        } else if (m == MODE_LOOP_ONE) {
            m = MODE_SHUFFLE;
        } else {
            m = MODE_SEQUENCE;
        }
        setPlayMode(m);
        return m;
    }

    public List<Song> favorites() {
        List<Song> out = new ArrayList<Song>();
        String raw = sp.getString(K_FAVS, "");
        if (raw == null || raw.length() == 0) {
            return out;
        }
        String[] rows = raw.split("\n");
        for (int i = 0; i < rows.length; i++) {
            Song s = Song.decode(rows[i]);
            if (s != null && s.title.length() > 0) {
                out.add(s);
            }
        }
        return out;
    }

    public void setFavorites(List<Song> songs) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < songs.size(); i++) {
            if (sb.length() > 0) {
                sb.append('\n');
            }
            sb.append(songs.get(i).encode());
        }
        sp.edit().putString(K_FAVS, sb.toString()).commit();
    }

    public boolean isFavorite(Song song) {
        List<Song> favs = favorites();
        for (int i = 0; i < favs.size(); i++) {
            if (favs.get(i).sameSong(song)) {
                return true;
            }
        }
        return false;
    }

    /** 收藏/取消收藏，返回操作后是否处于收藏状态。 */
    public boolean toggleFavorite(Song song) {
        List<Song> favs = favorites();
        for (int i = 0; i < favs.size(); i++) {
            if (favs.get(i).sameSong(song)) {
                favs.remove(i);
                setFavorites(favs);
                return false;
            }
        }
        favs.add(song);
        setFavorites(favs);
        return true;
    }
}