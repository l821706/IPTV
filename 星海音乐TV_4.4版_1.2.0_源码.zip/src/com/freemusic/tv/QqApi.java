package com.freemusic.tv;

import java.util.ArrayList;
import java.util.List;

/**
 * QQ 音乐官方接口（搜索 / 取流 / 歌词）。
 *
 *   搜索  https://c.y.qq.com/soso/fcgi-bin/client_search_cp?w=&format=json&n=&p=1&cr=1
 *         → data.song.list[]（songmid / songname / singer[].name / albumname / albummid / interval）
 *   取流  https://u.y.qq.com/cgi-bin/musicu.fcg（module=vkey.GetVkeyServer, method=CgiGetVkey）
 *         → req_0.data.sip[0] + req_0.data.midurlinfo[0].purl
 *   歌词  https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg?songmid=&format=json&nobase64=1
 *         → lyric（明文 LRC，\\n 已转义）
 *
 * 取流的实测情况（2026-11-05）：官方 vkey 接口对匿名请求一律返回空 purl
 * （多种 module / platform / filename 组合都一样，直连 CDN 也是 403），
 * 也就是说匿名拿不到 QQ 的试听地址；本类照官方参数发起请求，拿到空 purl 就返回空串，
 * 由调用方按既定的音源顺序继续找其它平台，绝不伪造地址。
 */
public final class QqApi {

    private static final String SEARCH = "https://c.y.qq.com/soso/fcgi-bin/client_search_cp";
    private static final String VKEY = "https://u.y.qq.com/cgi-bin/musicu.fcg";
    private static final String LYRIC = "https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg";

    private QqApi() {
    }

    static java.util.Map<String, String> headers() {
        return Http.headers("Referer", "https://y.qq.com/",
                "Origin", "https://y.qq.com");
    }

    // ------------------------------------------------------------------ 搜索

    public static List<Song> search(String keyword, int limit) {
        List<Song> out = new ArrayList<Song>();
        if (keyword == null || keyword.trim().length() == 0) {
            return out;
        }
        String url = SEARCH + "?w=" + Http.encode(keyword)
                + "&format=json&n=" + limit + "&p=1&cr=1&new_json=0&aggr=1&platform=20";
        Http.Res res = Http.get(url, headers());
        if (!res.ok()) {
            return out;
        }
        Object root = Json.parse(res.body);
        List<Object> list = Json.listAt(root, "data", "song", "list");
        for (int i = 0; i < list.size() && out.size() < limit; i++) {
            Object node = list.get(i);
            String mid = Json.strAt(node, "songmid");
            if (mid.length() == 0) {
                mid = Json.strAt(node, "mid");
            }
            if (mid.length() == 0) {
                continue;
            }
            String title = Json.html(Json.strAt(node, "songname"));
            if (title.length() == 0) {
                title = Json.html(Json.strAt(node, "name"));
            }
            StringBuilder artist = new StringBuilder();
            List<Object> singers = Json.listAt(node, "singer");
            for (int k = 0; k < singers.size(); k++) {
                if (artist.length() > 0) {
                    artist.append('/');
                }
                artist.append(Json.html(Json.strAt(singers.get(k), "name")));
            }
            String album = Json.html(Json.strAt(node, "albumname"));
            String albumMid = Json.strAt(node, "albummid");
            long interval = Json.lonAt(node, "interval");
            String cover = albumMid.length() > 0
                    ? "https://y.gtimg.cn/music/photo_new/T002R300x300M000" + albumMid + ".jpg" : "";
            out.add(new Song(title, artist.toString(), album, Song.SRC_QQ, mid, albumMid, cover,
                    (int) (interval * 1000)));
        }
        return out;
    }

    // ------------------------------------------------------------------ 取流

    /** 官方 vkey 取流；匿名拿不到试听地址时返回空串（详见类注释）。 */
    public static String songUrl(String mid, String qualityKey) {
        if (mid == null || mid.length() == 0) {
            return "";
        }
        String filename;
        if ("128k".equals(qualityKey)) {
            filename = "M500" + mid + ".mp3";
        } else if ("flac".equals(qualityKey) || "flac24bit".equals(qualityKey)) {
            filename = "F000" + mid + ".flac";
        } else {
            filename = "M800" + mid + ".mp3";
        }
        String body = "{\"req_0\":{\"module\":\"vkey.GetVkeyServer\",\"method\":\"CgiGetVkey\",\"param\":"
                + "{\"guid\":\"10000\",\"songmid\":[\"" + mid + "\"],\"filename\":[\"" + filename + "\"],"
                + "\"songtype\":[0],\"uin\":\"0\",\"loginflag\":1,\"platform\":\"20\"}},"
                + "\"comm\":{\"uin\":0,\"format\":\"json\",\"ct\":24,\"cv\":0}}";
        Http.Res res = Http.get(VKEY + "?format=json&data=" + Http.encode(body), headers());
        if (!res.ok()) {
            return "";
        }
        Object root = Json.parse(res.body);
        String purl = Json.strAt(root, "req_0", "data", "midurlinfo", "0", "purl");
        if (purllEmpty(purl)) {
            purl = Json.strAt(root, "req_0", "data", "midurlinfo", "purl");
        }
        if (purllEmpty(purl)) {
            return "";
        }
        String sip = Json.strAt(root, "req_0", "data", "sip", "0");
        if (sip.length() == 0) {
            sip = "https://isure.stream.qqmusic.qq.com/";
        }
        return sip + purl;
    }

    private static boolean purllEmpty(String purl) {
        return purl == null || purl.length() == 0 || "null".equals(purl);
    }

    // ------------------------------------------------------------------ 歌词

    /** 官方歌词接口，返回明文 LRC；取不到返回空串。 */
    public static String lyric(String mid) {
        if (mid == null || mid.length() == 0) {
            return "";
        }
        String url = LYRIC + "?songmid=" + Http.encode(mid) + "&format=json&nobase64=1&platform=20";
        Http.Res res = Http.get(url, headers());
        if (!res.ok()) {
            return "";
        }
        Object root = Json.parse(res.body);
        String lyric = Json.strAt(root, "lyric");
        if (lyric.length() == 0) {
            return "";
        }
        return lyric.replace("\\n", "\n").replace("\\r", "").replace("&nbsp;", " ");
    }
}