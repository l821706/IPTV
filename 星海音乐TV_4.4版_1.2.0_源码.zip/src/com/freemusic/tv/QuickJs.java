package com.freemusic.tv;

/**
 * QuickJS 引擎的 Java 入口。
 *
 * native 实现在 {@code native/qjs_jni.c}，库名 {@code libqjs.so}（随包放在 lib/<abi>/ 下，
 * x86 / armeabi-v7a / arm64-v8a）。库加载失败时 {@link #available()} 为 false，应用照常运行，
 * 只是没有「引擎执行型」音源能力（导入这类脚本时会明确提示引擎不可用）。
 *
 * 线程约定：Runtime/Context 不是线程安全的，只能在同一条线程上串行使用 —— 见 {@link JsEngine}。
 */
public final class QuickJs {

    private static volatile boolean loaded;

    static {
        try {
            System.loadLibrary("qjs");
            loaded = true;
        } catch (Throwable t) {
            loaded = false;
            try {
                android.util.Log.e("StarMusicTV", "JS 引擎库加载失败：" + t);
            } catch (Throwable ignore) {
                // JVM 侧跑校验时 android.util.Log 是桩实现，忽略
            }
        }
    }

    private QuickJs() {
    }

    public static boolean available() {
        return loaded;
    }

    /** 脚本内存上限 64MB（4.4 电视盒子内存小，别让脚本把机器吃光）。 */
    public static final long MEM_LIMIT = 64L * 1024L * 1024L;
    /** 脚本可用栈上限 2MB。 */
    public static final long STACK_LIMIT = 2L * 1024L * 1024L;

    public static native long nNew(long memLimit, long stackLimit, Class<?> hostCls);

    public static native String nEval(long handle, String code, String fname, long timeoutMs);

    public static native String nCall(long handle, String func, String arg, long timeoutMs);

    /** 等某个返回布尔的 JS 函数变成真值（期间泵定时器与微任务）；超时/无进展返回 ok:false。 */
    public static native String nWait(long handle, String condFunc, long timeoutMs);

    public static native void nFree(long handle);
}