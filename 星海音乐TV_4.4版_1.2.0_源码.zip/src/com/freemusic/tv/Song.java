package com.freemusic.tv;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

/** 歌曲模型。同一首歌可能来自不同平台，用 source+id 作为唯一键。 */
public class Song {

    public static final String SRC_WY = "wy";
    public static final String SRC_KW = "kw";
    public static final String SRC_KG = "kg";
    public static final String SRC_QQ = "qq";

    public String title = "";
    public String artist = "";
    public String album = "";
    public String source = "";
    public String id = "";
    public String extra = "";
    public String cover = "";
    public int duration = 0;

    public Song() {
    }

    public Song(String title, String artist, String album, String source, String id, String extra,
                String cover, int duration) {
        this.title = safe(title);
        this.artist = safe(artist);
        this.album = safe(album);
        this.source = safe(source);
        this.id = safe(id);
        this.extra = safe(extra);
        this.cover = safe(cover);
        this.duration = duration;
    }

    public String key() {
        return source + ":" + id;
    }

    public String sourceName() {
        if (SRC_WY.equals(source)) {
            return "网易云";
        }
        if (SRC_KW.equals(source)) {
            return "酷我";
        }
        if (SRC_KG.equals(source)) {
            return "酷狗";
        }
        if (SRC_QQ.equals(source)) {
            return "QQ音乐";
        }
        return "未知";
    }

    public String displayTitle() {
        return title.length() == 0 ? "未知歌曲" : title;
    }

    public String displayArtist() {
        return artist.length() == 0 ? "未知歌手" : artist;
    }

    public boolean sameSong(Song other) {
        if (other == null) {
            return false;
        }
        return key().equals(other.key());
    }

    public boolean sameTitleArtist(Song other) {
        if (other == null) {
            return false;
        }
        return norm(title).equals(norm(other.title))
                && (norm(artist).indexOf(norm(other.artist)) >= 0
                || norm(other.artist).indexOf(norm(artist)) >= 0);
    }

    /** 去掉大小写、空格与标点后的可比字符串，供歌名/歌手匹配使用。 */
    public static String norm(String s) {
        return normalize(s);
    }

    private static String normalize(String s) {
        if (s == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        String lower = s.toLowerCase();
        for (int i = 0; i < lower.length(); i++) {
            char c = lower.charAt(i);
            if (Character.isLetterOrDigit(c) || c > 0x2E80) {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /** 收藏持久化：字段用 | 分隔，值做 URL 编码。 */
    public String encode() {
        StringBuilder sb = new StringBuilder();
        sb.append(enc(title)).append('|');
        sb.append(enc(artist)).append('|');
        sb.append(enc(album)).append('|');
        sb.append(enc(source)).append('|');
        sb.append(enc(id)).append('|');
        sb.append(enc(extra)).append('|');
        sb.append(enc(cover)).append('|');
        sb.append(duration);
        return sb.toString();
    }

    public static Song decode(String line) {
        if (line == null || line.length() == 0) {
            return null;
        }
        String[] p = line.split("\\|", -1);
        if (p.length < 8) {
            return null;
        }
        Song s = new Song();
        s.title = dec(p[0]);
        s.artist = dec(p[1]);
        s.album = dec(p[2]);
        s.source = dec(p[3]);
        s.id = dec(p[4]);
        s.extra = dec(p[5]);
        s.cover = dec(p[6]);
        try {
            s.duration = Integer.parseInt(p[7].trim());
        } catch (RuntimeException e) {
            s.duration = 0;
        }
        return s;
    }

    private static String enc(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return s.replace('|', ' ');
        }
    }

    private static String dec(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        try {
            return URLDecoder.decode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    private static String safe(String s) {
        return s == null ? "" : s.trim();
    }

    @Override
    public String toString() {
        return displayTitle() + " - " + displayArtist() + " [" + sourceName() + "]";
    }
}