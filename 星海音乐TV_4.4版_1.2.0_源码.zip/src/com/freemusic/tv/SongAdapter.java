package com.freemusic.tv;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * 歌曲列表适配器。
 * 注意：列表项自身是 focusable 的，遥控器的确认键（OK / DPAD_CENTER）会先落到列表项上，
 * 项上没挂点击处理时这个键会被「按下去又什么都不做」地吞掉，ListView 的 onItemClick 也不会触发。
 * 所以这里必须给每一项都挂上 OnClickListener，再由它回接到列表原本的条目点击逻辑。
 */
public class SongAdapter extends BaseAdapter {

    public interface OnClick {
        void onClick(int position, Song song);
    }

    public interface OnLongClick {
        void onLongClick(int position, Song song);
    }

    private final Context ctx;
    private final List<Song> data = new ArrayList<Song>();
    private OnClick click;
    private OnLongClick longClick;

    public SongAdapter(Context ctx) {
        this.ctx = ctx;
    }

    public void setClickListener(OnClick l) {
        this.click = l;
    }

    public void setLongClickListener(OnLongClick l) {
        this.longClick = l;
    }

    public void setData(List<Song> songs) {
        data.clear();
        if (songs != null) {
            data.addAll(songs);
        }
        notifyDataSetChanged();
    }

    public List<Song> data() {
        return data;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            v = LayoutInflater.from(ctx).inflate(R.layout.item_song, parent, false);
        }
        Song song = data.get(position);
        TextView index = (TextView) v.findViewById(R.id.itmIndex);
        TextView title = (TextView) v.findViewById(R.id.itmTitle);
        TextView artist = (TextView) v.findViewById(R.id.itmArtist);
        TextView source = (TextView) v.findViewById(R.id.itmSource);
        TextView duration = (TextView) v.findViewById(R.id.itmDuration);

        index.setText(String.valueOf(position + 1));
        title.setText(song.displayTitle());
        artist.setText(song.displayArtist() + (song.album.length() == 0 ? "" : " · " + song.album));
        source.setText(song.sourceName());
        source.setBackgroundResource(R.drawable.badge_bg);
        duration.setText(song.duration > 0 ? Ui.time(song.duration) : "--:--");

        v.setClickable(true);
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (click != null) {
                    click.onClick(position, data.get(position));
                }
            }
        });
        if (longClick == null) {
            v.setLongClickable(false);
            v.setOnLongClickListener(null);
        } else {
            v.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    longClick.onLongClick(position, data.get(position));
                    return true;
                }
            });
        }
        return v;
    }
}