package com.freemusic.tv;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 音源仓库：把「内置音源描述」与「端上导入的音源」统一成同一套描述结构（{@link LxSource} 的 schema）。
 *
 * 端上不执行任何 JS（见 README 的硬约束），所以：
 *   * <b>.json 音源描述</b>：直接按 schema 生效，这是推荐形式，字段说明见
 *     {@code docs/音源描述文件格式.md}；
 *   * <b>.js 脚本</b>：只做「尽力提取」——读 {@code @name/@version} 等元信息，并把脚本里写出来的取流地址
 *     归一成模板：字面的「音质键 → http 地址」表，或 {@code kg:{musicUrl(...)} } 里拼出来的
 *     {@code 'http://host/xx.php?type=mp3&id=' + hash} / ES 模板串 {@code `...id=${n}&level=${e}`} /
 *     已经写成 {@code {id}·{level}} 的模板（见 {@link #normalizeTemplate}）。提取不到任何模板就不接收
 *     （不留不可用的空条目）。
 * 所有模板线路在真正取流前都会先做 2KB 验真，所以提取不准也不会播出错误音频，只会自然回退到平台线路。
 *
 * 本类不依赖 android.*，可直接在 JVM 上验证。
 */
public final class SourceStore {

    /** 内置音源的固定 id。 */
    public static final String ID_BUILTIN = "builtin";
    /** 应用内导入音源的存放目录（放在 getFilesDir() 下）。 */
    public static final String DIR = "lx_sources";

    /** 一个可用的音源。 */
    public static final class Item {
        public String id = "";
        /** 规范化后的描述 JSON（落盘的就是它）。 */
        public String json = "";
        /** 磁盘路径，内置音源为空串。 */
        public String path = "";
        public boolean builtin;
        public LxSource parsed;
        /** 有非空取流模板、或是引擎执行型脚本（runner=quickjs 且列出了平台）才可用。 */
        public boolean usable;
        /** 引擎执行型：取流时要由端上 JS 引擎运行脚本（描述里 runner=quickjs）。 */
        public boolean engine;

        /** 界面显示名，如「fish_music v1.9.0」「测试音源 v1.0」。 */
        public String title() {
            if (parsed == null) {
                return id;
            }
            String d = parsed.describe();
            return d == null || d.length() == 0 ? id : d;
        }

        /** 脚本/描述里声明的文件名，便于界面显示来源。 */
        public String fileName() {
            return parsed == null ? "" : parsed.scriptFile();
        }

        /** 支持的平台（脚本键），用于提示文案。 */
        public String platforms() {
            if (parsed == null) {
                return "";
            }
            List<String> keys = parsed.keys();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < keys.size(); i++) {
                if (i > 0) {
                    sb.append('/');
                }
                sb.append(keys.get(i));
            }
            return sb.toString();
        }
    }

    private static final Pattern P_NAME = Pattern.compile("@name\\s+([^\\s*]+)");
    private static final Pattern P_VERSION = Pattern.compile("@version\\s+([^\\s*]+)");
    /** 脚本里字面出现的「音质键 → http 地址」表（地址里可能带 \/ 转义，取值后统一反转义）。 */
    private static final Pattern P_QUALITY_URL = Pattern.compile(
            "[\"']?(128k|320k|flac24bit|flac)[\"']?\\s*[:=]\\s*[\"'](https?:[^\"']*)[\"']");
    /** 脚本里出现的 http(s) 字面地址，作为「平台 → 取流模板」的候选。 */
    private static final Pattern P_ANY_URL = Pattern.compile("(https?://[^\\s\"'`<>\\\\]+)");
    private static final String[] PLATFORM_KEYS = {"tx", "kg", "kw", "wy", "mg"};
    /** 应用要用的三个音质档（顺序与 LEVEL_FOR_QUALITY 对齐）。 */
    private static final String[] QUALITY_KEYS = {"128k", "320k", "flac"};
    /** 模板里带 {level} 占位时，各音质档对应的上游 level 取值（与内置 fish 链路同一套取值）。 */
    private static final String[] LEVEL_FOR_QUALITY = {"standard", "exhigh", "lossless"};
    /** 明显不是取流地址的路径关键词：返回 JSON/网页的接口、歌词、封面、配置、搜索等。 */
    private static final String[] NON_STREAM_HINTS = {
            ".json", ".js", ".css", ".png", ".jpg", ".jpeg", ".gif", ".html", ".htm",
            "type=json", "format=json", "lrc", "lyric", "songinfo", "cover", "search", "keyword",
            "init", "config", "update", "login", "cookie", "sheet"};

    private SourceStore() {
    }

    /** 由描述 JSON 构造条目；描述不成立（没有平台条目）时返回 null。 */
    public static Item fromJson(String id, String jsonText, String path, boolean builtin) {
        if (jsonText == null || jsonText.trim().length() == 0) {
            return null;
        }
        LxSource lx = LxSource.parse(jsonText);
        if (!lx.isReady()) {
            return null;
        }
        Item it = new Item();
        it.id = id;
        it.json = jsonText;
        it.path = path == null ? "" : path;
        it.builtin = builtin;
        it.parsed = lx;
        it.engine = lx.engineReady();
        it.usable = lx.hasTemplates() || it.engine;
        return it;
    }

    /** 导入识别的结果：成功给规范化描述 JSON，失败给可读的原因。 */
    public static final class Outcome {
        public String json = "";
        public String reason = "";

        public boolean ok() {
            return json.length() > 0;
        }
    }

    /**
     * 把导入内容规范化成可用的描述 JSON：JSON 直接校验；脚本走尽力提取。拿不到可用描述时返回空串。
     */
    public static String normalize(String raw, String hintName) {
        return normalizeFor(raw, hintName).json;
    }

    /**
     * 与 {@link #normalize} 同一套判定，但把失败原因一并带出来，便于界面给出可行动的提示。
     * 原因分三类：描述 JSON 解析不了；描述缺 urlTemplates；.js 属运行时装接口型（端上不执行 JS，提取不到模板）。
     */
    public static Outcome normalizeFor(String raw, String hintName) {
        return normalizeFor(raw, hintName, null);
    }

    /**
     * 带「引擎试跑」钩子的版本：静态提取不到模板时，用 probe 把脚本交给端上 JS 引擎跑一次，
     * 跑得通就按「引擎执行型」收下（描述里写 runner=quickjs），跑不通才给出失败原因。
     */
    public static Outcome normalizeFor(String raw, String hintName, EngineProbe probe) {
        Outcome out = new Outcome();
        if (raw == null || raw.trim().length() == 0) {
            out.reason = "内容为空";
            return out;
        }
        String text = raw.trim();
        if (text.charAt(0) == '{') {
            Item jsonItem = fromJson("probe", text, "", false);
            if (jsonItem == null) {
                out.reason = "不是有效的音源描述 JSON（结构见 docs/音源描述文件格式.md）";
            } else if (!jsonItem.usable) {
                out.reason = "描述里没有可用的取流模板（urlTemplates 缺失或全为空）";
            } else {
                out.json = text;
            }
            return out;
        }
        String json = extractFromScript(text, hintName);
        if (json.length() > 0) {
            out.json = json;
            return out;
        }
        // 静态提取不到模板：交给端上 JS 引擎试跑一次（能跑就按「引擎执行型」收下）
        if (probe != null) {
            EngineProbe.Result r = null;
            try {
                r = probe.probe(text, hintName);
            } catch (Throwable t) {
                r = null;
                out.reason = "端上 JS 引擎试跑脚本出错：" + t;
            }
            if (r != null && r.ok && r.platforms.size() > 0) {
                String engineJson = engineDescription(hintName, r);
                if (engineJson.length() > 0) {
                    out.json = engineJson;
                    return out;
                }
            }
            if (out.reason.length() == 0) {
                out.reason = "端上 JS 引擎跑不通这个脚本："
                        + (r == null ? "引擎不可用" : (r.error.length() == 0 ? "脚本未声明可用平台" : r.error));
            }
            return out;
        }
        out.reason = "该 .js 脚本属「运行时装接口型」：端上不执行 JS，"
                + "脚本是按逻辑联网请求接口再算地址的，提取不到可直接取流的地址模板";
        return out;
    }

    /** 引擎试跑：把脚本交给端上 JS 引擎跑一次，回传元信息与它声明的平台。JVM 侧可传 null。 */
    public interface EngineProbe {
        final class Result {
            public boolean ok;
            public String name = "";
            public String version = "";
            public String error = "";
            /** 脚本 inited 事件里声明的平台键（有序） */
            public final List<String> platforms = new ArrayList<String>();
            /** 平台键 -> 显示名（脚本里给的，可为空串） */
            public final Map<String, String> platformNames = new LinkedHashMap<String, String>();
            /** 平台键 -> 该平台支持的音质键 */
            public final Map<String, List<String>> qualitys = new LinkedHashMap<String, List<String>>();
        }

        Result probe(String scriptText, String hintName);
    }

    /** 由引擎试跑结果拼一份「引擎执行型」描述 JSON（无 urlTemplates，靠 runner 标记可用）。 */
    public static String engineDescription(String hintName, EngineProbe.Result r) {
        if (r == null || !r.ok || r.platforms.size() == 0) {
            return "";
        }
        String name = r.name.length() == 0 ? cleanName(hintName) : r.name;
        if (name.length() == 0) {
            name = "导入脚本音源";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("{\"scriptFile\":\"").append(esc(hintName)).append("\",\"sourceUrl\":\"\",");
        sb.append("\"runner\":\"quickjs\",");
        sb.append("\"metadata\":{\"name\":\"").append(esc(name)).append("\",\"version\":\"")
                .append(esc(r.version)).append("\"},");
        sb.append("\"behaviour\":{\"sources\":[");
        for (int i = 0; i < r.platforms.size(); i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append('"').append(esc(r.platforms.get(i))).append('"');
        }
        sb.append("]},\"sources\":{");
        for (int i = 0; i < r.platforms.size(); i++) {
            String key = r.platforms.get(i);
            String display = r.platformNames.get(key);
            if (display == null || display.length() == 0) {
                display = platformName(key);
            }
            List<String> qs = r.qualitys.get(key);
            if (i > 0) {
                sb.append(',');
            }
            sb.append('"').append(esc(key)).append("\":{\"name\":\"").append(esc(display))
                    .append("\",\"idField\":\"\",\"qualitys\":[");
            if (qs != null) {
                for (int k = 0; k < qs.size(); k++) {
                    if (k > 0) {
                        sb.append(',');
                    }
                    sb.append('"').append(esc(qs.get(k))).append('"');
                }
            }
            sb.append("],\"urlTemplates\":{},\"levelTokens\":{}}");
        }
        sb.append("}}");
        String json = sb.toString();
        Item probeItem = fromJson("probe", json, "", false);
        return probeItem != null && probeItem.usable ? json : "";
    }

    /**
     * 从脚本文本尽力提取出一份描述 JSON：元信息（@name/@version）+ 平台键 + 取流模板。
     * 两种模板形式都认：
     *   ① 字面的「音质键 → http 地址」表；
     *   ② 脚本里按平台写出来的取流地址（`kg:{musicUrl(...) 返回 'http://host/kg_song.php?type=mp3&id=' + hash`
     *      或 ES 模板串 `` `http://host/qq.php?type=mp3&id=${n}&level=${e}` ``，以及已经写成 `{id}`/`{level}` 的模板），
     *      统一归一成 {id} / {level} 占位。
     * 提取不到任何可用模板时返回空串（调用方据此提示「端上无法应用」）。
     */
    public static String extractFromScript(String js, String hintName) {
        if (js == null || js.length() == 0) {
            return "";
        }
        // 平台 -> (音质键 -> 模板)
        Map<String, Map<String, String>> perPlatform = new LinkedHashMap<String, Map<String, String>>();
        Map<String, String> idFields = new LinkedHashMap<String, String>();

        // ① 字面「音质键 → http 地址」表：对所有平台生效
        Map<String, String> literal = new LinkedHashMap<String, String>();
        Matcher tm = P_QUALITY_URL.matcher(js);
        while (tm.find() && literal.size() < 8) {
            String key = tm.group(1);
            String url = unescapeUrl(tm.group(2));
            if (url.length() > 0 && !literal.containsKey(key)) {
                literal.put(key, url);
            }
        }
        if (literal.isEmpty()) {
            // ② 扫脚本里按平台写的取流地址模板
            scanTemplates(js, perPlatform, idFields);
        }

        List<String> keys = detectPlatforms(js);
        for (String p : perPlatform.keySet()) {
            if (!keys.contains(p)) {
                keys.add(p);
            }
        }
        List<String> ordered = new ArrayList<String>();
        for (int i = 0; i < PLATFORM_KEYS.length; i++) {
            if (keys.contains(PLATFORM_KEYS[i])) {
                ordered.add(PLATFORM_KEYS[i]);
            }
        }
        if (ordered.isEmpty()) {
            for (int i = 0; i < PLATFORM_KEYS.length; i++) {
                ordered.add(PLATFORM_KEYS[i]);
            }
        }

        // 只保留真的有模板的平台（没有模板的平台不落条目，避免留下「能选但取不到流」的空条目）
        List<String> useful = new ArrayList<String>();
        Map<String, Map<String, String>> templatesOf = new LinkedHashMap<String, Map<String, String>>();
        for (int i = 0; i < ordered.size(); i++) {
            String p = ordered.get(i);
            Map<String, String> tpls = literal.isEmpty() ? perPlatform.get(p) : literal;
            if (tpls == null || tpls.isEmpty()) {
                continue;
            }
            useful.add(p);
            templatesOf.put(p, tpls);
        }
        if (useful.isEmpty()) {
            return "";
        }

        String name = firstGroup(P_NAME, js);
        if (name.length() == 0) {
            name = cleanName(hintName);
        }
        if (name.length() == 0) {
            name = "导入脚本音源";
        }
        String version = firstGroup(P_VERSION, js);

        StringBuilder sb = new StringBuilder();
        sb.append("{\"scriptFile\":\"").append(esc(hintName)).append("\",\"sourceUrl\":\"\",");
        sb.append("\"metadata\":{\"name\":\"").append(esc(name)).append("\",\"version\":\"")
                .append(esc(version)).append("\"},");
        sb.append("\"behaviour\":{\"sources\":[");
        for (int i = 0; i < useful.size(); i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append('"').append(useful.get(i)).append('"');
        }
        sb.append("]},\"sources\":{");
        for (int i = 0; i < useful.size(); i++) {
            String p = useful.get(i);
            Map<String, String> tpls = templatesOf.get(p);
            String idField = idFields.get(p);
            if (idField == null || idField.length() == 0) {
                idField = "id";
            }
            boolean needLevel = false;
            for (String v : tpls.values()) {
                if (v != null && v.indexOf("{level}") >= 0) {
                    needLevel = true;
                }
            }
            if (i > 0) {
                sb.append(',');
            }
            sb.append('"').append(p).append("\":{\"name\":\"").append(esc(platformName(p)))
                    .append("\",\"idField\":\"").append(esc(idField)).append("\",\"qualitys\":[");
            int n = 0;
            for (String q : tpls.keySet()) {
                if (n++ > 0) {
                    sb.append(',');
                }
                sb.append('"').append(q).append('"');
            }
            sb.append("],\"urlTemplates\":{");
            n = 0;
            for (Map.Entry<String, String> e : tpls.entrySet()) {
                if (n++ > 0) {
                    sb.append(',');
                }
                sb.append('"').append(e.getKey()).append("\":\"").append(esc(e.getValue())).append('"');
            }
            sb.append("},\"levelTokens\":{");
            if (needLevel) {
                n = 0;
                for (int k = 0; k < QUALITY_KEYS.length; k++) {
                    if (!tpls.containsKey(QUALITY_KEYS[k])) {
                        continue;
                    }
                    if (n++ > 0) {
                        sb.append(',');
                    }
                    sb.append('"').append(QUALITY_KEYS[k]).append("\":\"")
                            .append(LEVEL_FOR_QUALITY[k]).append('"');
                }
            }
            sb.append("}}");
        }
        sb.append("}}");
        String json = sb.toString();
        // 自校验：构造出来的描述必须能被解析成有模板的音源，且平台数与落盘条目一致（防拼错 JSON）
        Item probe = fromJson("probe", json, "", false);
        if (probe == null || !probe.usable || probe.parsed.keys().size() != useful.size()) {
            return "";
        }
        return json;
    }

    /** 脚本里声明/暗含的平台键（`'kw'`、`"kw"`、`kw:` 三种写法都认）。 */
    private static List<String> detectPlatforms(String js) {
        List<String> keys = new ArrayList<String>();
        for (int i = 0; i < PLATFORM_KEYS.length; i++) {
            String k = PLATFORM_KEYS[i];
            if (js.indexOf("'" + k + "'") >= 0 || js.indexOf("\"" + k + "\"") >= 0
                    || js.indexOf(k + ":") >= 0) {
                keys.add(k);
            }
        }
        return keys;
    }

    /** 扫脚本里的取流地址模板：按「地址前最近出现的平台键」或地址特征归平台，归不到就铺给所有平台。 */
    private static void scanTemplates(String js, Map<String, Map<String, String>> out,
                                      Map<String, String> idFields) {
        Matcher m = P_ANY_URL.matcher(js);
        while (m.find()) {
            String url = normalizeTemplate(m.group(1));
            if (url.length() == 0) {
                continue;
            }
            String platform = platformBefore(js, m.start(), 2000);
            if (platform == null) {
                platform = platformFromUrl(url);
            }
            String idField = idFieldBefore(js, m.start(), 800);
            List<String> targets = new ArrayList<String>();
            if (platform != null) {
                targets.add(platform);
            } else {
                for (int i = 0; i < PLATFORM_KEYS.length; i++) {
                    targets.add(PLATFORM_KEYS[i]);
                }
            }
            for (int i = 0; i < targets.size(); i++) {
                String p = targets.get(i);
                Map<String, String> tpls = out.get(p);
                if (tpls == null) {
                    tpls = new LinkedHashMap<String, String>();
                    out.put(p, tpls);
                }
                if (tpls.isEmpty()) {
                    // 每个平台只留脚本里先出现的那条（脚本通常按优先级排列）
                    for (int k = 0; k < QUALITY_KEYS.length; k++) {
                        tpls.put(QUALITY_KEYS[k], url);
                    }
                    if (idField.length() > 0) {
                        idFields.put(p, idField);
                    }
                }
            }
        }
    }

    /**
     * 把一个字面地址规范化成可用的取流模板：占位统一成 {id} / {level}。
     * 返回空串表示这个地址当不了模板：不是取流接口（JSON/网页/歌词/封面/配置）、
     * 没有歌曲 id 位、或含无法解析的配置占位（如 ${URL_CONFIG.domains.x}）。
     */
    private static String normalizeTemplate(String raw) {
        if (raw == null || raw.length() == 0) {
            return "";
        }
        String low = raw.toLowerCase();
        for (int i = 0; i < NON_STREAM_HINTS.length; i++) {
            if (low.indexOf(NON_STREAM_HINTS[i]) >= 0) {
                return "";
            }
        }
        StringBuilder sb = new StringBuilder();
        boolean hasId = false;
        int i = 0;
        while (i < raw.length()) {
            char c = raw.charAt(i);
            int end;
            String name;
            if (c == '$' && i + 1 < raw.length() && raw.charAt(i + 1) == '{') {
                end = raw.indexOf('}', i + 2);
                name = end < 0 ? null : raw.substring(i + 2, end);
            } else if (c == '{') {
                end = raw.indexOf('}', i + 1);
                name = end < 0 ? null : raw.substring(i + 1, end);
            } else {
                sb.append(c);
                i++;
                continue;
            }
            if (name == null) {
                return "";
            }
            String token = placeholderToken(name, sb.toString());
            if (token.length() == 0) {
                return "";
            }
            if ("{id}".equals(token)) {
                hasId = true;
            }
            sb.append(token);
            i = end + 1;
        }
        String t = sb.toString();
        if (!hasId) {
            // 拼接式：地址末尾正好停在 id 参数上（`...php?type=mp3&id=` + n）→ 补上 {id}
            String tl = t.toLowerCase();
            if (tl.endsWith("id=") || tl.endsWith("mid=") || tl.endsWith("hash=") || tl.endsWith("rid=")) {
                t = t + "{id}";
                hasId = true;
            }
        }
        return hasId ? t : "";
    }

    /** 占位变量 -> {id} / {level}；分不清就返回空串（该地址不能用）。 */
    private static String placeholderToken(String name, String before) {
        String n = unwrapVar(name == null ? "" : name.trim());
        String b = before == null ? "" : before.toLowerCase();
        if (b.endsWith("id=") || b.endsWith("mid=") || b.endsWith("hash=") || b.endsWith("rid=")
                || b.endsWith("songmid=")) {
            return "{id}";
        }
        if (b.endsWith("level=") || b.endsWith("quality=") || b.endsWith("type=") || b.endsWith("br=")) {
            return "{level}";
        }
        String nl = n.toLowerCase();
        if (isIdName(nl)) {
            return "{id}";
        }
        if (isLevelName(nl)) {
            return "{level}";
        }
        return "";
    }

    /** 去掉常见简单包装（${encodeURIComponent(id)} 之类），露出真正的变量名。 */
    private static String unwrapVar(String n) {
        String s = n;
        String[] fns = {"encodeURIComponent", "encodeURI", "String", "Number"};
        boolean changed = true;
        while (changed) {
            changed = false;
            for (int i = 0; i < fns.length; i++) {
                String pre = fns[i] + "(";
                if (s.startsWith(pre) && s.endsWith(")")) {
                    s = s.substring(pre.length(), s.length() - 1).trim();
                    changed = true;
                }
            }
        }
        return s;
    }

    /** 是否是「纯变量名」（允许 a.b），带括号/运算符的表达式一律不算。 */
    private static boolean isSimpleName(String n) {
        if (n.length() == 0) {
            return false;
        }
        for (int i = 0; i < n.length(); i++) {
            char c = n.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
                    || c == '_' || c == '$' || c == '.';
            if (!ok) {
                return false;
            }
        }
        return true;
    }

    private static boolean isIdName(String n) {
        if (n.length() == 1) {
            return "n".equals(n) || "u".equals(n) || "d".equals(n) || "s".equals(n);
        }
        if (!isSimpleName(n)) {
            return false;
        }
        return n.endsWith("id") || n.endsWith("mid") || n.endsWith("hash");
    }

    private static boolean isLevelName(String n) {
        if (n.length() == 1) {
            return "e".equals(n) || "q".equals(n) || "l".equals(n);
        }
        if (!isSimpleName(n)) {
            return false;
        }
        return n.indexOf("level") >= 0 || n.indexOf("quality") >= 0 || n.indexOf("rate") >= 0
                || n.endsWith("br") || "type".equals(n);
    }

    /** 地址前最近出现过的平台键（如脚本里的 `kg:{musicUrl(...)`）。 */
    private static String platformBefore(String js, int idx, int window) {
        int from = Math.max(0, idx - window);
        String sub = js.substring(from, idx);
        int best = -1;
        String bestKey = null;
        for (int i = 0; i < PLATFORM_KEYS.length; i++) {
            String k = PLATFORM_KEYS[i];
            int p = Math.max(sub.lastIndexOf(k + ":"),
                    Math.max(sub.lastIndexOf("'" + k + "'"), sub.lastIndexOf("\"" + k + "\"")));
            if (p > best) {
                best = p;
                bestKey = k;
            }
        }
        return bestKey;
    }

    /** 从地址本身猜平台（路径里的 /kg/、kw.php、/qq/、migu 等）。 */
    private static String platformFromUrl(String url) {
        String u = url == null ? "" : url.toLowerCase();
        if (u.indexOf("kgqq") >= 0) {
            if (u.indexOf("/qq.php") >= 0 || u.indexOf("qq_kw") >= 0) {
                return "tx";
            }
            if (u.indexOf("/kg.php") >= 0 || u.indexOf("kg_song") >= 0) {
                return "kg";
            }
            if (u.indexOf("/kw.php") >= 0 || u.indexOf("kwstream") >= 0) {
                return "kw";
            }
        }
        if (u.indexOf("migu") >= 0 || u.indexOf("/mg/") >= 0 || u.indexOf("mg.php") >= 0) {
            return "mg";
        }
        if (u.indexOf("kwstream") >= 0 || u.indexOf("kuwo") >= 0 || u.indexOf("/kw/") >= 0
                || u.indexOf("kw.php") >= 0 || u.indexOf("kw_song") >= 0) {
            return "kw";
        }
        if (u.indexOf("kugou") >= 0 || u.indexOf("/kg/") >= 0 || u.indexOf("kg.php") >= 0
                || u.indexOf("kg_song") >= 0) {
            return "kg";
        }
        if (u.indexOf("qqmusic") >= 0 || u.indexOf("/qq") >= 0 || u.indexOf("qq_kw") >= 0) {
            return "tx";
        }
        if (u.indexOf("163.com") >= 0 || u.indexOf("/wy") >= 0 || u.indexOf("wy.php") >= 0) {
            return "wy";
        }
        return null;
    }

    /** 地址前文里脚本读 id 用的字段名（脚本里常见 …=r.hash / r.songmid）。 */
    private static String idFieldBefore(String js, int idx, int window) {
        int from = Math.max(0, idx - window);
        String sub = js.substring(from, idx);
        int h = sub.lastIndexOf("hash");
        int s = sub.lastIndexOf("songmid");
        if (h < 0 && s < 0) {
            return "";
        }
        return h > s ? "hash" : "songmid";
    }

    /** 导入文件落盘：写 <id>.json（描述），原始脚本另存 <id>.js 便于排查。 */
    public static Item save(File dir, String id, String json, String raw, boolean rawIsScript) {
        try {
            if (!dir.exists()) {
                dir.mkdirs();
            }
            String clean = cleanId(id);
            File desc = new File(dir, clean + ".json");
            java.io.FileOutputStream out = new java.io.FileOutputStream(desc);
            out.write(json.getBytes("UTF-8"));
            out.close();
            if (rawIsScript && raw != null && raw.length() > 0) {
                File src = new File(dir, clean + ".js");
                java.io.FileOutputStream out2 = new java.io.FileOutputStream(src);
                out2.write(raw.getBytes("UTF-8"));
                out2.close();
            } else if (!rawIsScript) {
                // 覆盖导入时清掉可能残留的旧脚本
                File old = new File(dir, clean + ".js");
                if (old.exists()) {
                    old.delete();
                }
            }
            return fromJson(clean, json, desc.getAbsolutePath(), false);
        } catch (Throwable t) {
            return null;
        }
    }

    /** 由文件名/地址推导一个干净的 id（去掉扩展名与非法字符）。 */
    public static String idFrom(String nameOrUrl) {
        String s = nameOrUrl == null ? "" : nameOrUrl.trim();
        int q = s.indexOf('?');
        if (q >= 0) {
            s = s.substring(0, q);
        }
        int slash = s.lastIndexOf('/');
        if (slash >= 0) {
            s = s.substring(slash + 1);
        }
        if (s.endsWith(".json") || s.endsWith(".js")) {
            s = s.substring(0, s.lastIndexOf('.'));
        }
        return cleanId(s);
    }

    /** id 清洗：只留字母数字与 _-，空则给个兜底名。 */
    public static String cleanId(String s) {
        StringBuilder sb = new StringBuilder();
        String src = s == null ? "" : s;
        for (int i = 0; i < src.length() && sb.length() < 40; i++) {
            char c = src.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
                    || c == '_' || c == '-') {
                sb.append(c);
            }
        }
        return sb.length() == 0 ? "source" + System.currentTimeMillis() % 100000 : sb.toString();
    }

    /** 扫描目录里可导入的文件（.json / .js），按文件名排序。 */
    public static List<File> listImportable(File dir) {
        List<File> out = new ArrayList<File>();
        if (dir == null || !dir.exists() || !dir.isDirectory()) {
            return out;
        }
        File[] files = dir.listFiles();
        if (files == null) {
            return out;
        }
        java.util.Arrays.sort(files, new java.util.Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
        for (int i = 0; i < files.length; i++) {
            File f = files[i];
            if (!f.isFile()) {
                continue;
            }
            String n = f.getName().toLowerCase();
            if (n.endsWith(".json") || n.endsWith(".js")) {
                out.add(f);
            }
        }
        return out;
    }

    // ---------------- 小工具 ----------------

    private static String firstGroup(Pattern p, String text) {
        if (text == null) {
            return "";
        }
        Matcher m = p.matcher(text);
        return m.find() ? m.group(1).trim() : "";
    }

    private static String cleanName(String hint) {
        String s = hint == null ? "" : hint.trim();
        if (s.endsWith(".js") || s.endsWith(".json")) {
            s = s.substring(0, s.lastIndexOf('.'));
        }
        return s;
    }

    private static String unescapeUrl(String u) {
        return u == null ? "" : u.replace("\\/", "/").replace("\\u002F", "/").replace("\\u002f", "/");
    }

    private static String platformName(String key) {
        if ("tx".equals(key)) {
            return "QQ音乐";
        }
        if ("kg".equals(key)) {
            return "酷狗";
        }
        if ("kw".equals(key)) {
            return "酷我";
        }
        if ("wy".equals(key)) {
            return "网易云";
        }
        if ("mg".equals(key)) {
            return "咪咕";
        }
        return key;
    }

    /** 拼 JSON 时对文本做转义（引号、反斜杠、控制字符）。 */
    private static String esc(String s) {
        if (s == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\\') {
                sb.append('\\').append(c);
            } else if (c == '\n') {
                sb.append("\\n");
            } else if (c == '\r') {
                sb.append("\\r");
            } else if (c == '\t') {
                sb.append("\\t");
            } else if (c < 0x20) {
                sb.append(' ');
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}