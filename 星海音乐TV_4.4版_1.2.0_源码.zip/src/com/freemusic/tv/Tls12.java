package com.freemusic.tv;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * Android 4.4（API 19）默认只启用 TLSv1，很多站点早已只接受 TLSv1.2，
 * 因此这里给 HttpsURLConnection 换上会协商 TLSv1.2 / TLSv1.1 / TLSv1 的 SocketFactory。
 * 证书链校验保持默认（不使用任何绕过校验的 TrustManager）。
 */
public final class Tls12 {

    private Tls12() {
    }

    private static volatile boolean installed;

    public static synchronized void install() {
        if (installed) {
            return;
        }
        installed = true;
        try {
            SSLSocketFactory base = HttpsURLConnection.getDefaultSSLSocketFactory();
            HttpsURLConnection.setDefaultSSLSocketFactory(new Factory(base));
        } catch (Throwable ignore) {
            // 部分老设备可能不支持；取不到就沿用系统默认
        }
    }

    static final class Factory extends SSLSocketFactory {
        private final SSLSocketFactory base;

        Factory(SSLSocketFactory base) {
            this.base = base;
        }

        private Socket tune(Socket s) {
            if (s instanceof SSLSocket) {
                SSLSocket ss = (SSLSocket) s;
                try {
                    ss.setEnabledProtocols(new String[]{"TLSv1.2", "TLSv1.1", "TLSv1"});
                } catch (Throwable ignore) {
                    // 设备不支持某个协议时保持系统默认
                }
            }
            return s;
        }

        @Override
        public String[] getDefaultCipherSuites() {
            return base.getDefaultCipherSuites();
        }

        @Override
        public String[] getSupportedCipherSuites() {
            return base.getSupportedCipherSuites();
        }

        @Override
        public Socket createSocket(Socket s, String host, int port, boolean autoClose) throws IOException {
            return tune(base.createSocket(s, host, port, autoClose));
        }

        @Override
        public Socket createSocket(String host, int port) throws IOException {
            return tune(base.createSocket(host, port));
        }

        @Override
        public Socket createSocket(String host, int port, InetAddress localHost, int localPort) throws IOException {
            return tune(base.createSocket(host, port, localHost, localPort));
        }

        @Override
        public Socket createSocket(InetAddress host, int port) throws IOException {
            return tune(base.createSocket(host, port));
        }

        @Override
        public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort)
                throws IOException {
            return tune(base.createSocket(address, port, localAddress, localPort));
        }
    }

    }