package com.freemusic.tv;

import android.content.Context;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** 视图与格式化小工具。 */
public final class Ui {

    private Ui() {
    }

    public static int dp(Context ctx, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                ctx.getResources().getDisplayMetrics());
    }

    public static TextView chip(Context ctx, String text) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        tv.setTextColor(ctx.getResources().getColorStateList(R.color.itm_text));
        tv.setBackgroundResource(R.drawable.chip_bg);
        tv.setGravity(Gravity.CENTER);
        tv.setFocusable(true);
        tv.setClickable(true);
        tv.setSingleLine(true);
        tv.setPadding(dp(ctx, 16), 0, dp(ctx, 16), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(ctx, 42));
        lp.rightMargin = dp(ctx, 10);
        tv.setLayoutParams(lp);
        return tv;
    }

    public static String time(int ms) {
        if (ms <= 0) {
            return "00:00";
        }
        int total = ms / 1000;
        int m = total / 60;
        int s = total % 60;
        return (m < 10 ? "0" + m : String.valueOf(m)) + ":" + (s < 10 ? "0" + s : String.valueOf(s));
    }

    public static void toast(Context ctx, String msg) {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();
    }

    public static int color(Context ctx, int resId) {
        return ctx.getResources().getColor(resId);
    }
}