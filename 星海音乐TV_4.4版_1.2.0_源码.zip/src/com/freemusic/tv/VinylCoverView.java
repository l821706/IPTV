package com.freemusic.tv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;

import java.util.Random;

/**
 * 黑胶唱片封面视图：纯 Canvas 绘制，不使用任何图片库与矢量图资源。
 * 有封面时把封面裁成圆形并随播放旋转；无封面时用歌名首字生成唱片贴纸。
 */
public class VinylCoverView extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final RectF coverRect = new RectF();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private Bitmap cover;
    private String label = "";
    private boolean playing;
    private float rotation;
    private int fallbackColor = 0xFF2B6BF0;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (playing) {
                rotation += 0.5f;
                if (rotation >= 360f) {
                    rotation -= 360f;
                }
                invalidate();
            }
            handler.postDelayed(this, 40);
        }
    };

    public VinylCoverView(Context context) {
        super(context);
        init();
    }

    public VinylCoverView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public VinylCoverView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    public void setCover(Bitmap bmp) {
        cover = bmp;
        invalidate();
    }

    public void setLabel(String text) {
        label = text == null ? "" : text;
        Random random = new Random(label.hashCode());
        fallbackColor = 0xFF000000 | (0x40 + random.nextInt(0x80)) << 16
                | (0x60 + random.nextInt(0x80)) << 8 | (0x90 + random.nextInt(0x60));
        invalidate();
    }

    public void setPlaying(boolean p) {
        if (playing == p) {
            return;
        }
        playing = p;
        if (playing) {
            handler.removeCallbacks(ticker);
            handler.postDelayed(ticker, 40);
        } else {
            handler.removeCallbacks(ticker);
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        handler.removeCallbacks(ticker);
        handler.postDelayed(ticker, 40);
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacks(ticker);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        int size = Math.min(w, h);
        float cx = w / 2f;
        float cy = h / 2f;
        float radius = size / 2f - 4f;
        if (radius <= 0) {
            return;
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF11151C);
        canvas.drawCircle(cx, cy, radius, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1f);
        paint.setColor(0xFF242C3A);
        float grooveOuter = radius - 6f;
        float grooveInner = radius * 0.66f;
        for (float r = grooveOuter; r > grooveInner; r -= 7f) {
            canvas.drawCircle(cx, cy, r, paint);
        }

        float coverRadius = radius * 0.62f;
        clip.reset();
        clip.addCircle(cx, cy, coverRadius, Path.Direction.CW);
        canvas.save();
        canvas.clipPath(clip);
        if (cover != null) {
            canvas.save();
            canvas.rotate(rotation, cx, cy);
            coverRect.set(cx - coverRadius, cy - coverRadius, cx + coverRadius, cy + coverRadius);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawBitmap(cover, null, coverRect, paint);
            canvas.restore();
        } else {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(fallbackColor);
            canvas.drawCircle(cx, cy, coverRadius, paint);
            paint.setColor(0xFFFFFFFF);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(coverRadius * 0.9f);
            String text = label.length() > 0 ? label.substring(0, 1) : "♪";
            Paint.FontMetrics fm = paint.getFontMetrics();
            float offset = (fm.descent - fm.ascent) / 2f - fm.descent;
            canvas.drawText(text, cx, cy + offset, paint);
        }
        canvas.restore();

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF0B0E13);
        canvas.drawCircle(cx, cy, radius * 0.075f, paint);
        paint.setColor(0xFF4C9AFF);
        canvas.drawCircle(cx, cy, radius * 0.032f, paint);

        if (!playing) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(3f);
            paint.setColor(0x663D8BFD);
            canvas.drawCircle(cx, cy, radius - 2f, paint);
        }
    }
}