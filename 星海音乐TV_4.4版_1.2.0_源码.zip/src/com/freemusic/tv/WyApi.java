package com.freemusic.tv;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 网易云音乐公开接口（搜索 / 榜单 / 取流 / 歌词）。 */
public final class WyApi {

    private static final String HOST = "http://music.163.com";

    private WyApi() {
    }

    public static Map<String, String> headers() {
        return Http.headers("Referer", "http://music.163.com/");
    }

    public static List<Song> search(String keyword, int limit) {
        List<Song> out = new ArrayList<Song>();
        if (keyword == null || keyword.trim().length() == 0) {
            return out;
        }
        String url = HOST + "/api/search/get/web?s=" + Http.encode(keyword) + "&type=1&limit=" + limit + "&offset=0";
        Http.Res res = Http.get(url, headers());
        if (!res.ok()) {
            return out;
        }
        Object root = Json.parse(res.body);
        List<Object> songs = Json.listAt(root, "result", "songs");
        for (int i = 0; i < songs.size() && out.size() < limit; i++) {
            Song s = fromJson(songs.get(i));
            if (s != null) {
                out.add(s);
            }
        }
        return out;
    }

    /** 歌单 / 榜单详情，返回曲目列表。 */
    public static List<Song> playlist(String playlistId, int limit) {
        List<Song> out = new ArrayList<Song>();
        String url = HOST + "/api/playlist/detail?id=" + playlistId;
        Http.Res res = Http.get(url, headers());
        if (!res.ok()) {
            return out;
        }
        Object root = Json.parse(res.body);
        List<Object> tracks = Json.listAt(root, "result", "tracks");
        for (int i = 0; i < tracks.size() && (limit <= 0 || out.size() < limit); i++) {
            Song s = fromJson(tracks.get(i));
            if (s != null) {
                out.add(s);
            }
        }
        return out;
    }

    /** 官方取流接口，取不到（无版权 / 需付费）时返回空串。 */
    public static String songUrl(String id, int br) {
        if (id == null || id.length() == 0) {
            return "";
        }
        String url = HOST + "/api/song/enhance/player/url?ids=%5B" + id + "%5D&br=" + br;
        Http.Res res = Http.get(url, headers());
        if (!res.ok()) {
            return "";
        }
        Object root = Json.parse(res.body);
        String u = Json.strAt(root, "data", "0", "url");
        if (u == null || u.length() == 0 || "null".equals(u)) {
            return "";
        }
        return u;
    }

    /** 外链直链，作为官方接口取不到时的兜底。 */
    public static String outerUrl(String id) {
        if (id == null || id.length() == 0) {
            return "";
        }
        return HOST + "/song/media/outer/url?id=" + id + ".mp3";
    }

    /** 歌词，取不到返回空串。 */
    public static String lyric(String id) {
        if (id == null || id.length() == 0) {
            return "";
        }
        String url = HOST + "/api/song/lyric?id=" + id + "&lv=1&kv=1&tv=-1";
        Http.Res res = Http.get(url, headers());
        if (!res.ok()) {
            return "";
        }
        Object root = Json.parse(res.body);
        String lrc = Json.strAt(root, "lrc", "lyric");
        return lrc == null ? "" : lrc;
    }

    private static Song fromJson(Object node) {
        if (node == null) {
            return null;
        }
        String id = Json.strAt(node, "id");
        if (id.length() == 0) {
            return null;
        }
        String title = Json.html(Json.strAt(node, "name"));
        StringBuilder artist = new StringBuilder();
        List<Object> artists = Json.listAt(node, "artists");
        for (int i = 0; i < artists.size(); i++) {
            if (artist.length() > 0) {
                artist.append('/');
            }
            artist.append(Json.html(Json.strAt(artists.get(i), "name")));
        }
        String album = Json.html(Json.strAt(node, "album", "name"));
        String pic = Json.strAt(node, "album", "picUrl");
        long duration = Json.lonAt(node, "duration");
        return new Song(title, artist.toString(), album, Song.SRC_WY, id, "", pic, (int) duration);
    }

    /** 榜单分类固定表（平台公开榜单 id，已逐一核对名称）。 */
    public static Map<String, String> stations() {
        Map<String, String> m = new LinkedHashMap<String, String>();
        String[] names = stationNames();
        String[] ids = stationIds();
        for (int i = 0; i < names.length; i++) {
            m.put(names[i], ids[i]);
        }
        return m;
    }

    public static String[] stationNames() {
        return new String[]{
                "热歌榜", "新歌榜", "飙升榜", "原创榜",
                "网易云电音榜", "网易云国风榜", "网易云民谣榜", "网易云摇滚榜",
                "网易云ACG榜", "网易云古典榜", "网易云欧美热歌榜", "美国Billboard榜"
        };
    }

    public static String[] stationIds() {
        return new String[]{
                "3778678", "3779629", "19723756", "2884035",
                "1978921795", "5059642708", "5059661515", "5059633707",
                "71385702", "71384707", "2809513713", "60198"
        };
    }
}