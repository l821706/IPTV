#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""布局尺寸自检。

Android 4.4 对 ViewGroup 子元素的 layout_width / layout_height 是硬要求：
缺失时不会在 aapt2 编译或链接阶段报错，而是在 LayoutInflater 运行时抛
"Binary XML file line #N: You must supply a layout_width attribute"，
表现为应用一打开就闪退。所以这里在构建前把 res/layout 全部扫一遍，
把「元素自身没写、样式里也没提供」的情况直接当成构建失败。

用法：check_layouts.py [res 目录]
"""
import glob
import os
import sys
import xml.etree.ElementTree as ET

ANDROID = "http://schemas.android.com/apk/res/android"
LAYOUT_ATTRS = ("layout_width", "layout_height")


def style_attrs(res_dir):
    """收集 res/values 下各样式声明里提供的 layout_width / layout_height。"""
    found = {}
    for path in glob.glob(os.path.join(res_dir, "values*", "*.xml")):
        try:
            root = ET.parse(path).getroot()
        except ET.ParseError:
            continue
        for style in root.iter("style"):
            name = style.get("name")
            if not name:
                continue
            attrs = found.setdefault(name, set())
            for item in style.iter("item"):
                item_name = item.get("name") or ""
                # values XML 里的 android: 前缀不一定绑定命名空间，统一取冒号后半段
                short = item_name.split(":")[-1].strip()
                if short in LAYOUT_ATTRS:
                    attrs.add(short)
    return found


def main():
    res_dir = sys.argv[1] if len(sys.argv) > 1 else "res"
    layout_dir = os.path.join(res_dir, "layout")
    if not os.path.isdir(layout_dir):
        print("找不到布局目录：%s" % layout_dir)
        return 1
    styles = style_attrs(res_dir)
    problems = []
    total = 0
    for path in sorted(glob.glob(os.path.join(layout_dir, "*.xml"))):
        try:
            root = ET.parse(path).getroot()
        except ET.ParseError as e:
            problems.append((path, "-", "-", "XML 解析失败: %s" % e))
            continue
        for el in root.iter():
            if not isinstance(el.tag, str):
                continue
            total += 1
            style = (el.get("style") or "").replace("@style/", "").replace("@android:style/", "")
            provided = styles.get(style, set())
            have = set()
            for attr in LAYOUT_ATTRS:
                value = el.get("{" + ANDROID + "}" + attr)
                if value is not None and value != "":
                    have.add(attr)
            if el.get("{" + ANDROID + "}layout_width") in ("match_parent", "fill_parent") and \
                    el.get("{" + ANDROID + "}layout_height") is not None:
                pass
            missing = [a for a in LAYOUT_ATTRS if a not in have and a not in provided]
            if missing:
                problems.append((os.path.basename(path), el.tag,
                                 el.get("{" + ANDROID + "}id", "-"),
                                 "缺少 " + " / ".join(missing) + ("（样式 %s 也未提供）" % style if style else "")))
    print("布局尺寸自检：扫描 %d 个元素，发现问题 %d 个" % (total, len(problems)))
    for p in problems:
        print("  [问题] %s <%s> id=%s %s" % p)
    if problems:
        print("修复提示：给元素补上 android:layout_width / android:layout_height，"
              "或把尺寸写进它引用的 style。")
        return 1
    print("全部元素都具备 layout_width / layout_height（含样式提供的）")
    return 0


if __name__ == "__main__":
    sys.exit(main())