#!/usr/bin/env node
/**
 * 在构建期真实执行一份 lx-music-source 音源脚本，把它对外暴露的能力固化成描述文件。
 *
 * 为什么这么做（而不是在电视端跑 JS）：
 *   Android 4.4 的 WebView 是 Chromium 33（只有 ES5），可用版 Rhino 同样只到 ES5，
 *   而这类音源脚本普遍是 ES2015+（箭头函数/解构/模板串/async），端上根本解析不了；
 *   加上不少 4.4 电视盒子压根没有可用 WebView。
 *   而这类脚本的取流逻辑是纯字符串拼装（url 模板 + 音质等级 + 平台 id），
 *   所以「构建期把脚本跑一遍、把它的行为固化成描述文件、端上按描述文件执行」，
 *   与在端上跑脚本的行为一致，却不依赖任何 JS 引擎。
 *
 * 用法: node extract_lx_source.js <脚本路径> [输出 json 路径] [音源来源地址]
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const scriptPath = process.argv[2];
if (!scriptPath) {
  console.error('用法: node extract_lx_source.js <脚本路径> [输出 json 路径] [音源来源地址]');
  process.exit(2);
}
// require() 会把不带 ./ 的相对路径当“模块名”解析，这里统一转成绝对路径，避免相对路径取不到脚本
const scriptPathAbs = path.resolve(scriptPath);
const outPath = process.argv[3] || path.join(process.cwd(), 'lx_source.json');
// 内置音源接口的官方地址（例如 pdone/lx-music-source 的 changqing/latest.js），写进描述文件便于溯源
const sourceUrl = process.argv[4] || process.env.LX_SOURCE_URL || '';
const scriptSource = fs.readFileSync(scriptPathAbs, 'utf8');

// 让 url 里能看出脚本读的是 musicInfo 的哪个字段
const PLACEHOLDERS = [
  'hash', 'songmid', 'songId', 'id', 'rid', 'musicId', 'mid', 'albumId', 'copyrightId', 'idstr'
];
const probeInfo = {};
PLACEHOLDERS.forEach(f => { probeInfo[f] = '__' + f.toUpperCase() + '__'; });

const report = {
  scriptFile: path.basename(scriptPath),
  scriptBytes: Buffer.byteLength(scriptSource, 'utf8'),
  sourceUrl: sourceUrl,
  scriptSha256: crypto.createHash('sha256').update(scriptSource, 'utf8').digest('hex'),
  metadata: {},
  runtime: { esFeatures: [], engineNote: '' },
  sources: {},
  updateCheck: {},
  behaviour: {},
  problems: []
};

(function readMetadata(src) {
  const meta = {};
  const re = /@(name|description|version|author|homepage|update_url)\s+([^\n*]+)/g;
  let m;
  while ((m = re.exec(src)) !== null) {
    meta[m[1]] = m[2].trim();
  }
  report.metadata = meta;
})(scriptSource);

// 脚本内部解码出来的本地版本号、更新检查地址、版本比较分隔符（更新门禁用到这三个）
(function decodeVersionBits(src) {
  try {
    const start = src.indexOf('globalThis.lx,') + 'globalThis.lx,'.length;
    const end = src.indexOf(',_dab=');
    const seg = src.slice(start, end);
    const literal = '({' + seg.replace(/^_jd=/, '_jd:').replace(/,_qw=/, ',_qw:') + '})';
    const decoded = eval(literal);
    report.updateCheck.localVersion = decoded._jd;
    report.updateCheck.url = decoded._qw;
  } catch (e) {
    report.problems.push('本地版本号/更新地址解码失败: ' + ((e && e.message) || e));
  }
  try {
    const nzi = src.slice(src.indexOf('_nzi=(r,e)=>'), src.indexOf('_ui='));
    const sepExpr = nzi.match(/split\((.+?)\)\.map/);
    if (sepExpr) {
      report.updateCheck.versionSeparator = eval('(' + sepExpr[1] + ')');
    }
  } catch (e) {
    report.problems.push('版本分隔符解码失败: ' + ((e && e.message) || e));
  }
  // 脚本里的“更新门禁”判断：只有 statusCode 等于这个值才认为检查成功
  try {
    const cond = src.match(/statusCode!==([0-9+\-*/().\s]+)\)/);
    if (cond) {
      const expected = eval(cond[1]);
      report.updateCheck.expectedStatusCode = expected;
      report.updateCheck.gateEffective = expected >= 100 && expected <= 599;
      if (!report.updateCheck.gateEffective) {
        report.behaviour.gateObservation =
          '更新门禁实测失效：脚本要求 statusCode === ' + expected
          + '，正常 HTTP 响应永远不会满足，因此它总是走“检查更新失败”分支、照常注册音源，'
          + '不会因为上游发布新版本而停止提供音源。';
      }
    }
  } catch (e) {
    report.problems.push('状态码判断解析失败: ' + ((e && e.message) || e));
  }
})(scriptSource);

// 粗略判断脚本用到的语法/运行时能力（决定端上能否直接跑）
(function scanFeatures(src) {
  const checks = [
    ['globalThis', /\bglobalThis\b/],
    ['arrow function', /=>/],
    ['const/let', /\b(const|let)\s/],
    ['destructuring', /const\s*\{[^}]*\}\s*=/],
    ['template literal', /`[^`]*\$\{/],
    ['async/await', /\basync\b|\bawait\b/],
    ['optional chaining', /\?\./]
  ];
  checks.forEach(([name, re]) => {
    if (re.test(src)) {
      report.runtime.esFeatures.push(name);
    }
  });
  report.runtime.engineNote =
    '需要 ES2015+ 解析能力：Android 4.4 的 WebView(Chromium 33) 与可用版 Rhino 均为 ES5，'
    + '不能直接解析；故采用「构建期执行 + 行为描述文件 + 端上按描述执行」的方案。';
})(scriptSource);

const handlers = {};
let initedPayload = null;
let updateAlert = null;
let mode = 'normal';   // normal: 上游没有更新；outdated: 上游发布更新版本

globalThis.lx = {
  EVENT_NAMES: { request: 'request', inited: 'inited', updateAlert: 'updateAlert' },
  request: (url, options, callback) => {
    report.updateCheck = Object.assign(report.updateCheck, {
      url: url,
      method: (options && options.method) || 'GET',
      timeoutMs: (options && options.timeout) || null,
      bodyIsParsedObject: true
    });
    const remote = mode === 'outdated' ? '9.9.9' : (report.updateCheck.localVersion || '0.0.1');
    // lx-music 运行时的 request 回调里 body 是已解析好的对象，这里按同样形状返回
    callback(null, {
      statusCode: 200,
      statusMessage: 'OK',
      body: { version: remote, updateUrl: 'https://example.invalid/update', description: '本地探测' }
    });
  },
  on: (eventName, handler) => { handlers[eventName] = handler; },
  send: (eventName, payload) => {
    if (eventName === 'inited') { initedPayload = payload; }
    if (eventName === 'updateAlert') { updateAlert = payload; }
  }
};

function loadScript() {
  initedPayload = null;
  updateAlert = null;
  delete require.cache[require.resolve(scriptPathAbs)];
  require(scriptPathAbs);
}

const waitInit = () => new Promise(resolve => setTimeout(resolve, 500));

(async () => {
  // 第一次：上游没有新版本 → 应正常注册音源
  mode = 'normal';
  loadScript();
  await waitInit();
  report.behaviour.registersWhenUpToDate = !!(initedPayload && initedPayload.sources);

  if (initedPayload && initedPayload.sources) {
    const keys = Object.keys(initedPayload.sources);
    report.behaviour.sources = keys;
    const handler = handlers['request'];
    for (const key of keys) {
      const decl = initedPayload.sources[key];
      const entry = {
        name: decl.name,
        type: decl.type,
        actions: decl.actions,
        qualitys: decl.qualitys,
        levelTokens: {},
        urlTemplates: {},
        idField: null,
        idFieldProof: ''
      };
      for (const q of decl.qualitys) {
        try {
          const url = await Promise.resolve(handler({
            source: key,
            action: 'musicUrl',
            info: { musicInfo: probeInfo, type: q }
          }));
          entry.levelTokens[q] = (/(?:^|&)level=([^&]+)/.exec(url) || [])[1] || '';
          let template = url;
          let idField = null;
          for (const f of PLACEHOLDERS) {
            const token = probeInfo[f];
            if (template.indexOf(token) >= 0) {
              template = template.split(token).join('{id}');
              idField = f;
            }
          }
          entry.urlTemplates[q] = template;
          if (idField) {
            entry.idField = idField;
            entry.idFieldProof = 'url 中出现了 musicInfo.' + idField + ' 的占位符';
          }
        } catch (e) {
          report.problems.push(key + '/' + q + ' 调用异常: ' + ((e && e.message) || e));
        }
      }
      report.sources[key] = entry;
    }
  } else {
    report.problems.push('上游视为最新时脚本仍未注册音源');
  }

  // 第二次：模拟上游发布了更新版本 → 观察脚本是否停止提供音源
  mode = 'outdated';
  loadScript();
  await waitInit();
  report.behaviour.blocksWhenOutdated = !(initedPayload && initedPayload.sources);
  report.behaviour.updateAlertPayload = updateAlert;

  fs.writeFileSync(outPath, JSON.stringify(report, null, 2), 'utf8');
  console.log('已写出描述文件:', outPath);
  console.log('脚本元信息:', JSON.stringify(report.metadata));
  console.log('音源来源地址:', report.sourceUrl || '(未提供)', ' sha256:', report.scriptSha256);
  console.log('运行时特征:', report.runtime.esFeatures.join(', ') || '(未识别)');
  console.log('更新检查:', report.updateCheck.url, report.updateCheck.method,
    '本地版本=' + report.updateCheck.localVersion, '分隔符=' + JSON.stringify(report.updateCheck.versionSeparator));
  console.log('上游有新版本时是否停止提供音源:', report.behaviour.blocksWhenOutdated,
    ' 告警内容片段=', JSON.stringify(report.behaviour.updateAlertPayload || null).slice(0, 160));
  console.log('平台:', Object.keys(report.sources).map(k =>
    k + '(' + report.sources[k].name + ', id=' + report.sources[k].idField + ')').join(' , '));
  Object.keys(report.sources).forEach(k => {
    const s = report.sources[k];
    console.log('  ' + k + ' 音质=' + JSON.stringify(s.qualitys) + ' 等级=' + JSON.stringify(s.levelTokens));
  });
  if (report.problems.length) { console.log('问题:', report.problems.join(' | ')); }
  process.exit(0);
})();