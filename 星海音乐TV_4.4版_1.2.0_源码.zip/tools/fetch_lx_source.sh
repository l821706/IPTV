#!/usr/bin/env bash
#
# 取内置音源脚本。
# 默认从官方地址取：https://raw.githubusercontent.com/pdone/lx-music-source/main/changqing/latest.js
# GitHub 直连不可达时按顺序尝试镜像（jsDelivr / gitmirror / ghproxy），全部失败则沿用仓库里已有的脚本。
#
# 用法: fetch_lx_source.sh <输出文件>
#       LX_SOURCE_URL=<自定义地址> fetch_lx_source.sh <输出文件>
#
set -euo pipefail

OUT="${1:?用法: fetch_lx_source.sh <输出文件>}"
URL="${LX_SOURCE_URL:-https://raw.githubusercontent.com/pdone/lx-music-source/main/changqing/latest.js}"
mkdir -p "$(dirname "$OUT")"

# 由官方 raw 地址推导出镜像地址
MIRRORS="$URL
$(printf '%s' "$URL" | sed -n 's|https://raw.githubusercontent.com/\([^/]*\)/\([^/]*\)/\([^/]*\)/\(.*\)|https://cdn.jsdelivr.net/gh/\1/\2@\3/\4|p')
$(printf '%s' "$URL" | sed -n 's|https://raw.githubusercontent.com/\([^/]*\)/\([^/]*\)/\([^/]*\)/\(.*\)|https://raw.gitmirror.com/\1/\2/\3/\4|p')
$(printf '%s' "$URL" | sed -n 's|https://raw.githubusercontent.com/\(.*\)|https://ghproxy.net/https://raw.githubusercontent.com/\1|p')"

TMP="$(mktemp)"
trap 'rm -f "$TMP"' EXIT

for u in $MIRRORS; do
  [ -n "$u" ] || continue
  code="$(curl -sL --max-time 30 -o "$TMP" -w '%{http_code}' -H 'User-Agent: Mozilla/5.0' "$u" 2>/dev/null || echo 000)"
  size="$(stat -c%s "$TMP" 2>/dev/null || echo 0)"
  if [ "$code" = "200" ] && [ "$size" -gt 2000 ]; then
    cp "$TMP" "$OUT"
    printf '内置音源脚本已获取：%s（%s 字节）\n' "$u" "$size"
    exit 0
  fi
  printf '取用失败：%s（HTTP %s / %s 字节）\n' "$u" "$code" "$size" >&2
done

if [ -s "$OUT" ]; then
  printf '所有地址均不可达，沿用仓库中已有的 %s\n' "$OUT" >&2
  exit 0
fi
printf '无法获取内置音源脚本：%s\n' "$URL" >&2
exit 1