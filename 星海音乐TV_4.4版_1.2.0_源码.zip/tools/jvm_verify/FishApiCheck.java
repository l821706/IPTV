import com.freemusic.tv.FishApi;
import com.freemusic.tv.Http;
import com.freemusic.tv.KgApi;
import com.freemusic.tv.KwApi;
import com.freemusic.tv.LxSource;
import com.freemusic.tv.QqApi;
import com.freemusic.tv.Song;
import com.freemusic.tv.WyApi;

import java.io.File;
import java.util.List;

/**
 * 内置音源 fish_music 专项联网核对：装载描述文件 → 各平台按脚本分支取流 → 2KB 音频验真。
 * 用法: java -cp tools/jvm_verify/out FishApiCheck [关键词] [音源描述文件]
 */
public class FishApiCheck {

    private static int pass;
    private static int fail;

    public static void main(String[] args) throws Exception {
        String keyword = args.length > 0 ? args[0] : "晴天 周杰伦";
        String descriptor = args.length > 1 ? args[1] : "assets/lx_source.json";

        File f = new File(descriptor);
        StringBuilder sb = new StringBuilder();
        java.io.BufferedReader br = new java.io.BufferedReader(
                new java.io.InputStreamReader(new java.io.FileInputStream(f), "UTF-8"));
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line).append('\n');
        }
        br.close();
        LxSource.setActive(LxSource.parse(sb.toString()));
        LxSource lx = LxSource.active();

        report("描述文件装载", lx != null && lx.isReady(),
                lx == null ? "未装载" : (lx.describe() + " / " + lx.scriptFile() + " / 平台=" + lx.sourceKeys()));
        report("fish 链路启用（enabled）", FishApi.enabled(), "enabled=" + FishApi.enabled());

        check("网易云", WyApi.search(keyword, 5), Song.SRC_WY);
        check("酷我", KwApi.search(keyword, 5), Song.SRC_KW);
        check("酷狗", KgApi.search(keyword, 5), Song.SRC_KG);
        check("QQ音乐", QqApi.search(keyword, 5), Song.SRC_QQ);
        summary();
    }

    private static void check(String label, List<Song> found, String src) {
        Song song = pick(found);
        if (song == null) {
            report(label + " 搜索到可试的样本歌", false, "无结果");
            return;
        }
        System.out.println("-- " + label + "：" + song.title + " / " + song.artist + " / id=" + song.id
                + " / " + (song.duration / 1000) + "s --");
        int good = 0;
        for (int i = 0; i < 2; i++) {
            String q = i == 0 ? "320k" : "128k";
            FishApi.Resolved r = FishApi.resolve(song, q);
            if (!r.ok()) {
                System.out.println("[INFO] " + label + " " + q + " 本条未取到可用地址（上游："
                        + (r.upstream.length() == 0 ? "全部尝试失败" : r.upstream) + "），端上会落到后续线路");
                continue;
            }
            Http.Probe p = Http.probeAudio(r.url, Http.headers());
            if (p.audio) {
                good++;
            }
            System.out.println("[" + (p.audio ? "OK" : "INFO") + "] " + label + " " + q + " 取流（"
                    + r.upstream + "） -> HTTP " + p.code + " · " + p.contentType + " · "
                    + (p.audio ? "真音频 · " + r.url : p.error));
        }
        report(label + " 至少一条音质档能取到真音频", good > 0, "可用档位 " + good + "/2");
    }

    private static Song pick(List<Song> list) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        Song longest = null;
        for (int i = 0; i < list.size(); i++) {
            Song s = list.get(i);
            if (s.title.indexOf("片段") >= 0) {
                continue;
            }
            if (longest == null || s.duration > longest.duration) {
                longest = s;
            }
        }
        return longest == null ? list.get(0) : longest;
    }

    private static void report(String name, boolean ok, String detail) {
        if (ok) {
            pass++;
        } else {
            fail++;
        }
        System.out.println("[" + (ok ? "PASS" : "FAIL") + "] " + name + " -> " + detail);
    }

    private static void summary() {
        System.out.println("==== 汇总：通过 " + pass + " 项，失败 " + fail + " 项 ====");
    }
}