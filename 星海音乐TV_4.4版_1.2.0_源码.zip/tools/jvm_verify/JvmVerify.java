import com.freemusic.tv.FishApi;
import com.freemusic.tv.Http;
import com.freemusic.tv.KgApi;
import com.freemusic.tv.KwApi;
import com.freemusic.tv.Lrc;
import com.freemusic.tv.LxSource;
import com.freemusic.tv.PlayResolver;
import com.freemusic.tv.QqApi;
import com.freemusic.tv.Song;
import com.freemusic.tv.WyApi;

import java.io.File;
import java.util.List;
import java.util.Map;

/**
 * JVM 端真实联网验证：用的就是打进 APK 的同一份 class，
 * 逐项核对搜索、榜单、歌词、多平台取流与 2KB 音频验真、脚本音源线路以及下载兜底。
 * 用法: java -cp build/classes:tools/jvm_verify/out JvmVerify [关键词] [音源描述文件]
 */
public class JvmVerify {

    private static int pass;
    private static int fail;

    public static void main(String[] args) throws Exception {
        String keyword = args.length > 0 ? args[0] : "周杰伦";
        String descriptor = args.length > 1 ? args[1] : "assets/lx_source.json";
        System.out.println("== 关键词：" + keyword + " ==");

        // 装载构建期由脚本固化出来的音源描述文件（端上是从 assets 读，这里从磁盘读同一份文件）
        File lxFile = new File(descriptor);
        if (lxFile.isFile()) {
            StringBuilder sb = new StringBuilder();
            java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.InputStreamReader(new java.io.FileInputStream(lxFile), "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
            }
            br.close();
            LxSource.setActive(LxSource.parse(sb.toString()));
        }
        LxSource lx = LxSource.active();
        report("脚本音源描述文件装载", lx != null && lx.isReady(),
                lx == null ? "未装载" : (lx.describe() + " / " + lx.scriptFile() + " / 音源键=" + lx.sourceKeys()));
        if (lx != null && lx.isReady()) {
            for (int i = 0; i < lx.sourceKeys().size(); i++) {
                String k = lx.sourceKeys().get(i);
                LxSource.Entry e = lx.entry(k);
                // 模板型脚本（如长青 SVIP）有 url 模板；运行时装接口型脚本（如 fish_music）没有模板，
                // 但平台名/音质清单齐全，取流由 FishApi 按脚本分支实现，同样算描述到位。
                boolean described = e != null && (e.templates.size() > 0 || e.qualitys.size() > 0);
                report("脚本音源 " + k + " 描述", described,
                        e == null ? "-" : (e.name + " · id 字段=" + e.idField + " · 音质=" + e.qualitys
                                + " · 等级=" + e.levelTokens + " · url 模板=" + e.templates.size()
                                + (e.templates.size() == 0 ? "（运行时装接口型，端上按脚本分支取流）" : "")));
            }
        }

        List<Song> wy = WyApi.search(keyword, 5);
        report("网易云搜索", !wy.isEmpty(), wy.isEmpty() ? "-" : wy.size() + " 首, 首条=" + wy.get(0).title + "/" + wy.get(0).artist);

        List<Song> kw = KwApi.search(keyword, 5);
        report("酷我搜索", !kw.isEmpty(), kw.isEmpty() ? "-" : kw.size() + " 首, 首条=" + kw.get(0).title + "/" + kw.get(0).artist + " rid=" + kw.get(0).id);

        List<Song> kg = KgApi.search(keyword, 5);
        report("酷狗搜索", !kg.isEmpty(), kg.isEmpty() ? "-" : kg.size() + " 首, 首条=" + kg.get(0).title + "/" + kg.get(0).artist);

        List<Song> qq = QqApi.search(keyword, 5);
        report("QQ搜索", !qq.isEmpty(), qq.isEmpty() ? "-" : qq.size() + " 首, 首条=" + qq.get(0).title + "/" + qq.get(0).artist);

        System.out.println();
        System.out.println("== 榜单（网易云公开榜单）==");
        Map<String, String> stations = WyApi.stations();
        String[] names = WyApi.stationNames();
        for (int i = 0; i < names.length; i++) {
            List<Song> tracks = WyApi.playlist(stations.get(names[i]), 100);
            report("榜单 " + names[i], tracks.size() > 0, tracks.size() + " 首"
                    + (tracks.isEmpty() ? "" : ", 首条=" + tracks.get(0).title));
        }

        System.out.println();
        System.out.println("== 歌词 ==");
        if (!wy.isEmpty()) {
            String lyric = WyApi.lyric(wy.get(0).id);
            Lrc lrc = Lrc.parse(lyric);
            report("歌词解析", lrc.size() > 0, lrc.size() + " 行, 第 3 行="
                    + (lrc.size() > 2 ? lrc.lines().get(2).text : "-"));
        }

        System.out.println();
        System.out.println("== 多线路取流（含 2KB 音频验真）==");
        resolveAndReport("网易云来源", wy.isEmpty() ? null : wy.get(0));
        resolveAndReport("酷我来源", kw.isEmpty() ? null : kw.get(0));
        resolveAndReport("酷狗来源（跨平台兜底）", kg.isEmpty() ? null : kg.get(0));
        resolveAndReport("QQ来源（跨平台兜底）", qq.isEmpty() ? null : qq.get(0));

        System.out.println();
        System.out.println("== 脚本音源（" + (lx == null ? "未装载" : lx.describe()) + "）线路 ==");
        if (lx != null && lx.isReady() && !wy.isEmpty()) {
            Song sample = wy.get(0);
            String key = LxSource.appSourceToKey(sample.source);
            String qk = LxSource.qualityKey(PlayResolver.QUALITY_320);
            LxSource.Entry entry = lx.entry(key);
            boolean templated = entry != null && entry.templates.size() > 0;
            if (templated) {
                // 模板型脚本：端上直接按模板拼地址
                String url = lx.buildUrl(key, sample.id, qk);
                report("脚本线路 URL 生成（" + key + " / " + qk + "）", url.length() > 0, url);
                Http.Probe p = Http.probeAudio(url, Http.headers(), 4000, 6000);
                System.out.println("[INFO] 脚本线路当前可用性：audio=" + p.audio + " HTTP " + p.code
                        + " / " + p.contentType
                        + "（上游代理不可用时这里会是非音频，属预期；取流会自动落到后面的兜底线路）");
            } else if (FishApi.enabled()) {
                // 运行时装接口型脚本（fish_music）：端上按脚本的分支链取流
                FishApi.Resolved r = FishApi.resolve(sample, qk);
                Http.Probe p = r.ok() ? Http.probeAudio(r.url, Http.headers(), 4000, 6000) : null;
                report("脚本线路取流（" + key + " / " + qk + "，运行时装接口型）",
                        r.ok() && p != null && p.audio,
                        r.ok() ? (r.upstream + " · HTTP " + p.code + " · " + p.contentType
                                + " · " + (p.audio ? "真音频" : p.error))
                                : "未取到地址（上游：" + r.upstream + "）");
            } else {
                report("脚本线路取流", false, "既无 url 模板，也不在 fish 链路覆盖范围内");
            }
        } else {
            report("脚本线路取流", false, "描述文件未装载或没有样本");
        }

        System.out.println();
        System.out.println("== 下载兜底（HTTPS 线路时使用）==");
        Song target = kw.isEmpty() ? (wy.isEmpty() ? null : wy.get(0)) : kw.get(0);
        if (target != null) {
            PlayResolver.Result r = PlayResolver.resolve(target, PlayResolver.QUALITY_320);
            if (r.ok()) {
                try {
                    File out = File.createTempFile("verify", ".mp3");
                    Http.download(r.url, Http.headers(), out, null);
                    Http.Probe p = Http.probeAudio(out.getAbsolutePath().startsWith("/") ? r.url : r.url, Http.headers());
                    report("整曲下载", out.length() > 200 * 1024,
                            "已下载 " + (out.length() / 1024) + "KB 到本地，音频头验真=" + p.audio);
                    out.delete();
                } catch (Exception e) {
                    report("整曲下载", false, e.toString());
                }
            } else {
                report("整曲下载", false, "未取到可用线路");
            }
        }

        System.out.println();
        System.out.println("==== 汇总：通过 " + pass + " 项，失败 " + fail + " 项 ====");
        if (fail > 0) {
            System.exit(1);
        }
    }

    private static void resolveAndReport(String title, Song song) {
        if (song == null) {
            report(title, false, "没有可用样本");
            return;
        }
        PlayResolver.Result r = PlayResolver.resolve(song, PlayResolver.QUALITY_320);
        System.out.println("-- " + title + "：" + song.title + " / " + song.artist);
        System.out.println(r.log());
        String note = r.ok() ? ("线路=" + r.label + " 类型=" + r.contentType) : r.note;
        report(title + " 取流", r.ok(), note);
    }

    private static void report(String item, boolean ok, String detail) {
        if (ok) {
            pass++;
        } else {
            fail++;
        }
        System.out.println("[" + (ok ? "PASS" : "FAIL") + "] " + item + " -> " + detail);
    }
}