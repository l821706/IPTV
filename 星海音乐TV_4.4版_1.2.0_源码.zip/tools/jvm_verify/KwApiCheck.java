import com.freemusic.tv.Http;
import com.freemusic.tv.KwApi;
import com.freemusic.tv.Song;

import java.util.List;

/**
 * 酷我官方三接口（nmobi.kuwo.cn）专项联网核对：
 *   搜索 → 取流 → 音频验真 → 官方明文歌词，用的就是打进 APK 的同一份 class。
 * 用法: java -cp tools/jvm_verify/out KwApiCheck [关键词]
 */
public class KwApiCheck {

    private static int pass;
    private static int fail;

    public static void main(String[] args) throws Exception {
        String keyword = args.length > 0 ? args[0] : "花海";
        System.out.println("== 关键词：" + keyword + " ==");

        List<Song> list = KwApi.search(keyword, 8);
        report("nmobi 官方搜索接口返回歌曲", list.size() > 0, "共 " + list.size() + " 首");
        for (int i = 0; i < list.size() && i < 8; i++) {
            Song s = list.get(i);
            System.out.println("    [" + (i + 1) + "] " + s.title + " / " + s.artist + " / "
                    + (s.duration / 1000) + "s / rid=" + s.id + " / 片段=" + (s.title.indexOf("片段") >= 0));
        }

        Song first = null;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).duration >= 60000 && list.get(i).title.indexOf("片段") < 0) {
                first = list.get(i);
                break;
            }
        }
        if (first == null && list.size() > 0) {
            first = list.get(0);
        }
        if (first == null) {
            report("可取流的样本歌曲", false, "搜索结果为空");
            summary();
            return;
        }
        System.out.println("-- 样本：" + first.title + " / " + first.artist + " rid=" + first.id + " --");

        String url = KwApi.playUrlMp3(first.id);
        report("nmobi 官方取流接口（convert_url_with_sign）返回地址",
                url != null && url.length() > 0, url == null ? "空" : url);
        if (url != null && url.length() > 0) {
            Http.Probe p = Http.probeAudio(url, Http.headers());
            report("取流地址 2KB 音频验真", p.audio,
                    "HTTP " + p.code + " · " + p.contentType + " · " + (p.audio ? "真音频" : p.error));
        }

        String lrc = KwApi.lyric(first.id);
        int lines = lrc == null ? 0 : lrc.split("\n").length;
        report("酷我官方明文歌词接口", lrc != null && lrc.trim().length() > 0, "共 " + lines + " 行");
        if (lrc != null && lrc.trim().length() > 0) {
            String[] arr = lrc.split("\n");
            for (int i = 0; i < arr.length && i < 3; i++) {
                System.out.println("     " + arr[i]);
            }
        }
        summary();
    }

    private static void report(String name, boolean ok, String detail) {
        if (ok) {
            pass++;
        } else {
            fail++;
        }
        System.out.println("[" + (ok ? "PASS" : "FAIL") + "] " + name + " -> " + detail);
    }

    private static void summary() {
        System.out.println("==== 汇总：通过 " + pass + " 项，失败 " + fail + " 项 ====");
    }
}