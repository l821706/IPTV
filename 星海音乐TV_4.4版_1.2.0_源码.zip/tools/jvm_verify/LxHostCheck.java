import com.freemusic.tv.JsEngine;
import com.freemusic.tv.Json;
import com.freemusic.tv.SourceStore;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;

/**
 * 「端上 lx 宿主接口完整性」的 JVM 侧检查（1.2.0 起）：
 *
 *   1. 宿主胶水确实给脚本准备了 lx.currentScriptInfo（脚本读 .version 不再 cannot read property）；
 *   2. 装载脚本时注入的元信息 JSON 能带上头部注释与脚本原文，且转义正确（多行原文能原样取回）；
 *   3. 「脚本跑不通」的原因里带得出错位置，并在脚本读过宿主没有的接口时写明缺哪个接口；
 *   4. 引擎试跑成功的脚本仍按「引擎执行型」收进描述（runner=quickjs）。
 *
 * 这些都不需要端上 QuickJS（native 库），可在 JVM 上直接跑：
 *   $ java -cp tools/jvm_verify/out:build/classes LxHostCheck
 */
public class LxHostCheck {

    private static int pass;
    private static int fail;

    public static void main(String[] args) throws Exception {
        String glue = readFile("assets/js/lx-host.js");
        check("宿主胶水提供 lx.currentScriptInfo", glue.indexOf("lx.currentScriptInfo = {") >= 0);
        check("宿主胶水给 currentScriptInfo 填 rawScript", glue.indexOf("rawScript: metaStr('rawScript')") >= 0);
        check("宿主胶水给 currentScriptInfo 填 version", glue.indexOf("version: metaStr('version')") >= 0);
        check("宿主胶水记录脚本读过但宿主没有的接口",
                glue.indexOf("lxMissing.push(k)") >= 0 && glue.indexOf("__lxMissingText") >= 0);

        String script = "/*!\n"
                + " * @name 测试音源\n"
                + " * @description 用于 JVM 侧检查的假脚本\n"
                + " * @version 9.9.9\n"
                + " * @author 测试者\n"
                + " * @homepage https://example.invalid/x\n"
                + " */\n"
                + "var a = 1;\n"
                + "lx.send(lx.EVENT_NAMES.inited, { status: true, sources: {} });\n";
        String meta = JsEngine.scriptMetaJson(script, "lx-latest.js",
                "https://raw.githubusercontent.com/pdone/lx-music-source/main/lx/latest.js", null, null);
        check("元信息 JSON 里没有裸换行（原样嵌入 JS 不会断行）", meta.indexOf('\n') < 0 && meta.indexOf('\r') < 0);
        Object root = Json.parse(meta);
        check("元信息能解析成 JSON", root != null);
        check("元信息带上脚本名", "测试音源".equals(Json.strAt(root, "name")));
        check("元信息带上脚本版本", "9.9.9".equals(Json.strAt(root, "version")));
        check("元信息带上描述/作者/主页",
                "用于 JVM 侧检查的假脚本".equals(Json.strAt(root, "description"))
                        && "测试者".equals(Json.strAt(root, "author"))
                        && "https://example.invalid/x".equals(Json.strAt(root, "homepage")));
        check("元信息带上脚本原文（逐字符一致）", script.equals(Json.strAt(root, "rawScript")));
        check("元信息带上脚本文件名", "lx-latest.js".equals(Json.strAt(root, "rawScriptPath")));
        check("元信息带上导入来源（在线地址）",
                "https://raw.githubusercontent.com/pdone/lx-music-source/main/lx/latest.js"
                        .equals(Json.strAt(root, "source")));
        Object localMeta = Json.parse(JsEngine.scriptMetaJson(script, "local.js", "", "本地音源", "1.0.0"));
        check("本地导入来源记为 local", "local".equals(Json.strAt(localMeta, "source")));
        check("描述文件里的名称/版本可以覆盖头部注释",
                "本地音源".equals(Json.strAt(localMeta, "name")) && "1.0.0".equals(Json.strAt(localMeta, "version")));

        check("报错堆栈能取出「文件:行」",
                "lx-latest.js:13".equals(JsEngine.positionOf("TypeError: x\n    at f (lx-latest.js:13)\n")));
        check("报错堆栈能取出「文件:行:列」且跳过 eval 拼接帧（胶水帧）",
                "lx-latest.js:13:3794".equals(JsEngine.positionOf(
                        "TypeError: x\n"
                                + "    at Array.eval (eval at <anonymous> (lx-host.js:1:1), <anonymous>:13:3797)\n"
                                + "    at f (lx-latest.js:13:3794)\n")));
        check("空堆栈返回空串", "".equals(JsEngine.positionOf("")) && "".equals(JsEngine.positionOf(null)));

        // 引擎试跑：跑不通时原因要能定位；跑得通时仍按「引擎执行型」收下
        String raw = "var x = 1;\n";
        SourceStore.Outcome bad = SourceStore.normalizeFor(raw, "lx-latest.js",
                new SourceStore.EngineProbe() {
                    @Override
                    public Result probe(String scriptText, String hintName) {
                        Result r = new Result();
                        r.error = "脚本执行失败：TypeError: cannot read property 'version' of undefined"
                                + "（出错位置 lx-latest.js:13:3794）；脚本读取了宿主未提供的接口：lx.currentScriptInfo";
                        return r;
                    }
                });
        check("跑不通时原因前缀仍是「端上 JS 引擎跑不通这个脚本」",
                bad.json.length() == 0 && bad.reason.startsWith("端上 JS 引擎跑不通这个脚本："));
        check("跑不通时原因带出错位置", bad.reason.indexOf("lx-latest.js:13:3794") >= 0);
        check("跑不通时原因写明缺哪个接口", bad.reason.indexOf("lx.currentScriptInfo") >= 0);

        SourceStore.Outcome good = SourceStore.normalizeFor(raw, "lx-latest.js",
                new SourceStore.EngineProbe() {
                    @Override
                    public Result probe(String scriptText, String hintName) {
                        Result r = new Result();
                        r.ok = true;
                        r.name = "独家音源";
                        r.version = "7";
                        r.platforms.add("kw");
                        r.platforms.add("kg");
                        r.platforms.add("tx");
                        r.platformNames.put("tx", "QQ音乐");
                        r.qualitys.put("tx", java.util.Arrays.asList("128k", "320k", "flac"));
                        return r;
                    }
                });
        check("跑得通时收成「引擎执行型」描述", good.json.length() > 0
                && good.json.indexOf("\"runner\":\"quickjs\"") >= 0);
        check("描述里带上脚本声明的平台", good.json.indexOf("\"kw\"") >= 0 && good.json.indexOf("\"tx\"") >= 0);

        System.out.println();
        System.out.println("通过 " + pass + " / 共 " + (pass + fail) + (fail == 0 ? "（全部通过）" : "，失败 " + fail));
        if (fail != 0) {
            System.exit(1);
        }
    }

    private static void check(String what, boolean ok) {
        if (ok) {
            pass++;
        } else {
            fail++;
        }
        System.out.println((ok ? "  ok   " : "  FAIL ") + what);
    }

    private static String readFile(String path) throws Exception {
        InputStream in = new FileInputStream(path);
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] tmp = new byte[8192];
        int n;
        while ((n = in.read(tmp)) > 0) {
            buf.write(tmp, 0, n);
        }
        in.close();
        return new String(buf.toByteArray(), "UTF-8");
    }
}