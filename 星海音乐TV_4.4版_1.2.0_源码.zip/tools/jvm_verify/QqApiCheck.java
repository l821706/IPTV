import com.freemusic.tv.Http;
import com.freemusic.tv.PlayResolver;
import com.freemusic.tv.QqApi;
import com.freemusic.tv.Song;
import com.freemusic.tv.WyApi;

import java.util.List;

/**
 * QQ 音乐官方三接口（搜索 / 取流 / 歌词）专项联网核对 + 三档音质核对。
 * 用法: java -cp tools/jvm_verify/out QqApiCheck [关键词]
 */
public class QqApiCheck {

    private static int pass;
    private static int fail;

    public static void main(String[] args) throws Exception {
        String keyword = args.length > 0 ? args[0] : "晴天 周杰伦";

        List<Song> list = QqApi.search(keyword, 5);
        report("QQ 官方搜索接口", !list.isEmpty(), "共 " + list.size() + " 首");
        for (int i = 0; i < list.size() && i < 3; i++) {
            Song s = list.get(i);
            System.out.println("    " + s.title + " / " + s.artist + " / mid=" + s.id + " / "
                    + (s.duration / 1000) + "s");
        }
        Song first = list.isEmpty() ? null : list.get(0);

        if (first != null) {
            String lrc = QqApi.lyric(first.id);
            int lines = lrc == null ? 0 : lrc.split("\n").length;
            report("QQ 官方歌词接口", lrc != null && lrc.trim().length() > 0, "共 " + lines + " 行");
            if (lrc != null && lrc.trim().length() > 0) {
                String[] arr = lrc.split("\n");
                for (int i = 0; i < arr.length && i < 3; i++) {
                    System.out.println("     " + arr[i]);
                }
            }
            int got = 0;
            String[] qs = {"128k", "320k", "flac"};
            for (int i = 0; i < qs.length; i++) {
                String u = QqApi.songUrl(first.id, qs[i]);
                if (u.length() == 0) {
                    System.out.println("[INFO] QQ 官方取流 " + qs[i] + " -> 返回空地址（匿名未登录，官方接口不下发 purl）");
                    continue;
                }
                Http.Probe p = Http.probeAudio(u, Http.headers("Referer", "https://y.qq.com/"));
                if (p.audio) {
                    got++;
                }
                System.out.println("[" + (p.audio ? "OK" : "INFO") + "] QQ 官方取流 " + qs[i]
                        + " -> HTTP " + p.code + " · " + p.contentType + " · " + (p.audio ? "真音频" : p.error));
            }
            // 取流接口本身是否可达、响应结构是否符合预期（与「能不能拿到地址」分开看）
            String fn = "M800" + first.id + ".mp3";
            String body = "{\"req_0\":{\"module\":\"vkey.GetVkeyServer\",\"method\":\"CgiGetVkey\",\"param\":"
                    + "{\"guid\":\"10000\",\"songmid\":[\"" + first.id + "\"],\"filename\":[\"" + fn + "\"],"
                    + "\"songtype\":[0],\"uin\":\"0\",\"loginflag\":1,\"platform\":\"20\"}},"
                    + "\"comm\":{\"uin\":0,\"format\":\"json\",\"ct\":24,\"cv\":0}}";
            Http.Res raw = Http.get("https://u.y.qq.com/cgi-bin/musicu.fcg?format=json&data=" + Http.encode(body),
                    Http.headers("Referer", "https://y.qq.com/"));
            boolean reachable = raw.ok() && raw.body.indexOf("\"code\":0") >= 0
                    && raw.body.indexOf("midurlinfo") >= 0;
            report("QQ 官方取流接口可达且响应结构正确", reachable,
                    "HTTP " + raw.code + " · 含 req_0/data/midurlinfo" + (got > 0 ? " · 可用档位 " + got + "/3" : ""));
            System.out.println("[限制] QQ 官方取流需要登录态（uin + qqmusic_key）：匿名请求官方一律不下发 purl，"
                    + "端上照官方参数发起后拿到空地址即按顺序回落到 酷狗 → 酷我 → 网易云。");
        }

        // 三档音质：用网易云样本看 128K / 320K / FLAC 三档是否都能取到真音频
        List<Song> wy = WyApi.search("晴天 周杰伦", 5);
        if (!wy.isEmpty()) {
            Song s = wy.get(0);
            String[] labels = {"高品 128K", "超品 320K", "无损 FLAC"};
            int[] qs = {PlayResolver.QUALITY_128, PlayResolver.QUALITY_320, PlayResolver.QUALITY_FLAC};
            for (int i = 0; i < qs.length; i++) {
                PlayResolver.Result r = PlayResolver.resolve(s, qs[i]);
                report("音质档「" + labels[i] + "」取流", r.ok(),
                        r.ok() ? (r.label + " · " + r.contentType) : r.note);
            }
        }
        summary();
    }

    private static void report(String name, boolean ok, String detail) {
        if (ok) {
            pass++;
        } else {
            fail++;
        }
        System.out.println("[" + (ok ? "PASS" : "FAIL") + "] " + name + " -> " + detail);
    }

    private static void summary() {
        System.out.println("==== 汇总：通过 " + pass + " 项，失败 " + fail + " 项 ====");
    }
}