import com.freemusic.tv.LxSource;
import com.freemusic.tv.PlayResolver;
import com.freemusic.tv.Song;
import com.freemusic.tv.SourceStore;
import com.freemusic.tv.WyApi;
import java.util.List;

/**
 * 「导入音源切换后取流确实走它」的 JVM 侧检查：
 * 用一份测试音源描述（网易云外链模板）顶到当前音源，看取流首选线路是不是它，再切回内置对比。
 */
public class SourceFlowCheck {

    public static void main(String[] args) throws Exception {
        String builtin = readFile("assets/lx_source.json");
        String test = readFile(args.length > 0 ? args[0] : "/tmp/test-source.json");
        SourceStore.Item bi = SourceStore.fromJson(SourceStore.ID_BUILTIN, builtin, "", true);
        SourceStore.Item ti = SourceStore.fromJson("test-source", test, "", false);
        System.out.println("内置音源: " + (bi == null ? "解析失败" : bi.title() + " 平台=" + bi.platforms()
                + " 模板=" + bi.parsed.hasTemplates()));
        System.out.println("导入音源: " + (ti == null ? "解析失败" : ti.title() + " 平台=" + ti.platforms()
                + " 模板=" + (ti == null ? false : ti.parsed.hasTemplates())));

        List<Song> wy = WyApi.search("晴天 周杰伦", 3);
        if (wy.isEmpty()) {
            System.out.println("网易云搜索无结果，无法检查");
            return;
        }
        Song song = wy.get(0);
        System.out.println("测试歌曲: " + song.displayTitle() + " / " + song.displayArtist()
                + " 平台=" + song.source + " id=" + song.id);

        System.out.println("--- 切换到导入音源后取流 ---");
        LxSource.setActive(ti.parsed);
        PlayResolver.Result r1 = PlayResolver.resolve(song, PlayResolver.QUALITY_320);
        System.out.println("  结果=" + r1.ok() + " 线路=" + r1.label);
        System.out.println("  地址=" + (r1.url.length() > 80 ? r1.url.substring(0, 80) + "…" : r1.url));
        System.out.println("  首选走导入音源=" + r1.label.contains(ti.title()));
        System.out.println("  全部线路尝试:\n" + r1.log());

        checkEngineFallback();

        System.out.println("--- 切回内置音源后取流（回归） ---");
        LxSource.setActive(bi.parsed);
        PlayResolver.Result r2 = PlayResolver.resolve(song, PlayResolver.QUALITY_320);
        System.out.println("  结果=" + r2.ok() + " 线路=" + r2.label);
        System.out.println("  线路不含导入音源名=" + !r2.label.contains(ti.title()));
    }

    /** 引擎执行型描述在 JVM 上应优雅降级：记一条「引擎不可用」线路，再回退平台线路取流。 */
    private static void checkEngineFallback() {
        String engineJson = "{\"scriptFile\":\"juhe.js\",\"sourceUrl\":\"\",\"runner\":\"quickjs\","
                + "\"metadata\":{\"name\":\"接口型测试音源\",\"version\":\"1.0\"},"
                + "\"behaviour\":{\"sources\":[\"tx\",\"wy\"]},"
                + "\"sources\":{"
                + "\"tx\":{\"name\":\"QQ音乐\",\"idField\":\"\",\"qualitys\":[\"128k\",\"320k\"],\"urlTemplates\":{},\"levelTokens\":{}},"
                + "\"wy\":{\"name\":\"网易云\",\"idField\":\"\",\"qualitys\":[\"320k\"],\"urlTemplates\":{},\"levelTokens\":{}}}}";
        SourceStore.Item ei = SourceStore.fromJson("juhe", engineJson, "", false);
        System.out.println("--- 引擎执行型音源（JVM 无引擎） ---");
        System.out.println("  条目可用=" + (ei != null && ei.usable) + " 引擎执行=" + (ei != null && ei.engine)
                + " 显示名=" + (ei == null ? "null" : ei.title()));
        if (ei == null || !ei.usable || !ei.engine) {
            System.out.println("  [FAIL] 引擎执行型条目应被接受且可用");
            return;
        }
        List<Song> wy = WyApi.search("晴天 周杰伦", 3);
        if (wy.isEmpty()) {
            System.out.println("  网易云搜索无结果，跳过");
            return;
        }
        LxSource.setActive(ei.parsed);
        PlayResolver.Result r = PlayResolver.resolve(wy.get(0), PlayResolver.QUALITY_320);
        boolean noted = false;
        for (int i = 0; i < r.attempts.size(); i++) {
            String label = r.attempts.get(i).label;
            if (label != null && label.indexOf("脚本音源") >= 0) {
                noted = true;
                System.out.println("  线路: " + r.attempts.get(i).describe());
            }
        }
        System.out.println("  取流结果=" + r.ok() + " 命中=" + r.label);
        System.out.println("  " + (noted ? "[PASS] 引擎不可用时记为一条线路并回退平台线路"
                : "[FAIL] 诊断里应出现「脚本音源」线路"));
        LxSource.setActive(null);
    }

    private static String readFile(String p) throws Exception {
        java.io.FileInputStream in = new java.io.FileInputStream(p);
        java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
        byte[] c = new byte[4096];
        int n;
        while ((n = in.read(c)) > 0) {
            b.write(c, 0, n);
        }
        in.close();
        return new String(b.toByteArray(), "UTF-8");
    }
}
