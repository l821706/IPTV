import com.freemusic.tv.LxSource;
import com.freemusic.tv.SourceStore;

/** 音源仓库（导入识别/校验）的 JVM 侧自检：不依赖 android.*，与端上共用同一份 class。 */
public class SourceStoreCheck {

    private static int pass;
    private static int fail;

    public static void main(String[] args) {
        String good = "{\"scriptFile\":\"test-source.json\",\"sourceUrl\":\"\","
                + "\"metadata\":{\"name\":\"测试音源\",\"version\":\"1.0\"},"
                + "\"behaviour\":{\"sources\":[\"wy\",\"kw\"]},"
                + "\"sources\":{"
                + "\"wy\":{\"name\":\"网易云\",\"idField\":\"id\",\"qualitys\":[\"320k\"],"
                + "\"urlTemplates\":{\"320k\":\"https://example.com/wy/{id}.mp3\"},\"levelTokens\":{}},"
                + "\"kw\":{\"name\":\"酷我\",\"idField\":\"rid\",\"qualitys\":[\"128k\"],"
                + "\"urlTemplates\":{\"128k\":\"https://example.com/kw/{id}.mp3\"},\"levelTokens\":{}}}}";

        // 1) 合法描述 JSON：应被接收，且可用（有模板）
        String norm = SourceStore.normalize(good, "test-source.json");
        report("合法描述 JSON 被接收", norm.length() > 0, norm.length() + " 字符");
        SourceStore.Item item = SourceStore.fromJson("test-source", good, "", false);
        report("条目可用（有取流模板）", item != null && item.usable,
                item == null ? "null" : item.title() + " 平台=" + item.platforms());
        report("显示名解析", item != null && "测试音源 v1.0".equals(item.title()),
                item == null ? "null" : item.title());

        // 2) 没有模板的描述 JSON：应被拒（不留不可用条目）
        String noTpl = "\"qualitys\":[]";
        String plain = "{"
                + "\"scriptFile\":\"x.json\",\"metadata\":{\"name\":\"空音源\"},"
                + "\"behaviour\":{\"sources\":[\"wy\"]},"
                + "\"sources\":{\"wy\":{\"name\":\"网易云\",\"idField\":\"id\",";
        String bad = plain + noTpl + ",\"urlTemplates\":{},\"levelTokens\":{}}}}";
        report("无模板描述被拒", SourceStore.normalize(bad, "x.json").length() == 0, "长度应为 0");

        // 3) 脚本文本：带 @name/@version 与字面模板 → 尽力提取成描述
        String js = "/*\n * @name my_source\n * @version 2.3.4\n * @author someone\n */\n"
                + "(function(){ var m = { 'kw': { '320k': 'https:\\/\\/api.example.com\\/kw?id={id}&q=320',"
                + " '128k': 'https://api.example.com/kw?id={id}&q=128' } }; })();";
        String fromJs = SourceStore.normalize(js, "my_source.js");
        report("脚本可提取出模板描述", fromJs.length() > 0, fromJs.length() + " 字符");
        SourceStore.Item jsItem = SourceStore.fromJson("my_source", fromJs, "", false);
        report("脚本条目可用且带元信息", jsItem != null && jsItem.usable
                        && jsItem.title().indexOf("my_source") >= 0,
                jsItem == null ? "null" : jsItem.title() + " 平台=" + jsItem.platforms());
        LxSource jsLx = jsItem == null ? null : jsItem.parsed;
        String built = jsLx == null ? "" : jsLx.buildUrl("kw", "123456", "320k");
        report("脚本模板能拼出地址并替换 {id}",
                built.indexOf("123456") >= 0 && built.indexOf("{id}") < 0, built);

        // 4) 没有任何模板的脚本：应被拒
        String jsNoTpl = "/* @name obfuscated */\n(function(){var _0x1='\u4e2d\u6587';})();";
        report("无模板脚本被拒", SourceStore.normalize(jsNoTpl, "obfuscated.js").length() == 0, "长度应为 0");

        // 5) 真实脚本形态：musicUrl 里用 ES 模板串拼出来的取流地址（长青SVIP 1.3.0 同款）
        String changqing = "/*\n * @name 长青SVIP音源\n * @version 1.3.0\n */\n"
                + "const _ru={kg:{musicUrl(r,e){let t=\"\";const n=r.hash;"
                + "return t=`http://yinyue.haitangw.net/kg/kg_song_kw.php?type=mp3&id=${n}&level=${e}`,t}}"
                + ",tx:{musicUrl(r,e){let t=\"\";const n=r.songmid;"
                + "return t=`http://yinyue.haitangw.net/qq/qq_kw.php?type=mp3&id=${n}&level=${e}`,t}}};";
        SourceStore.Outcome cq = SourceStore.normalizeFor(changqing, "changqing.js");
        report("模板串式脚本被接收", cq.ok(), cq.ok() ? cq.json.length() + " 字符" : cq.reason);
        SourceStore.Item cqItem = cq.ok() ? SourceStore.fromJson("cq", cq.json, "", false) : null;
        report("模板串式脚本可用且认到平台/元信息",
                cqItem != null && cqItem.usable && cqItem.title().indexOf("长青SVIP音源") >= 0
                        && cqItem.platforms().indexOf("kg") >= 0 && cqItem.platforms().indexOf("tx") >= 0,
                cqItem == null ? "null" : cqItem.title() + " 平台=" + cqItem.platforms());
        report("模板串里的 ${n} 被归一成 {id}、${e} 成 {level}",
                cqItem != null && "hash".equals(cqItem.parsed.idField("kg"))
                        && cqItem.parsed.entry("kg").templates.get("320k")
                        .equals("http://yinyue.haitangw.net/kg/kg_song_kw.php?type=mp3&id={id}&level={level}"),
                cqItem == null ? "null" : cqItem.parsed.entry("kg").templates.get("320k"));
        report("取流地址能拼出歌曲 id 与音质 level",
                cqItem != null && "http://yinyue.haitangw.net/kg/kg_song_kw.php?type=mp3&id=H1&level=exhigh"
                        .equals(cqItem.parsed.buildUrl("kg", "H1", "320k"))
                        && "http://yinyue.haitangw.net/qq/qq_kw.php?type=mp3&id=M1&level=standard"
                        .equals(cqItem.parsed.buildUrl("tx", "M1", "128k")),
                cqItem == null ? "null" : cqItem.parsed.buildUrl("kg", "H1", "320k"));

        // 6) 真实脚本形态：已经写成 {id}/{level} 的模板表 + 字符串拼接式模板
        String templates = "/*\n * @name 汽水音源\n * @version 9.3\n */\n"
                + "const T={tx:\"http://175.27.166.236/kgqq/qq.php?type=mp3&id={id}&level={level}\","
                + "wy:\"http://music.nxinxz.com/wy.php?id={id}&level={level}&type=mp3\"};";
        SourceStore.Item tItem = SourceStore.fromJson("t", SourceStore.normalize(templates, "qdy.js"), "", false);
        report("{id} 模板表被接收并可用", tItem != null && tItem.usable,
                tItem == null ? "null" : tItem.platforms() + " " + tItem.parsed.entry("tx").templates.get("128k"));
        report("{id} 模板表认到两个平台且顺序正确",
                tItem != null && "tx/wy".equals(tItem.platforms()),
                tItem == null ? "null" : tItem.platforms());

        String concat = "/*\n * @name 拼接式音源\n * @version 2.3.0\n */\n"
                + "const pick=()=>'http://175.27.166.236/kgqq1/qq.php?type=mp3&id=' + songmid;";
        SourceStore.Item ctItem = SourceStore.fromJson("c", SourceStore.normalize(concat, "jiexiang.js"), "", false);
        report("拼接式模板补出 {id}",
                ctItem != null && ctItem.parsed.entry("tx") != null
                        && "http://175.27.166.236/kgqq1/qq.php?type=mp3&id={id}"
                        .equals(ctItem.parsed.entry("tx").templates.get("128k")),
                ctItem == null ? "null" : "平台=" + ctItem.platforms() + " "
                        + ctItem.parsed.entry("tx").templates.get("128k"));

        // 7) 含无法解析的配置占位（星海 2.3.15 同款）与配置/更新地址都不该被当模板
        String configOnly = "/* @name 配置型 */\nconst U=\"https://${URL_CONFIG.domains.a}\""
                + "${URL_CONFIG.paths.b}?id=${id}&level=${level}&apikey=${encodeURIComponent(K)}\";";
        report("无法解析的配置占位地址被拒",
                SourceStore.normalize(configOnly, "xinghai.js").length() == 0, "长度应为 0");
        String metaOnly = "/* @name 只有配置地址 */\nconst A=\"https://x.com/lxmusic/changqing.json\";"
                + "const B=\"https://api.example.com/init.conf\";";
        report("描述/配置地址不会误当取流模板",
                SourceStore.normalize(metaOnly, "meta.js").length() == 0, "长度应为 0");

        // 8) 引擎执行型：接口型脚本交给「引擎试跑」钩子判定
        String runtimeScript = "/*!\n * @name 聚合API接口 (CF)\n * @version 3\n */\n"
                + "let A='https://api.music.lerd.dpdns.org';\n"
                + "on(EVENT_NAMES.request, async ({action, source, info}) => { const r = await h(A); return r.body.url; });";
        SourceStore.EngineProbe okProbe = new SourceStore.EngineProbe() {
            @Override
            public Result probe(String scriptText, String hintName) {
                Result r = new Result();
                r.ok = true;
                r.name = "聚合API接口";
                r.version = "3";
                r.platforms.add("tx");
                r.platforms.add("kg");
                r.platformNames.put("tx", "QQ音乐");
                r.platformNames.put("kg", "酷狗");
                r.qualitys.put("tx", java.util.Arrays.asList("128k", "320k"));
                r.qualitys.put("kg", java.util.Arrays.asList("128k"));
                return r;
            }
        };
        SourceStore.Outcome eng = SourceStore.normalizeFor(runtimeScript, "juhe.js", okProbe);
        report("引擎跑得通时接口型脚本被收下", eng.ok(), eng.ok() ? eng.json : eng.reason);
        SourceStore.Item engItem = eng.ok() ? SourceStore.fromJson("juhe", eng.json, "", false) : null;
        report("引擎执行型条目可用且标记正确",
                engItem != null && engItem.usable && engItem.engine && !engItem.parsed.hasTemplates(),
                engItem == null ? "null" : engItem.title() + " 平台=" + engItem.platforms());
        report("引擎执行型显示名带「引擎执行」", engItem != null && engItem.title().indexOf("引擎执行") > 0,
                engItem == null ? "null" : engItem.title());

        SourceStore.EngineProbe badProbe = new SourceStore.EngineProbe() {
            @Override
            public Result probe(String scriptText, String hintName) {
                Result r = new Result();
                r.ok = false;
                r.error = "SyntaxError: unexpected token";
                return r;
            }
        };
        SourceStore.Outcome badOutcome = SourceStore.normalizeFor(runtimeScript, "juhe.js", badProbe);
        report("引擎跑不通时给出引擎原因",
                !badOutcome.ok() && badOutcome.reason.indexOf("端上 JS 引擎跑不通") >= 0
                        && badOutcome.reason.indexOf("SyntaxError") >= 0,
                badOutcome.reason);

        // 9) id / 文件名清洗
        report("id 取自地址", "my_source".equals(SourceStore.idFrom("https://a.b/c/my_source.js?x=1")),
                SourceStore.idFrom("https://a.b/c/my_source.js?x=1"));
        report("非法字符被清洗", SourceStore.cleanId("../a b/中文.json").indexOf('/') < 0,
                SourceStore.cleanId("../a b/中文.json"));

        // 10) 内置描述（真实 assets 文件）仍可解析，且判定为「非模板型」
        String builtinJson = readFile(args.length > 0 ? args[0] : "assets/lx_source.json");
        SourceStore.Item bi = SourceStore.fromJson(SourceStore.ID_BUILTIN, builtinJson, "", true);
        report("内置描述可解析", bi != null && bi.parsed != null && bi.parsed.isReady(),
                bi == null ? "null" : bi.title());
        report("内置描述判定为非模板型（模板线路不会插到平台线路前）",
                bi != null && !bi.parsed.hasTemplates(), bi == null ? "null" : "hasTemplates=false");
        report("内置描述按导入路径会被拒且原因指向 urlTemplates",
                !SourceStore.normalizeFor(builtinJson, "lx_source.json").ok()
                        && SourceStore.normalizeFor(builtinJson, "lx_source.json").reason.indexOf("urlTemplates") >= 0,
                SourceStore.normalizeFor(builtinJson, "lx_source.json").reason);

        System.out.println("==== 汇总：通过 " + pass + " 项，失败 " + fail + " 项 ====");
        if (fail > 0) {
            System.exit(1);
        }
    }

    private static void report(String name, boolean ok, String detail) {
        if (ok) {
            pass++;
        } else {
            fail++;
        }
        System.out.println("[" + (ok ? "PASS" : "FAIL") + "] " + name + " -> " + detail);
    }

    private static String readFile(String path) {
        try {
            java.io.FileInputStream in = new java.io.FileInputStream(path);
            java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
            byte[] c = new byte[4096];
            int n;
            while ((n = in.read(c)) > 0) {
                buf.write(c, 0, n);
            }
            in.close();
            return new String(buf.toByteArray(), "UTF-8");
        } catch (Throwable t) {
            return "";
        }
    }
}