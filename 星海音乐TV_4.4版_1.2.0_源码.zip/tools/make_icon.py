# -*- coding: utf-8 -*-
"""生成各密度启动图标（深色底 + 蓝色唱片 + 高光）。"""
import os
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SIZES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144}

BG = (11, 14, 19, 255)
DISC = (18, 23, 34, 255)
RING = (35, 42, 54, 255)
ACCENT = (76, 154, 255, 255)
WHITE = (233, 238, 247, 255)


def make(size):
    scale = 4
    s = size * scale
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([0, 0, s - 1, s - 1], radius=int(s * 0.22), fill=BG)
    cx = cy = s / 2.0
    r = s * 0.36
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=DISC)
    for i in range(1, 6):
        rr = r * (0.68 + 0.06 * i)
        d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], outline=RING, width=max(1, scale // 2))
    label_r = r * 0.58
    d.ellipse([cx - label_r, cy - label_r, cx + label_r, cy + label_r], fill=ACCENT)
    d.polygon(
        [(cx - label_r * 0.28, cy - label_r * 0.55),
         (cx - label_r * 0.28, cy + label_r * 0.55),
         (cx + label_r * 0.62, cy)],
        fill=WHITE,
    )
    d.ellipse([cx - r * 0.07, cy - r * 0.07, cx + r * 0.07, cy + r * 0.07], fill=(11, 14, 19, 255))
    return img.resize((size, size), Image.LANCZOS)


for name, px in SIZES.items():
    folder = os.path.join(ROOT, "res", "mipmap-" + name)
    os.makedirs(folder, exist_ok=True)
    out = os.path.join(folder, "ic_launcher.png")
    make(px).save(out, "PNG")
    print("生成", out, px)